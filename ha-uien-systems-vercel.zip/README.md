# HỆ THỐNG AI AGENT THẨM ĐỊNH MẠNG LƯỚI PHÂN PHỐI ĐỐI TÁC 3 KHU VỰC
## HA UIEN SYSTEMS (TRÍ TUỆ NHÂN TẠO HA UIEN)

---

## 🌟 TỔNG QUAN GIẢI PHÁP
Hệ thống **Trí tuệ nhân tạo Ha Uien** là giải pháp AI Agent tự động thẩm định và phân bổ hồ sơ đối tác phân phối tại **3 khu vực (Miền Bắc - Miền Trung - Miền Nam)** cho Tập đoàn **HA UIEN SYSTEMS**. Hệ thống giải quyết triệt để 3 bài toán lớn:
1. **Phát hiện đối tác cũ nợ xấu đổi tên đăng ký mới (Entity Resolution):** Tự động phát hiện các đối tác cố tình che giấu nợ quá hạn (vụ điển hình: *Đại lý Hoàng Phát còn nợ 180 triệu VNĐ*).
2. **Kiểm tra và ngăn chặn xung đột địa bàn bảo hộ độc quyền (< 3.0 km) (Territory Geofencing):** Bảo vệ các đại lý Cấp 1 hiện hữu bằng thuật toán toạ độ thực tế Haversine.
3. **Chống thiên vị cam kết sản lượng ảo và kiểm soát rủi ro công nợ vượt chính sách (Anti-Bias & Credit Policy Audit):** Tự động gắn cờ và yêu cầu Thư bảo lãnh ngân hàng cho các trường hợp vượt trần (tối đa 30 ngày, 500 triệu VNĐ).

Giao diện được thiết kế sinh động, hiện đại kết hợp:
- **Ảnh 1 & 2:** Bố cục thanh điều hướng chuẩn mực, luồng xử lý 4 bước trực quan, bảng điều khiển chuyên nghiệp và chân trang thông tin doanh nghiệp.
- **Ảnh 3:** Tông màu vàng chanh rực rỡ, xanh ngọc bích, linh vật sinh động và menu thả xuống Dịch vụ 3 mục.

---

## 🏢 THÔNG TIN DOANH NGHIỆP HA UIEN SYSTEMS
- **Doanh nghiệp:** HA UIEN SYSTEMS (Tập đoàn Thiết bị Gia dụng & Phân phối Quốc tế)
- **Trụ sở Quốc tế & Điều hành:** New York, Mỹ
- **Hotline hỗ trợ 24/7:** 0816710189
- **Email tiếp nhận:** buihauyen121007@gmail.com
- **Mã số thuế:** US-NY-8899210 (Đại diện VN: 0108899210)

---

## ✨ CÁC TÍNH NĂNG MỚI ĐÃ BỔ SUNG TOÀN DIỆN
1. **Thanh điều hướng Header (Phong cách Ảnh 2 & Tông màu Vàng-Mint chuẩn):**
   - `Trang chủ`: Cuộn mượt về đầu trang.
   - `Giới thiệu` (Huy hiệu Vàng-Mint hài hòa): Mở modal giới thiệu chi tiết về HA UIEN SYSTEMS, sứ mệnh 3 miền và kiến trúc Trí tuệ nhân tạo Ha Uien.
   - `Dịch vụ ᐯ` (Menu thả xuống phong cách Ảnh 3):
     - ☁️ **Gửi dữ liệu:** *Excel · Word · PDF · Sheet · Lark Base* (chuyển thẳng Bước 1).
     - 🖌️ **Nhận & làm sạch:** *AI kiểm tra, báo lỗi để gửi lại* (chuyển thẳng Bước 2).
     - 📊 **Kết quả dữ liệu:** *Dashboard · Báo cáo (BC) · Xuất HTML* (chuyển thẳng Bước 4).
   - `Hỏi đáp`: Mở modal FAQ tương tác giải đáp chính sách 3km, công nợ 500tr, bảo hành và hướng dẫn nạp file thi.
   - `Liên hệ`: Mở modal liên hệ trực tiếp với trụ sở New York, hotline 0816710189, buihauyen121007@gmail.com và form gửi phản hồi.
2. **Khung biểu đồ 3D tương tác Trái / Phải:**
   - Xoay 3D đa chiều mượt mà khi di chuột hoặc chạm kéo trên màn hình cảm ứng.
   - Đầy đủ nút công cụ 3D: `↺ Trái`, `🔄 Xoay 3D (Tự động)`, `Phải ↻`, `Reset`.
3. **Bộ Sticker Hoạt hình Vui nhộn (Pop Stickers):**
   - Bắp rang bơ 🍿, Xấp tiền đô la 💵, Mặt cười trái tim 😍, Kim cương xanh 💎, Thẻ tín dụng 💳, Ngọn lửa 🔥, Quả bom 💣, Kính ngôi sao 🕶️.
4. **Chế độ Sáng / Tối (Light & Dark Mode):**
   - Nút chuyển đổi ☀️ Sáng / 🌙 Tối tiện lợi trên thanh Header.
5. **Hệ thống Tài khoản Người dùng (User Account & Auth):**
   - **Đăng nhập:** Email/SĐT + Mật khẩu, hỗ trợ 1-click Demo Login với tư cách Trưởng phòng PTKD Bùi Hà Uyên.
   - **Tạo tài khoản (Đăng ký):** Nhập Tên, Email, SĐT, Phòng ban, Mật khẩu.
   - **Quên mật khẩu:** Gửi mã xác thực OTP về email (`buihauyen121007@gmail.com`), nhập mã xác nhận và đổi mật khẩu mới.
6. **Đa ngôn ngữ Song ngữ (Bilingual Switcher):**
   - Hỗ trợ chuyển đổi giữa **🇻🇳 Tiếng Việt (VIE)** và **🇬🇧 Tiếng Anh (ENG)** theo thời gian thực.
7. **Chân trang Doanh nghiệp (Footer hài hòa tuyệt đối):**
   - 4 cột đầy đủ thông tin HA UIEN SYSTEMS (New York, SĐT 0816710189, Email buihauyen121007@gmail.com), tông màu vàng chanh - xanh ngọc thống nhất.

---

## 🚀 HƯỚNG DẪN KHỞI CHẠY TRÊN LOCALHOST

### Cách 1: Chạy bằng file `run.bat` (Khuyên dùng - 1 Click)
- Nhấp đúp chuột vào file **`run.bat`** trong thư mục này.
- Cửa sổ dòng lệnh sẽ chạy máy chủ HTTP nội bộ và tự động mở trình duyệt tại:
  $$\text{http://localhost:8080}$$

### Cách 2: Mở trực tiếp bằng trình duyệt
- Nhấp đúp chuột vào file **`index.html`** để mở ngay trên bất kỳ trình duyệt nào (Edge, Chrome, Opera, Cốc Cốc).
