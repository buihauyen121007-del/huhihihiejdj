/**
 * HA UIEN SYSTEMS - 3D INTERACTIVE BACKGROUND ENGINE
 * Pure 3D Interactive Space with Real Spheres, Cubes, Rings & Polyhedrons
 * Supports Three.js WebGL (PBR/Specular/Lights) with seamless Native Canvas 3D Fallback.
 * 60 FPS, Mouse Parallax, Reactive Physics, Zero Layout Disruption.
 */

(function () {
  'use strict';

  // Palette: Colorful Tech & Playful Modern SaaS
  const PALETTE = {
    electricBlue: '#3B82F6',
    electricBlueDark: '#1D4ED8',
    lavenderPurple: '#8B5CF6',
    lavenderLight: '#A78BFA',
    coralPink: '#F43F5E',
    coralPinkLight: '#FB7185',
    goldenAmber: '#FFD027',
    amberDeep: '#F59E0B',
    freshMint: '#10B981',
    cyberCyan: '#06B6D4',
    bgDark: '#080C16',
    bgLight: '#F8FAFC'
  };

  let canvas = null;
  let activeEngine = null;
  let mouse = { x: 0, y: 0, targetX: 0, targetY: 0, px: 0, py: 0 };
  let isDark = document.documentElement.classList.contains('dark');

  // Track mouse coordinates across the entire document
  function setupMouseTracking() {
    window.addEventListener('mousemove', function (e) {
      const halfW = window.innerWidth / 2;
      const halfH = window.innerHeight / 2;
      mouse.targetX = (e.clientX - halfW) / halfW; // -1 to 1
      mouse.targetY = (e.clientY - halfH) / halfH; // -1 to 1
      mouse.px = e.clientX;
      mouse.py = e.clientY;
    }, { passive: true });

    // Touch support for mobile devices
    window.addEventListener('touchmove', function (e) {
      if (e.touches && e.touches[0]) {
        const halfW = window.innerWidth / 2;
        const halfH = window.innerHeight / 2;
        mouse.targetX = (e.touches[0].clientX - halfW) / halfW;
        mouse.targetY = (e.touches[0].clientY - halfH) / halfH;
      }
    }, { passive: true });

    // Watch for Theme changes (Dark Mode <-> Light Mode)
    const observer = new MutationObserver(function (mutations) {
      mutations.forEach(function (m) {
        if (m.attributeName === 'class') {
          const newDark = document.documentElement.classList.contains('dark');
          if (newDark !== isDark) {
            isDark = newDark;
            if (activeEngine && activeEngine.onThemeChange) {
              activeEngine.onThemeChange(isDark);
            }
          }
        }
      });
    });
    observer.observe(document.documentElement, { attributes: true });
  }

  /* =========================================================================
   * ENGINE A: THREE.JS WEBGL 3D INTERACTIVE WORLD
   * ========================================================================= */
  function initThreeJsEngine(c) {
    const THREE = window.THREE;
    const scene = new THREE.Scene();

    const fov = 50;
    const aspect = window.innerWidth / window.innerHeight;
    const camera = new THREE.PerspectiveCamera(fov, aspect, 1, 3000);
    camera.position.z = 700;

    const renderer = new THREE.WebGLRenderer({
      canvas: c,
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance'
    });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));

    // Lights
    const ambientLight = new THREE.AmbientLight(isDark ? 0x1e1b4b : 0xe0e7ff, 1.2);
    scene.add(ambientLight);

    // Multi-color orbiting Point Lights
    const lightBlue = new THREE.PointLight(0x3B82F6, isDark ? 3.5 : 2.0, 1500);
    scene.add(lightBlue);

    const lightPurple = new THREE.PointLight(0x8B5CF6, isDark ? 3.0 : 1.8, 1500);
    scene.add(lightPurple);

    const lightPink = new THREE.PointLight(0xF43F5E, isDark ? 2.8 : 1.5, 1200);
    scene.add(lightPink);

    const lightAmber = new THREE.PointLight(0xFFD027, isDark ? 2.5 : 1.5, 1200);
    scene.add(lightAmber);

    const dirLight = new THREE.DirectionalLight(0xffffff, isDark ? 0.8 : 1.2);
    dirLight.position.set(200, 400, 300);
    scene.add(dirLight);

    // Container group for gentle mouse tilt
    const worldGroup = new THREE.Group();
    scene.add(worldGroup);

    const interactiveObjects = [];

    // Helper: Create glassy / metallic physical material
    function createMaterial(colorHex, emissiveHex, metal, rough, trans) {
      return new THREE.MeshPhysicalMaterial({
        color: colorHex,
        emissive: emissiveHex || 0x000000,
        emissiveIntensity: isDark ? 0.25 : 0.08,
        metalness: metal || 0.2,
        roughness: rough || 0.15,
        clearcoat: 0.8,
        clearcoatRoughness: 0.1,
        transmission: trans || 0.35,
        opacity: isDark ? 0.92 : 0.82,
        transparent: true,
        reflectivity: 0.9
      });
    }

    // 1. PRIMARY GLOWING CORE SPHERE (Electric Blue) with Outer Wireframe Cage
    const coreGeo = new THREE.SphereGeometry(68, 48, 48);
    const coreMat = createMaterial(0x3B82F6, 0x1D4ED8, 0.3, 0.1, 0.3);
    const coreSphere = new THREE.Mesh(coreGeo, coreMat);
    coreSphere.position.set(-240, 80, -80);
    worldGroup.add(coreSphere);

    const cageGeo = new THREE.IcosahedronGeometry(82, 1);
    const cageMat = new THREE.MeshBasicMaterial({
      color: 0x60A5FA,
      wireframe: true,
      transparent: true,
      opacity: 0.25
    });
    const coreCage = new THREE.Mesh(cageGeo, cageMat);
    coreSphere.add(coreCage);
    interactiveObjects.push({ mesh: coreSphere, cage: coreCage, rx: 0.004, ry: 0.007, rz: 0.002, floatSpeed: 0.0012, amp: 22 });

    // 2. GOLDEN MARIGOLD SPHERE (Sunny Amber)
    const goldGeo = new THREE.SphereGeometry(46, 40, 40);
    const goldMat = createMaterial(0xFFD027, 0xF59E0B, 0.5, 0.15, 0.25);
    const goldSphere = new THREE.Mesh(goldGeo, goldMat);
    goldSphere.position.set(280, 130, -50);
    worldGroup.add(goldSphere);
    interactiveObjects.push({ mesh: goldSphere, rx: 0.006, ry: 0.005, rz: 0.003, floatSpeed: 0.0016, amp: 28 });

    // 3. CORAL PINK SATELLITE ORB
    const pinkGeo = new THREE.SphereGeometry(32, 32, 32);
    const pinkMat = createMaterial(0xF43F5E, 0xBE123C, 0.2, 0.12, 0.4);
    const pinkSphere = new THREE.Mesh(pinkGeo, pinkMat);
    pinkSphere.position.set(340, -110, -20);
    worldGroup.add(pinkSphere);
    interactiveObjects.push({ mesh: pinkSphere, rx: 0.008, ry: 0.009, rz: 0.004, floatSpeed: 0.002, amp: 20 });

    // 4. DEEP LAVENDER SPHERE
    const purpleGeo = new THREE.SphereGeometry(52, 36, 36);
    const purpleMat = createMaterial(0x8B5CF6, 0x6D28D9, 0.25, 0.15, 0.35);
    const purpleSphere = new THREE.Mesh(purpleGeo, purpleMat);
    purpleSphere.position.set(60, -200, -140);
    worldGroup.add(purpleSphere);
    interactiveObjects.push({ mesh: purpleSphere, rx: 0.005, ry: 0.006, rz: 0.002, floatSpeed: 0.0014, amp: 25 });

    // 5. GYROSCOPIC NESTED RINGS (Toruses) Around Core Sphere
    const ringOuterGeo = new THREE.TorusGeometry(110, 3.0, 16, 80);
    const ringOuterMat = new THREE.MeshStandardMaterial({
      color: 0x60A5FA,
      emissive: 0x2563EB,
      emissiveIntensity: 0.4,
      metalness: 0.8,
      roughness: 0.2,
      transparent: true,
      opacity: 0.75
    });
    const ringOuter = new THREE.Mesh(ringOuterGeo, ringOuterMat);
    coreSphere.add(ringOuter);

    const ringInnerGeo = new THREE.TorusGeometry(95, 2.4, 16, 70);
    const ringInnerMat = new THREE.MeshStandardMaterial({
      color: 0xA78BFA,
      emissive: 0x7C3AED,
      emissiveIntensity: 0.4,
      metalness: 0.8,
      roughness: 0.2,
      transparent: true,
      opacity: 0.65
    });
    const ringInner = new THREE.Mesh(ringInnerGeo, ringInnerMat);
    coreSphere.add(ringInner);

    // 6. 3D FLOATING CUBES (Hexahedrons with illuminated wireframes)
    const cubeData = [
      { size: 48, pos: [-360, -120, -90], color: 0x06B6D4, rx: 0.009, ry: 0.013, rz: 0.006, amp: 18 },
      { size: 36, pos: [160, -150, 40], color: 0x8B5CF6, rx: 0.012, ry: 0.008, rz: 0.01, amp: 24 },
      { size: 28, pos: [-110, 190, -40], color: 0xF43F5E, rx: 0.015, ry: 0.012, rz: 0.007, amp: 16 },
      { size: 24, pos: [380, 50, -110], color: 0xFFD027, rx: 0.011, ry: 0.014, rz: 0.009, amp: 20 },
      { size: 32, pos: [-40, -90, -180], color: 0x10B981, rx: 0.007, ry: 0.01, rz: 0.005, amp: 22 }
    ];

    cubeData.forEach(function (d) {
      const cGeo = new THREE.BoxGeometry(d.size, d.size, d.size);
      const cMat = createMaterial(d.color, d.color, 0.4, 0.2, 0.45);
      const cMesh = new THREE.Mesh(cGeo, cMat);
      cMesh.position.set(d.pos[0], d.pos[1], d.pos[2]);

      const eGeo = new THREE.EdgesGeometry(cGeo);
      const eMat = new THREE.LineBasicMaterial({
        color: d.color,
        transparent: true,
        opacity: isDark ? 0.75 : 0.55
      });
      const wire = new THREE.LineSegments(eGeo, eMat);
      cMesh.add(wire);

      worldGroup.add(cMesh);
      interactiveObjects.push({ mesh: cMesh, rx: d.rx, ry: d.ry, rz: d.rz, floatSpeed: 0.0015, amp: d.amp });
    });

    // 7. ABSTRACT TORUS KNOT (AI Neural Nexus)
    const knotGeo = new THREE.TorusKnotGeometry(42, 8.5, 120, 16, 2, 3);
    const knotMat = createMaterial(0xA78BFA, 0x8B5CF6, 0.7, 0.15, 0.25);
    const knotMesh = new THREE.Mesh(knotGeo, knotMat);
    knotMesh.position.set(220, -80, -130);
    worldGroup.add(knotMesh);
    interactiveObjects.push({ mesh: knotMesh, rx: 0.007, ry: 0.009, rz: 0.004, floatSpeed: 0.0013, amp: 25 });

    // 8. ABSTRACT 3D POLYHEDRONS (Icosahedrons & Octahedrons)
    const poly1Geo = new THREE.IcosahedronGeometry(36, 0);
    const poly1Mat = createMaterial(0xFB7185, 0xF43F5E, 0.5, 0.1, 0.35);
    const poly1 = new THREE.Mesh(poly1Geo, poly1Mat);
    poly1.position.set(380, 200, -160);
    worldGroup.add(poly1);
    interactiveObjects.push({ mesh: poly1, rx: 0.01, ry: 0.012, rz: 0.008, floatSpeed: 0.0018, amp: 20 });

    const poly2Geo = new THREE.OctahedronGeometry(32, 0);
    const poly2Mat = createMaterial(0x10B981, 0x059669, 0.6, 0.15, 0.3);
    const poly2 = new THREE.Mesh(poly2Geo, poly2Mat);
    poly2.position.set(-290, 190, -50);
    worldGroup.add(poly2);
    interactiveObjects.push({ mesh: poly2, rx: 0.012, ry: 0.008, rz: 0.011, floatSpeed: 0.0014, amp: 22 });

    // 9. 3D FLOATING PARTICLE CONSTELLATION (Deep Space Starfield)
    const particleCount = 180;
    const partGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);

    const paletteList = [
      new THREE.Color(0x3B82F6),
      new THREE.Color(0x8B5CF6),
      new THREE.Color(0xF43F5E),
      new THREE.Color(0xFFD027),
      new THREE.Color(0x10B981),
      new THREE.Color(0x06B6D4)
    ];

    for (let i = 0; i < particleCount; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 1400;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 1000;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 700 - 100;

      const c = paletteList[Math.floor(Math.random() * paletteList.length)];
      colors[i * 3] = c.r;
      colors[i * 3 + 1] = c.g;
      colors[i * 3 + 2] = c.b;
    }
    partGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    partGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const partMat = new THREE.PointsMaterial({
      size: 4.2,
      vertexColors: true,
      transparent: true,
      opacity: isDark ? 0.75 : 0.45,
      blending: THREE.AdditiveBlending
    });
    const particleSystem = new THREE.Points(partGeo, partMat);
    worldGroup.add(particleSystem);

    // Initial base positions for sine floating
    interactiveObjects.forEach(function (obj) {
      obj.baseY = obj.mesh.position.y;
      obj.baseX = obj.mesh.position.x;
      obj.phase = Math.random() * Math.PI * 2;
    });

    let animationFrameId = null;
    let clock = new THREE.Clock();

    function renderLoop() {
      if (document.hidden) {
        animationFrameId = requestAnimationFrame(renderLoop);
        return;
      }

      const time = clock.getElapsedTime();

      // Smooth mouse lerping
      mouse.x += (mouse.targetX - mouse.x) * 0.04;
      mouse.y += (mouse.targetY - mouse.y) * 0.04;

      // Camera gently rotates & tilts with mouse parallax
      camera.position.x = mouse.x * 75;
      camera.position.y = -mouse.y * 55;
      camera.lookAt(0, 0, 0);

      // World tilt
      worldGroup.rotation.y = mouse.x * 0.12;
      worldGroup.rotation.x = -mouse.y * 0.08;

      // Orbiting lights
      lightBlue.position.x = Math.sin(time * 0.6) * 450 - 150;
      lightBlue.position.y = Math.cos(time * 0.5) * 300 + 80;
      lightBlue.position.z = Math.sin(time * 0.4) * 200 + 50;

      lightPurple.position.x = Math.cos(time * 0.55) * 420 + 120;
      lightPurple.position.y = Math.sin(time * 0.45) * 320 - 50;

      lightPink.position.x = Math.sin(time * 0.7 + 1.5) * 380;
      lightPink.position.y = Math.cos(time * 0.65) * 250 - 100;

      lightAmber.position.x = Math.cos(time * 0.5 + 2.0) * 350;
      lightAmber.position.y = Math.sin(time * 0.6) * 280 + 100;

      // Animate core gyroscopic rings
      ringOuter.rotation.x += 0.015;
      ringOuter.rotation.y += 0.009;
      ringInner.rotation.y += 0.018;
      ringInner.rotation.z += 0.012;

      // Animate all interactive 3D solids
      interactiveObjects.forEach(function (obj) {
        obj.mesh.rotation.x += obj.rx;
        obj.mesh.rotation.y += obj.ry;
        obj.mesh.rotation.z += obj.rz;

        if (obj.cage) {
          obj.cage.rotation.x -= obj.rx * 1.5;
          obj.cage.rotation.y -= obj.ry * 1.5;
        }

        // Continuous organic levitation
        obj.mesh.position.y = obj.baseY + Math.sin(time * (obj.floatSpeed * 1000) + obj.phase) * obj.amp;
      });

      // Slowly rotate starfield
      particleSystem.rotation.y = time * 0.018;
      particleSystem.rotation.x = time * 0.008;

      renderer.render(scene, camera);
      animationFrameId = requestAnimationFrame(renderLoop);
    }

    function onResize() {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    }

    window.addEventListener('resize', onResize, { passive: true });
    renderLoop();

    return {
      type: 'threejs',
      onThemeChange: function (dark) {
        ambientLight.color.setHex(dark ? 0x1e1b4b : 0xe0e7ff);
        ambientLight.intensity = dark ? 1.2 : 1.5;
        dirLight.intensity = dark ? 0.8 : 1.3;
        partMat.opacity = dark ? 0.75 : 0.45;
      },
      destroy: function () {
        if (animationFrameId) cancelAnimationFrame(animationFrameId);
        window.removeEventListener('resize', onResize);
      }
    };
  }

  /* =========================================================================
   * ENGINE B: NATIVE HTML5 CANVAS 3D PERSPECTIVE ENGINE (Instant Fallback)
   * Real 3D Perspective Projection Matrix & Specular Lighting
   * ========================================================================= */
  function initNativeCanvas3DEngine(c) {
    const ctx = c.getContext('2d');
    let width = (c.width = window.innerWidth);
    let height = (c.height = window.innerHeight);

    function onResize() {
      width = c.width = window.innerWidth;
      height = c.height = window.innerHeight;
    }
    window.addEventListener('resize', onResize, { passive: true });

    // Mathematical 3D Vector Math
    function rotateX(v, a) {
      const cos = Math.cos(a), sin = Math.sin(a);
      return { x: v.x, y: v.y * cos - v.z * sin, z: v.y * sin + v.z * cos };
    }
    function rotateY(v, a) {
      const cos = Math.cos(a), sin = Math.sin(a);
      return { x: v.x * cos + v.z * sin, y: v.y, z: -v.x * sin + v.z * cos };
    }
    function rotateZ(v, a) {
      const cos = Math.cos(a), sin = Math.sin(a);
      return { x: v.x * cos - v.y * sin, y: v.x * sin + v.y * cos, z: v.z };
    }

    // 3D Objects Definition
    const objects = [
      // 1. Core Sphere (Electric Blue)
      { type: 'sphere', x: -220, y: 60, z: -80, radius: 64, color: PALETTE.electricBlue, lightColor: '#93C5FD', speed: 0.0015, amp: 22, rx: 0.01, ry: 0.015, rz: 0 },
      // 2. Sunny Amber Sphere
      { type: 'sphere', x: 260, y: 110, z: -50, radius: 44, color: PALETTE.goldenAmber, lightColor: '#FEF08A', speed: 0.0018, amp: 26, rx: 0.012, ry: 0.01, rz: 0 },
      // 3. Coral Pink Orb
      { type: 'sphere', x: 310, y: -90, z: -30, radius: 30, color: PALETTE.coralPink, lightColor: '#FECDD3', speed: 0.0022, amp: 18, rx: 0.015, ry: 0.012, rz: 0 },
      // 4. Lavender Sphere
      { type: 'sphere', x: 60, y: -170, z: -120, radius: 48, color: PALETTE.lavenderPurple, lightColor: '#DDD6FE', speed: 0.0014, amp: 24, rx: 0.008, ry: 0.011, rz: 0 },
      // 5. Nested Gyro Ring
      { type: 'ring', x: -220, y: 60, z: -80, radius: 98, innerRadius: 82, color: PALETTE.cyberCyan, rx: 0.02, ry: 0.014, rz: 0.008, speed: 0.0015, amp: 22 },
      { type: 'ring', x: -220, y: 60, z: -80, radius: 82, innerRadius: 70, color: PALETTE.lavenderLight, rx: 0.012, ry: 0.025, rz: 0.015, speed: 0.0015, amp: 22 },
      // 6. 3D Cubes
      { type: 'cube', x: -330, y: -110, z: -60, size: 44, color: PALETTE.cyberCyan, rx: 0.012, ry: 0.016, rz: 0.008, speed: 0.0017, amp: 16 },
      { type: 'cube', x: 150, y: -140, z: 30, size: 34, color: PALETTE.lavenderPurple, rx: 0.014, ry: 0.011, rz: 0.013, speed: 0.002, amp: 20 },
      { type: 'cube', x: -90, y: 170, z: -40, size: 28, color: PALETTE.coralPink, rx: 0.018, ry: 0.014, rz: 0.009, speed: 0.0016, amp: 15 },
      { type: 'cube', x: 350, y: 40, z: -90, size: 22, color: PALETTE.goldenAmber, rx: 0.013, ry: 0.017, rz: 0.01, speed: 0.0019, amp: 18 },
      // 7. 3D Icosahedron / Diamond Polyhedron
      { type: 'diamond', x: 340, y: 180, z: -140, size: 38, color: PALETTE.coralPinkLight, rx: 0.014, ry: 0.018, rz: 0.01, speed: 0.002, amp: 22 },
      { type: 'diamond', x: -270, y: 170, z: -40, size: 32, color: PALETTE.freshMint, rx: 0.016, ry: 0.012, rz: 0.014, speed: 0.0016, amp: 20 }
    ];

    objects.forEach(function (obj) {
      obj.baseY = obj.y;
      obj.rotX = Math.random() * Math.PI;
      obj.rotY = Math.random() * Math.PI;
      obj.rotZ = Math.random() * Math.PI;
      obj.phase = Math.random() * Math.PI * 2;
    });

    // 120 3D Starfield Particles
    const particles = [];
    for (let i = 0; i < 120; i++) {
      particles.push({
        x: (Math.random() - 0.5) * 1200,
        y: (Math.random() - 0.5) * 900,
        z: Math.random() * 500 - 250,
        size: Math.random() * 3.5 + 1.5,
        color: [PALETTE.electricBlue, PALETTE.lavenderPurple, PALETTE.coralPink, PALETTE.goldenAmber][i % 4],
        alpha: Math.random() * 0.6 + 0.2
      });
    }

    let animationFrameId = null;
    let t = 0;

    function renderLoop() {
      if (document.hidden) {
        animationFrameId = requestAnimationFrame(renderLoop);
        return;
      }

      t += 0.016;
      ctx.clearRect(0, 0, width, height);

      mouse.x += (mouse.targetX - mouse.x) * 0.04;
      mouse.y += (mouse.targetY - mouse.y) * 0.04;

      const fov = 650;
      const cx = width / 2 + mouse.x * 60;
      const cy = height / 2 - mouse.y * 45;

      // Render 3D Background Particles
      particles.forEach(function (p) {
        const pz = p.z + 400;
        if (pz <= 0) return;
        const scale = fov / (fov + pz);
        const px = cx + (p.x + mouse.x * 40) * scale;
        const py = cy + (p.y - mouse.y * 30) * scale;

        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.alpha * (isDark ? 0.75 : 0.45);
        ctx.beginPath();
        ctx.arc(px, py, p.size * scale, 0, Math.PI * 2);
        ctx.fill();
      });

      // Update object positions & depth sort
      objects.forEach(function (obj) {
        obj.y = obj.baseY + Math.sin(t * obj.speed * 100 + obj.phase) * obj.amp;
        obj.rotX += obj.rx;
        obj.rotY += obj.ry;
        obj.rotZ += obj.rz;

        // Apply mouse tilt to world coordinates
        const tilted = rotateY({ x: obj.x, y: obj.y, z: obj.z }, mouse.x * 0.18);
        obj.curX = tilted.x;
        obj.curY = tilted.y;
        obj.curZ = tilted.z;
      });

      // Painter's algorithm: Render from back to front
      const sorted = objects.slice().sort(function (a, b) {
        return a.curZ - b.curZ;
      });

      sorted.forEach(function (obj) {
        const depth = obj.curZ + 600;
        if (depth <= 10) return;
        const scale = fov / (fov + depth);
        const sx = cx + obj.curX * scale;
        const sy = cy + obj.curY * scale;

        ctx.save();
        ctx.translate(sx, sy);

        if (obj.type === 'sphere') {
          const r = obj.radius * scale;
          // 3D Specular Highlight Radial Gradient
          const grad = ctx.createRadialGradient(
            -r * 0.35 + mouse.x * r * 0.15,
            -r * 0.35 - mouse.y * r * 0.15,
            r * 0.05,
            0,
            0,
            r
          );
          grad.addColorStop(0, obj.lightColor);
          grad.addColorStop(0.3, obj.color);
          grad.addColorStop(0.85, isDark ? '#0F172A' : '#475569');
          grad.addColorStop(1, 'rgba(0,0,0,0.4)');

          ctx.fillStyle = grad;
          ctx.globalAlpha = isDark ? 0.92 : 0.82;
          ctx.beginPath();
          ctx.arc(0, 0, r, 0, Math.PI * 2);
          ctx.fill();

          // Outer atmospheric rim glow
          ctx.strokeStyle = obj.lightColor;
          ctx.lineWidth = 1.8 * scale;
          ctx.globalAlpha = isDark ? 0.4 : 0.25;
          ctx.stroke();

        } else if (obj.type === 'ring') {
          const r = obj.radius * scale;
          ctx.rotate(obj.rotZ + mouse.x * 0.3);
          ctx.scale(1, Math.abs(Math.sin(obj.rotX) * 0.7) + 0.3);

          ctx.strokeStyle = obj.color;
          ctx.lineWidth = 3.5 * scale;
          ctx.globalAlpha = isDark ? 0.75 : 0.55;
          ctx.beginPath();
          ctx.arc(0, 0, r, 0, Math.PI * 2);
          ctx.stroke();

        } else if (obj.type === 'cube') {
          // Render True 3D Cube with 8 Vertices
          const s = obj.size * scale;
          const verts = [
            { x: -s, y: -s, z: -s }, { x: s, y: -s, z: -s },
            { x: s, y: s, z: -s }, { x: -s, y: s, z: -s },
            { x: -s, y: -s, z: s }, { x: s, y: -s, z: s },
            { x: s, y: s, z: s }, { x: -s, y: s, z: s }
          ];

          // Rotate vertices around 3D axes
          const rotVerts = verts.map(function (v) {
            let r = rotateX(v, obj.rotX);
            r = rotateY(r, obj.rotY + mouse.x * 0.5);
            r = rotateZ(r, obj.rotZ);
            return r;
          });

          // Cube 6 Faces
          const faces = [
            [0, 1, 2, 3], // Front
            [5, 4, 7, 6], // Back
            [4, 0, 3, 7], // Left
            [1, 5, 6, 2], // Right
            [4, 5, 1, 0], // Top
            [3, 2, 6, 7]  // Bottom
          ];

          // Draw translucent faces
          ctx.fillStyle = obj.color;
          ctx.globalAlpha = isDark ? 0.35 : 0.22;
          ctx.strokeStyle = obj.color;
          ctx.lineWidth = 1.8 * scale;

          faces.forEach(function (f) {
            ctx.beginPath();
            ctx.moveTo(rotVerts[f[0]].x, rotVerts[f[0]].y);
            ctx.lineTo(rotVerts[f[1]].x, rotVerts[f[1]].y);
            ctx.lineTo(rotVerts[f[2]].x, rotVerts[f[2]].y);
            ctx.lineTo(rotVerts[f[3]].x, rotVerts[f[3]].y);
            ctx.closePath();
            ctx.fill();
            ctx.globalAlpha = isDark ? 0.8 : 0.6;
            ctx.stroke();
            ctx.globalAlpha = isDark ? 0.35 : 0.22;
          });

        } else if (obj.type === 'diamond') {
          // 3D Octahedron / Diamond
          const s = obj.size * scale;
          const dVerts = [
            { x: 0, y: -s * 1.3, z: 0 },
            { x: s, y: 0, z: 0 },
            { x: 0, y: 0, z: s },
            { x: -s, y: 0, z: 0 },
            { x: 0, y: 0, z: -s },
            { x: 0, y: s * 1.3, z: 0 }
          ];
          const rotD = dVerts.map(function (v) {
            let r = rotateX(v, obj.rotX);
            r = rotateY(r, obj.rotY + mouse.x * 0.4);
            r = rotateZ(r, obj.rotZ);
            return r;
          });

          ctx.fillStyle = obj.color;
          ctx.globalAlpha = isDark ? 0.38 : 0.25;
          ctx.strokeStyle = obj.color;
          ctx.lineWidth = 1.8 * scale;

          const dFaces = [
            [0, 1, 2], [0, 2, 3], [0, 3, 4], [0, 4, 1],
            [5, 2, 1], [5, 3, 2], [5, 4, 3], [5, 1, 4]
          ];
          dFaces.forEach(function (f) {
            ctx.beginPath();
            ctx.moveTo(rotD[f[0]].x, rotD[f[0]].y);
            ctx.lineTo(rotD[f[1]].x, rotD[f[1]].y);
            ctx.lineTo(rotD[f[2]].x, rotD[f[2]].y);
            ctx.closePath();
            ctx.fill();
            ctx.globalAlpha = isDark ? 0.75 : 0.5;
            ctx.stroke();
            ctx.globalAlpha = isDark ? 0.38 : 0.25;
          });
        }

        ctx.restore();
      });

      ctx.globalAlpha = 1.0;
      animationFrameId = requestAnimationFrame(renderLoop);
    }

    renderLoop();

    return {
      type: 'canvas3d',
      onThemeChange: function (dark) {
        // Automatically handled by isDark check in render loop
      },
      destroy: function () {
        if (animationFrameId) cancelAnimationFrame(animationFrameId);
        window.removeEventListener('resize', onResize);
      }
    };
  }

  /* =========================================================================
   * SYSTEM BOOTSTRAPPER & ENGINE SELECTOR
   * ========================================================================= */
  function start3DBackground() {
    canvas = document.getElementById('bg3d-canvas');
    if (!canvas) {
      console.warn('[HA UIEN 3D] Canvas #bg3d-canvas not found, retrying...');
      setTimeout(start3DBackground, 100);
      return;
    }

    setupMouseTracking();

    // Check if Three.js is loaded
    if (typeof window.THREE !== 'undefined') {
      try {
        activeEngine = initThreeJsEngine(canvas);
        console.log('[HA UIEN 3D] Active Engine: Three.js WebGL 3D Interactive Space.');
        return;
      } catch (err) {
        console.warn('[HA UIEN 3D] WebGL Three.js init failed, falling back to Native 3D Canvas:', err);
      }
    }

    // High performance instant fallback
    activeEngine = initNativeCanvas3DEngine(canvas);
    console.log('[HA UIEN 3D] Active Engine: High-Performance Native 3D Canvas Perspective.');

    // If Three.js script was loading asynchronously, upgrade when available
    let checkCount = 0;
    const upgradeTimer = setInterval(function () {
      checkCount++;
      if (typeof window.THREE !== 'undefined' && activeEngine && activeEngine.type !== 'threejs') {
        clearInterval(upgradeTimer);
        activeEngine.destroy();
        try {
          activeEngine = initThreeJsEngine(canvas);
          console.log('[HA UIEN 3D] Upgraded to Three.js WebGL 3D Interactive Space.');
        } catch (e) {
          activeEngine = initNativeCanvas3DEngine(canvas);
        }
      } else if (checkCount > 30) {
        clearInterval(upgradeTimer);
      }
    }, 200);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start3DBackground);
  } else {
    start3DBackground();
  }
})();

