﻿/**
 * HA UIEN SYSTEMS - ENTERPRISE MANAGEMENT ECOSYSTEM
 * Comprehensive 10-Module Operating Suite with Real Interactive CRUD, Charts, Search, Filter & 7-Part User Guides
 * 
 * Modules:
 *  1. Executive Dashboard (Tổng quan Điều hành)
 *  2. Human Resources Management (Quản trị Nhân sự & Headcount)
 *  3. Finance Management (Quản trị Tài chính & Dòng tiền)
 *  4. CRM & Partner Network (Quản trị Khách hàng & Đối tác 3 Khu vực)
 *  5. Project Management (Quản lý Dự án & Tiến độ SLA)
 *  6. Business Operations (Vận hành Doanh nghiệp & Điểm bán 3km)
 *  7. AI Data Analytics (Phân tích Dữ liệu BI & 5 Bước Thẩm định AI)
 *  8. Document Management (Quản lý Hồ sơ & Tài liệu Pháp lý)
 *  9. Internal Communication (Truyền thông Nội bộ & Trợ lý Chat AI)
 * 10. System Administration (Quản trị Hệ thống, Phân quyền & Audit Logs)
 * 
 * Brand Identity: HA UIEN SYSTEMS (New York, Mỹ)
 * Theme: Dark (#080C16, #0F1629, #1F2943) & Light (#F8FAFC, #FFFFFF, #E2E8F0)
 * Accents: Lemon (#FFD027), Mint (#10B981), Grape (#8B5CF6), Rose (#F43F5E), Sky (#38BDF8)
 */

const EnterpriseEcosystem = (() => {
  "use strict";

  // Storage Keys
  const STORAGE_KEY = "HA_UIEN_ENTERPRISE_DATA_V2";
  const DATA_LOADED_KEY = "HA_UIEN_ECOSYSTEM_DATA_LOADED";

  // Default Seed Data
  const DEFAULT_DATA = {
    hr: [
      { id: "NV-001", name: "Bùi Hà Uyên", role: "Tổng Giám Đốc Điều Hành (CEO)", dept: "Ban Giám Đốc", region: "Toàn Quốc", phone: "0816710189", email: "buihauyen121007@gmail.com", salary: 85000000, kpi: 98, status: "Chính thức", joinDate: "2022-01-15" },
      { id: "NV-002", name: "Trần Minh Quân", role: "Trưởng phòng Phát triển Kinh doanh", dept: "Phát triển Kinh doanh", region: "Miền Bắc (KV1)", phone: "0912345671", email: "quan.tm@hauien.com", salary: 45000000, kpi: 94, status: "Chính thức", joinDate: "2022-06-10" },
      { id: "NV-003", name: "Lê Hoàng Yến", role: "Kế Toán Trưởng", dept: "Tài chính - Kế toán", region: "Toàn Quốc", phone: "0912345672", email: "yen.lh@hauien.com", salary: 42000000, kpi: 96, status: "Chính thức", joinDate: "2022-03-01" },
      { id: "NV-004", name: "Phạm Hải Đăng", role: "Giám Đốc Vùng Miền Trung", dept: "Phát triển Kinh doanh", region: "Miền Trung (KV2)", phone: "0912345673", email: "dang.ph@hauien.com", salary: 38000000, kpi: 91, status: "Chính thức", joinDate: "2023-02-15" },
      { id: "NV-005", name: "Nguyễn Vũ Thắng", role: "Giám Đốc Vùng Miền Nam", dept: "Phát triển Kinh doanh", region: "Miền Nam (KV3)", phone: "0912345674", email: "thang.nv@hauien.com", salary: 40000000, kpi: 93, status: "Chính thức", joinDate: "2023-01-20" },
      { id: "NV-006", name: "Đỗ Thùy Linh", role: "Chuyên viên Phân tích BI (Data Analyst)", dept: "Khối Công nghệ & BI", region: "Toàn Quốc", phone: "0912345675", email: "linh.dt@hauien.com", salary: 28000000, kpi: 95, status: "Chính thức", joinDate: "2023-08-01" },
      { id: "NV-007", name: "Vũ Quốc Hưng", role: "Trưởng phòng Kỹ thuật & Bảo hành", dept: "Kỹ thuật & Dịch vụ", region: "Miền Bắc (KV1)", phone: "0912345676", email: "hung.vq@hauien.com", salary: 32000000, kpi: 89, status: "Chính thức", joinDate: "2022-11-15" },
      { id: "NV-008", name: "Hoàng Nhật Nam", role: "Chuyên viên Pháp chế & Thẩm định", dept: "Pháp chế & Rủi ro", region: "Toàn Quốc", phone: "0912345677", email: "nam.hn@hauien.com", salary: 25000000, kpi: 92, status: "Chính thức", joinDate: "2024-02-01" }
    ],
    finance: [
      { id: "TC-101", type: "THU", partner: "Công ty CP Điện máy Á Châu (Hà Nội)", amount: 1250000000, category: "Doanh thu đại lý", dept: "Phát triển Kinh doanh", date: "2026-11-15", status: "Đã khớp lệnh", approver: "Lê Hoàng Yến" },
      { id: "TC-102", type: "CHI", partner: "Nhà cung cấp Linh kiện New York", amount: 680000000, category: "Nhập hàng linh kiện", dept: "Chuỗi Cung Ứng", date: "2026-11-14", status: "Đã giải ngân", approver: "Bùi Hà Uyên" },
      { id: "TC-103", type: "THU", partner: "Công ty TNHH Thương mại Phú Quý (Đà Nẵng)", amount: 890000000, category: "Doanh thu đại lý", dept: "Phát triển Kinh doanh", date: "2026-11-12", status: "Đã khớp lệnh", approver: "Lê Hoàng Yến" },
      { id: "TC-104", type: "CHI", partner: "Trung tâm Logistics Tân Cảng", amount: 145000000, category: "Chi phí vận chuyển & kho bãi", dept: "Vận hành", date: "2026-11-11", status: "Đã giải ngân", approver: "Lê Hoàng Yến" },
      { id: "TC-105", type: "THU", partner: "Công ty TNHH Bách Khoa SG", amount: 1540000000, category: "Doanh thu đại lý", dept: "Phát triển Kinh doanh", date: "2026-11-10", status: "Đã khớp lệnh", approver: "Lê Hoàng Yến" },
      { id: "TC-106", type: "CHI", partner: "Cloudflare & AWS US Hosting", amount: 62000000, category: "Hạ tầng Cloud BI", dept: "Khối Công nghệ & BI", date: "2026-11-08", status: "Đã giải ngân", approver: "Bùi Hà Uyên" },
      { id: "TC-107", type: "TÍN DỤNG", partner: "Đại lý Nam Định (Đang chờ ký)", amount: 300000000, category: "Bảo lãnh hạn mức công nợ", dept: "Pháp chế & Rủi ro", date: "2026-11-05", status: "Chờ phê duyệt", approver: "Trần Minh Quân" }
    ],
    crm: [
      { id: "DL-001", name: "Công ty CP Thương mại & Đầu tư Á Châu", rep: "Nguyễn Văn An", phone: "0903112233", email: "contact@achau.com.vn", region: "Miền Bắc (KV1)", tier: "Tier 1", creditLimit: 500000000, qtrSales: 1850000000, status: "Đang hợp tác", rating: "Xuất sắc" },
      { id: "DL-002", name: "Công ty TNHH Thiết bị Gia dụng Phú Quý", rep: "Trần Thị Mai", phone: "0904223344", email: "phuquy.dn@gmail.com", region: "Miền Trung (KV2)", tier: "Tier 1", creditLimit: 400000000, qtrSales: 1420000000, status: "Đang hợp tác", rating: "Xuất sắc" },
      { id: "DL-003", name: "Công ty CP Đầu tư Nam Phát Group", rep: "Lê Hoàng Nam", phone: "0905334455", email: "info@namphatgroup.vn", region: "Miền Nam (KV3)", tier: "Tier 1", creditLimit: 500000000, qtrSales: 2100000000, status: "Đang hợp tác", rating: "Xuất sắc" },
      { id: "DL-004", name: "Đại lý Thiết bị Điện máy Sao Mai", rep: "Phạm Quốc Bảo", phone: "0906445566", email: "saomai.elect@gmail.com", region: "Miền Bắc (KV1)", tier: "Tier 2", creditLimit: 200000000, qtrSales: 680000000, status: "Cần bổ sung", rating: "Đạt chuẩn" },
      { id: "DL-005", name: "Công ty TNHH MTV Thành Vinh", rep: "Đặng Hữu Phước", phone: "0907556677", email: "thanhvinh.na@gmail.com", region: "Miền Trung (KV2)", tier: "Tier 2", creditLimit: 200000000, qtrSales: 750000000, status: "Cần bổ sung", rating: "Đạt chuẩn" },
      { id: "DL-006", name: "Công ty CP Dịch vụ Công nghệ Toàn Cầu", rep: "Hoàng Văn Tuấn", phone: "0908667788", email: "toancau.tech@gmail.com", region: "Miền Bắc (KV1)", tier: "Tier 3", creditLimit: 0, qtrSales: 0, status: "Từ chối (Nợ xấu)", rating: "Không đạt" }
    ],
    project: [
      { id: "DA-01", name: "Mở rộng 15 Điểm bán Miền Bắc Q4/2026", pm: "Trần Minh Quân", dept: "Phát triển Kinh doanh", budget: 3500000000, startDate: "2026-10-01", dueDate: "2026-12-31", progress: 85, priority: "Khẩn cấp", status: "Đang thực hiện" },
      { id: "DA-02", name: "Nâng cấp Hệ thống BI Agent v2.5", pm: "Đỗ Thùy Linh", dept: "Khối Công nghệ & BI", budget: 1200000000, startDate: "2026-09-15", dueDate: "2026-11-30", progress: 95, priority: "Cao", status: "Đang kiểm thử" },
      { id: "DA-03", name: "Setup 3 Trạm Bảo Hành Chính Hãng Miền Trung", pm: "Vũ Quốc Hưng", dept: "Kỹ thuật & Dịch vụ", budget: 850000000, startDate: "2026-10-15", dueDate: "2026-12-15", progress: 70, priority: "Trung bình", status: "Đang thực hiện" },
      { id: "DA-04", name: "Triển khai Chính sách Hạn mức Tín dụng Mới", pm: "Lê Hoàng Yến", dept: "Tài chính - Kế toán", budget: 450000000, startDate: "2026-11-01", dueDate: "2026-12-20", progress: 60, priority: "Cao", status: "Đang thực hiện" },
      { id: "DA-05", name: "Thẩm định Bán kính 3km Mạng lưới Showroom KV3", pm: "Nguyễn Vũ Thắng", dept: "Phát triển Kinh doanh", budget: 620000000, startDate: "2026-10-20", dueDate: "2026-11-25", progress: 90, priority: "Khẩn cấp", status: "Đang thực hiện" }
    ],
    operations: [
      { id: "OP-01", name: "Showroom Trung tâm Hà Nội (Cầu Giấy)", address: "Số 18 Duy Tân, Cầu Giấy, Hà Nội", region: "Miền Bắc (KV1)", area: 240, compliance: "100% Đạt (>3.2km)", manager: "Trần Minh Quân", status: "Hoạt động xuất sắc" },
      { id: "OP-02", name: "Kho Tổng Phân Phối Gia Lâm", address: "Khu công nghiệp Đài Tư, Long Biên, Hà Nội", region: "Miền Bắc (KV1)", area: 1850, compliance: "Kho vận trung chuyển", manager: "Nguyễn Văn Hùng", status: "Hoạt động xuất sắc" },
      { id: "OP-03", name: "Showroom Trung tâm Đà Nẵng", address: "450 Nguyễn Văn Linh, Thanh Khê, Đà Nẵng", region: "Miền Trung (KV2)", area: 180, compliance: "100% Đạt (>4.5km)", manager: "Phạm Hải Đăng", status: "Hoạt động tốt" },
      { id: "OP-04", name: "Showroom Quận 1 TP. Hồ Chí Minh", address: "128 Nguyễn Thị Minh Khai, Quận 1, TP.HCM", region: "Miền Nam (KV3)", area: 310, compliance: "100% Đạt (>5.0km)", manager: "Nguyễn Vũ Thắng", status: "Hoạt động xuất sắc" },
      { id: "OP-05", name: "Showroom Tân Bình (Điểm thử nghiệm)", address: "35 Cộng Hòa, Tân Bình, TP.HCM", region: "Miền Nam (KV3)", area: 110, compliance: "Cảnh báo 2.8km (HITL)", manager: "Lê Đức Tài", status: "Cần phê duyệt ngoại lệ" }
    ],
    documents: [
      { id: "TL-01", title: "Quy chế Quản lý & Cấp Hạn mức Tín dụng Đại lý 2026", type: "Quy chế quản trị", issueDate: "2026-01-10", author: "Lê Hoàng Yến", security: "Nội bộ", size: "2.4 MB", status: "Hiệu lực" },
      { id: "TL-02", title: "Quy chuẩn Bán kính Bảo hộ 3km & Thẩm định Showroom", type: "Quy định nghiệp vụ", issueDate: "2026-02-15", author: "Trần Minh Quân", security: "Nội bộ", size: "1.8 MB", status: "Hiệu lực" },
      { id: "TL-03", title: "Hợp đồng Nguyên tắc Phân phối Độc quyền (Mẫu Tier 1)", type: "Hợp đồng mẫu", issueDate: "2026-03-01", author: "Hoàng Nhật Nam", security: "Tuyệt mật", size: "3.5 MB", status: "Hiệu lực" },
      { id: "TL-04", title: "Báo cáo Toàn diện Thẩm định Dữ liệu BI - HA UIEN SYSTEMS", type: "Báo cáo điều hành", issueDate: "2026-11-18", author: "Trí tuệ nhân tạo Ha Uien", security: "Lưu hành nội bộ", size: "4.1 MB", status: "Đã ký duyệt" }
    ],
    communication: [
      { id: "TB-01", title: "Thông báo Kết quả Thẩm định Đối tác Đợt 4 Toàn Quốc", author: "Ban Giám Đốc", target: "Toàn thể CBNV & Các Giám đốc Vùng", date: "2026-11-18", urgency: "Hỏa tốc", content: "Ban Giám Đốc chính thức thông qua danh sách đối tác Tier 1 đạt chuẩn ký kết hợp đồng phân phối. Các trường hợp Escalation cần hoàn thiện biên bản thẩm định thực địa trước ngày 25/11." },
      { id: "TB-02", title: "Phổ biến Quy trình 5 Bước Phân tích Dữ liệu Chuẩn BI", author: "Khối Công nghệ & BI", target: "Phòng PTKD & Tài chính", date: "2026-11-15", urgency: "Bình thường", content: "Toàn bộ dữ liệu hồ sơ mới bắt buộc xử lý qua Agent Trí tuệ nhân tạo Ha Uien theo đủ 5 bước: Khai thác, Kiểm tra lỗi, Kết quả AI, Đánh giá người dùng và Xuất báo cáo." },
      { id: "TB-03", title: "Kế hoạch Kiểm định Định kỳ Trạm Bảo Hành KV2 & KV3", author: "Phòng Kỹ thuật & Dịch vụ", target: "Trạm bảo hành ủy quyền", date: "2026-11-10", urgency: "Quan trọng", content: "Đoàn kỹ thuật viên của HA UIEN SYSTEMS sẽ tiến hành kiểm tra năng lực mặt bằng và bàn giao linh kiện chính hãng đợt cuối năm 2026." }
    ],
    admin: [
      { time: "2026-11-18 08:05:42", user: "Bùi Hà Uyên (CEO)", ip: "127.0.0.1 (Localhost)", module: "AI Analytics", action: "Ký duyệt Báo cáo Thẩm định (Executive Sign-off)", level: "INFO" },
      { time: "2026-11-18 07:58:19", user: "Trần Minh Quân (PTKD)", ip: "192.168.1.45", module: "CRM", action: "Cập nhật Phân hạng Tier 1 cho Đại lý Á Châu", level: "INFO" },
      { time: "2026-11-18 07:42:10", user: "Lê Hoàng Yến (Kế toán)", ip: "192.168.1.12", module: "Finance", action: "Duyệt lệnh thu tiền đợt 4 (1.25 tỷ VNĐ)", level: "SUCCESS" },
      { time: "2026-11-18 06:30:00", user: "Hệ thống Tự Động (Auto BI)", ip: "127.0.0.1", module: "System", action: "Sao lưu cơ sở dữ liệu định kỳ an toàn", level: "SYSTEM" },
      { time: "2026-11-17 19:15:33", user: "Vũ Quốc Hưng (Kỹ thuật)", ip: "192.168.1.78", module: "Operations", action: "Kiểm tra tọa độ GPS showroom 2.8km", level: "WARNING" }
    ]
  };

  // State in Memory
  let state = {
    activeModule: "executive",
    data: null,
    isDataLoaded: false,
    searchQuery: "",
    filterValue: "ALL",
    editingRecordId: null,
    deletingRecordId: null,
    chartInstances: {}
  };

  // 7-Part User Guide Knowledge Base for all 10 modules
  const USER_GUIDES = {
    executive: {
      title: "Hệ Thống Tổng Quan Điều Hành (Executive Dashboard)",
      icon: "🏢",
      part1: "Phân hệ Tổng quan Điều hành (Executive Dashboard) đóng vai trò trung tâm điều khiển chiến lược của HA UIEN SYSTEMS. Hệ thống tổng hợp các chỉ số cốt lõi từ 9 phân hệ chức năng: Doanh thu, Chi phí, Biên lợi nhuận, Định biên nhân sự, Tỷ lệ hoàn thành dự án và Sức khỏe mạng lưới đối tác.",
      part2: "Cần đảm bảo các phân hệ con (Tài chính, Kinh doanh, Nhân sự) đã cập nhật số liệu trong kỳ. Người dùng cấp quản lý hoặc Ban Giám Đốc đăng nhập vào hệ thống để có quyền xem toàn cảnh số liệu hợp nhất.",
      part3: "1. Chọn phân hệ 'Executive Dashboard' từ menu điều hướng hoặc thanh chọn phân hệ.\n2. Quan sát 6 thẻ KPI tổng quan (Doanh thu, Chi phí, Lợi nhuận, Nhân sự, Đối tác, Dự án).\n3. Tương tác với các biểu đồ phân tích xu hướng 6 tháng và cơ cấu chi phí.\n4. Rà soát danh sách công việc cần xử lý gấp và bảng tin cảnh báo rủi ro tức thời.",
      part4: "• Doanh thu luỹ kế: Tổng dòng tiền đã thu hợp lệ trong kỳ (VNĐ).\n• Lợi nhuận ròng: Doanh thu trừ chi phí vận hành (VNĐ & biên %).\n• Headcount: Tổng số nhân sự hiện diện so với định biên.\n• Health Index: Chỉ số sức khỏe dự án & rủi ro bán kính bảo hộ.",
      part5: "Sau khi xem xét nhận định, Ban Lãnh đạo có thể bấm trực tiếp vào từng thẻ KPI hoặc bảng công việc để điều hướng tới phân hệ tương ứng xử lý nghiệp vụ cụ thể.",
      part6: "Q: Số liệu Dashboard cập nhật bao lâu một lần?\nA: Hệ thống đồng bộ tức thì (Real-time Localhost) mỗi khi có giao dịch tài chính, hồ sơ nhân sự hoặc phân tích BI mới.\nQ: Tôi có thể xuất báo cáo điều hành không?\nA: Bấm nút 'Xuất Excel / Báo cáo' ở góc trên bên phải để tải file thống kê tổng hợp.",
      part7: "Nếu số liệu không hiển thị, vui lòng bấm nút 'Đồng bộ Dữ liệu' hoặc kiểm tra kết nối máy chủ Localhost tại cổng 8080. Đảm bảo trình duyệt không chặn JavaScript."
    },
    hr: {
      title: "Hệ Thống Quản Trị Nhân Sự (Human Resources Management - HRM)",
      icon: "👥",
      part1: "Quản trị toàn diện vòng đời nhân sự tại HA UIEN SYSTEMS từ tuyển dụng, quản lý hồ sơ, định biên 3 khu vực (Bắc, Trung, Nam), đánh giá KPI định kỳ đến mức lương và chế độ đãi ngộ.",
      part2: "Chuẩn bị thông tin cá nhân nhân viên, phòng ban phân bổ, chức danh, mức lương cơ bản và tài liệu hợp đồng lao động.",
      part3: "1. Bấm '+ Thêm Nhân Viên Mới' để mở biểu mẫu nhập liệu.\n2. Điền đầy đủ Mã NV, Họ tên, Phòng ban, Khu vực, Mức lương, KPI.\n3. Bấm 'Lưu Dữ Liệu' để ghi nhận vào hệ thống.\n4. Tìm kiếm nhân viên bằng thanh gõ hoặc lọc theo phòng ban / khu vực.\n5. Bấm '👁️ Chi Tiết' để xem hồ sơ hoặc '✏️ Sửa' / '🗑️ Xóa' khi có biến động.",
      part4: "• Mã NV: Định danh duy nhất (VD: NV-001).\n• Phòng ban: Ban Giám Đốc, PTKD, Kế toán, Công nghệ & BI, Kỹ thuật.\n• KPI Score: Điểm hiệu suất từ 0 - 100 điểm.\n• Trạng thái: Chính thức, Thử việc, Đã nghỉ việc.",
      part5: "Nhân viên mới sẽ xuất hiện ngay trong bảng danh sách, biểu đồ định biên phòng ban tự động cập nhật và số lượng tổng nhân sự trên Executive Dashboard được đồng bộ.",
      part6: "Q: Có thể sửa mức lương nhân viên không?\nA: Có, cán bộ có thẩm quyền chỉ cần bấm nút '✏️ Sửa' trên dòng nhân viên đó.\nQ: Xóa nhân viên có làm mất dữ liệu lịch sử không?\nA: Hệ thống yêu cầu xác nhận trước khi xóa và tự động lưu vào Audit Log.",
      part7: "Nếu phát hiện nhập sai định dạng email hoặc số điện thoại, hệ thống sẽ cảnh báo bằng thông báo đỏ. Vui lòng kiểm tra lại số ký tự hợp lệ."
    },
    finance: {
      title: "Hệ Thống Quản Lý Tài Chính & Kế Toán (Finance & Cashflow)",
      icon: "💰",
      part1: "Theo dõi dòng tiền thu chi, quản lý công nợ đại lý 3 khu vực, giám sát trần hạn mức tín dụng và báo cáo ngân sách tự động cho HA UIEN SYSTEMS.",
      part2: "Chuẩn bị chứng từ thu/chi hợp lệ, tên đối tác nhận/thanh toán, hợp đồng nguyên tắc hoặc đề xuất giải ngân đã được ký duyệt.",
      part3: "1. Bấm '+ Thêm Giao Dịch Thu / Chi'.\n2. Chọn loại giao dịch (THU / CHI / TÍN DỤNG), số tiền, đối tác, hạng mục chi phí.\n3. Ghi rõ người duyệt và ngày hạch toán.\n4. Bấm 'Lưu Giao Dịch'. Hệ thống tự tính lại quỹ tiền mặt và biểu đồ doanh thu.",
      part4: "• Loại: THU (tiền vào), CHI (tiền ra), TÍN DỤNG (hạn mức bảo lãnh).\n• Số tiền: Định dạng chuẩn Việt Nam Đồng (VNĐ).\n• Hạng mục: Doanh thu đại lý, Nhập linh kiện, Logistics, Hạ tầng Cloud, v.v.\n• Trạng thái: Đã khớp lệnh, Đã giải ngân, Chờ phê duyệt.",
      part5: "Số dư khả dụng và biên lợi nhuận trên toàn hệ thống sẽ được tính toán lại ngay lập tức. Bút toán được niêm phong vào sổ cái tài chính.",
      part6: "Q: Trần hạn mức công nợ tối đa là bao nhiêu?\nA: Theo chính sách HA UIEN SYSTEMS, đại lý Tier 1 tối đa 500 triệu VNĐ, Tier 2 tối đa 200 triệu VNĐ.\nQ: Tôi có thể lọc riêng các lệnh Thu không?\nA: Chọn 'Lọc: Thu' từ hộp chọn bộ lọc phía trên bảng.",
      part7: "Lỗi cảnh báo vượt trần công nợ: Nếu số tiền tín dụng vượt quá 500 triệu VNĐ, hệ thống yêu cầu có phê duyệt ngoại lệ của Giám đốc Tài chính."
    },
    crm: {
      title: "Hệ Thống Quản Trị Quan Hệ Khách Hàng & Đối Tác (CRM)",
      icon: "🤝",
      part1: "Quản trị danh bạ 360 độ mạng lưới đối tác phân phối, đại lý Cấp 1, Cấp 2 tại 3 khu vực (Miền Bắc, Miền Trung, Miền Nam), theo dõi doanh số mua hàng và phân hạng đối tác Tier 1 / 2 / 3.",
      part2: "Thu thập hồ sơ pháp nhân đại lý: Tên doanh nghiệp, Người đại diện pháp luật, Mã số thuế, SĐT, Địa chỉ điểm bán và doanh số cam kết.",
      part3: "1. Bấm '+ Thêm Khách Hàng / Đối Tác'.\n2. Nhập thông tin liên hệ, chọn khu vực phân bổ và phân hạng Tier.\n3. Thiết lập trần hạn mức tín dụng đề xuất.\n4. Theo dõi doanh số quý và lịch sử công nợ trên bảng tương tác.",
      part4: "• Phân hạng Tier: Tier 1 (Đối tác chiến lược ≥80đ), Tier 2 (Cần bổ sung 65-79đ), Tier 3 (Loại trừ <65đ).\n• Hạn mức: Mức tín dụng nợ gối đầu được cấp (VNĐ).\n• Đánh giá: Xuất sắc, Đạt chuẩn, Cần giám sát.",
      part5: "Đối tác được phân loại tự động vào các chiến dịch hỗ trợ bán hàng, cấp tài liệu kỹ thuật và mã bảo hành chính hãng tương ứng.",
      part6: "Q: Làm thế nào để nâng hạng từ Tier 2 lên Tier 1?\nA: Khi đối tác hoàn thiện showroom đạt chuẩn diện tích và duy trì doanh số 3 tháng liên tiếp, vào sửa thông tin và chọn Tier 1.\nQ: Bảng có cho phép tìm kiếm theo số điện thoại không?\nA: Có, ô tìm kiếm hỗ trợ tra cứu theo tên, SĐT, mã đối tác và khu vực.",
      part7: "Lỗi trùng lặp đối tác: Nếu mã số thuế hoặc tên trùng với hồ sơ nợ xấu trong sổ đen, hệ thống sẽ bật cảnh báo đỏ Knockout."
    },
    project: {
      title: "Hệ Thống Quản Lý Dự Án & Tiến Độ (Project Management)",
      icon: "🚀",
      part1: "Theo dõi toàn bộ các dự án mở rộng mạng lưới, nâng cấp công nghệ BI, thiết lập trạm bảo hành và kiểm tra bán kính bảo hộ của HA UIEN SYSTEMS theo chuẩn tiến độ SLA.",
      part2: "Xác định rõ Trưởng dự án (Project Manager), phòng ban chủ trì, ngân sách phân bổ, ngày khởi công và mốc bàn giao dự kiến.",
      part3: "1. Bấm '+ Khởi Tạo Dự Án Mới'.\n2. Điền tên dự án, PM phụ trách, ngân sách và thời hạn hoàn thành.\n3. Chọn mức độ ưu tiên (Khẩn cấp, Cao, Trung bình).\n4. Cập nhật thanh tiến độ % định kỳ để hệ thống đo lường hiệu suất.",
      part4: "• Tiến độ (%): Tỷ lệ hoàn thành công việc từ 0% đến 100%.\n• Ưu tiên: Khẩn cấp (Cần xử lý ngay), Cao, Trung bình.\n• Trạng thái: Đang thực hiện, Đang kiểm thử, Đã nghiệm thu, Tạm dừng.",
      part5: "Biểu đồ tiến độ dự án trên Dashboard sẽ hiển thị thanh đo trực quan, cảnh báo các dự án có nguy cơ trễ hạn (chậm so với deadline).",
      part6: "Q: Dự án nào được đánh dấu là 'Khẩn cấp'?\nA: Các dự án mở rộng mạng lưới phân phối trọng điểm hoặc xử lý xung đột cự ly bảo hộ 3km.\nQ: Tôi có thể lọc dự án theo phòng ban không?\nA: Có, chọn phòng ban từ danh sách lọc.",
      part7: "Lỗi quá hạn (Overdue): Dự án có tiến độ <100% khi đã qua ngày bàn giao sẽ tự động chuyển màu đỏ cảnh báo."
    },
    operations: {
      title: "Hệ Thống Vận Hành Doanh Nghiệp & Chuỗi Cung Ứng (Operations)",
      icon: "⚙️",
      part1: "Quản lý hệ thống kho bãi trung chuyển, mạng lưới showroom trưng bày thực tế, năng lực vận chuyển hàng hóa và kiểm định bán kính bảo hộ 3km nghiêm ngặt giữa các điểm bán.",
      part2: "Chuẩn bị tọa độ địa lý (kinh độ, vĩ độ hoặc địa chỉ cụ thể), diện tích mặt bằng showroom (m²), sức chứa kho bãi và thông tin cán bộ phụ trách điểm.",
      part3: "1. Bấm '+ Thêm Điểm Vận Hành / Showroom'.\n2. Nhập tên điểm, địa chỉ, khu vực và diện tích (m²).\n3. Nhập trạng thái tuân thủ bán kính bảo hộ (>3.0km).\n4. Bấm 'Lưu Dữ Liệu' để hệ thống lập bản đồ theo dõi.",
      part4: "• Diện tích: Mặt bằng trưng bày tối thiểu 80 m² (chuẩn Tier 1 là ≥150 m²).\n• Bán kính bảo hộ: Phải cách điểm bán hiện hữu tối thiểu 3.0 km đường bộ.\n• Trạng thái: Hoạt động xuất sắc, Hoạt động tốt, Cần phê duyệt ngoại lệ (HITL).",
      part5: "Điểm bán đạt chuẩn sẽ được cấp mã định danh điểm bán chính thức và kích hoạt giao hàng từ kho tổng gần nhất trong vòng 24 giờ.",
      part6: "Q: Xử lý thế nào nếu điểm bán mới nằm trong bán kính 2.8km với đại lý cũ?\nA: Điểm bán sẽ rơi vào hàng đợi 'Escalation - Cần phê duyệt ngoại lệ' và bắt buộc có văn bản chấp thuận của Giám đốc Vùng trước khi kích hoạt.\nQ: Diện tích mặt bằng có ảnh hưởng đến điểm số thẩm định không?\nA: Có, chiếm 25% trọng số trong ma trận điểm vị trí & dịch vụ.",
      part7: "Nếu điểm bán báo lỗi xung đột vị trí, kiểm tra lại cự ly thực tế trên bản đồ hoặc tiến hành khảo sát thực địa."
    },
    analytics: {
      title: "Hệ Thống Phân Tích Dữ Liệu BI & AI Agent (AI Data Analytics)",
      icon: "🧠",
      part1: "Trọng tâm công nghệ của HA UIEN SYSTEMS - Vận hành mô hình Trí tuệ nhân tạo Ha Uien theo quy trình chuẩn 5 bước Business Intelligence: Tự động đọc dữ liệu thô, Báo cáo lỗi chi tiết, Nhận định AI & Console phản hồi, Ký duyệt của người dùng và Bộ 6 Multi-Dashboard chuyên biệt kèm xuất Excel, Word, HTML.",
      part2: "Chuẩn bị file dữ liệu thô (.xlsx, .csv, .json, .txt) hoặc bấm nút '🧪 Thử dữ liệu mẫu' để nạp ngay bộ hồ sơ chuẩn doanh nghiệp.",
      part3: "1. Bước 1: Xem bảng Data Profiling và bấm 'Xác nhận Kế hoạch Xử lý'.\n2. Bước 2: Rà soát sổ cái báo lỗi (dòng, cột, bản chất) và phê duyệt các điểm ngoài kế hoạch.\n3. Bước 3: Xem kết quả chấm điểm Tier, nhận định AI và gửi phản hồi điều chỉnh nếu cần.\n4. Bước 4: Đánh giá chất lượng mô hình (sao, độ tin cậy), chỉnh sửa nhận định và bấm 'Chốt nhận định cuối cùng'.\n5. Bước 5: Khai thác 6 Dashboard tình trạng và bấm xuất file Excel (.xlsx), Word (.doc), HTML tương tác.",
      part4: "• Data Profiling: Thống kê số dòng, cột, missing rate, outlier, kiểu dữ liệu.\n• Error Ledger: Sổ cái chi tiết từng lỗi dữ liệu (CRITICAL, HIGH, MEDIUM).\n• HITL Feedback: Vòng lặp phản hồi người dùng giúp Agent học hỏi qua từng chu kỳ.\n• Executive Sign-off: Chữ ký niêm phong pháp lý trước khi phát hành báo cáo.",
      part5: "Báo cáo đa định dạng được tạo ra ngay lập tức, phục vụ báo cáo HĐQT, Ban Giám đốc và bàn giao cho các phòng ban thực thi.",
      part6: "Q: Tại sao không thể chuyển ngay sang Bước 2 sau khi tải file?\nA: Theo quy trình nghiêm ngặt, người dùng bắt buộc phải xác nhận Kế hoạch Xử lý tại Bước 1 thì hệ thống mới được phép can thiệp làm sạch dữ liệu.\nQ: Tôi có thể xuất file Word không?\nA: Có, nút '📝 Xuất Báo Cáo Word (.doc)' tạo tài liệu chuẩn 7 phần kèm quốc hiệu HA UIEN SYSTEMS.",
      part7: "Nếu file tải lên bị lỗi định dạng không đọc được, Agent sẽ thông báo ngay tên lỗi và hướng dẫn bạn kiểm tra lại cấu trúc cột hoặc dùng chức năng nạp mẫu."
    },
    documents: {
      title: "Hệ Thống Quản Lý Tài Liệu & Hồ Sơ Pháp Lý (Document Management)",
      icon: "📁",
      part1: "Lưu trữ tập trung toàn bộ văn bản quy chế, hợp đồng nguyên tắc đại lý, biên bản nghiệm thu kỹ thuật, giấy chứng nhận đại lý dịch vụ và các báo cáo thẩm định dữ liệu BI đã ký duyệt.",
      part2: "Tài liệu dạng file điện tử (PDF, DOCX, XLSX, MD, JSON), tiêu đề rõ ràng, xác định cấp độ bảo mật và người ban hành.",
      part3: "1. Bấm '+ Tải Lên Tài Liệu Mới'.\n2. Nhập tên tài liệu, loại văn bản, tác giả, cấp bảo mật (Công khai, Nội bộ, Tuyệt mật).\n3. Bấm 'Lưu Tài Liệu'.\n4. Tìm kiếm tài liệu theo từ khóa hoặc tải về máy chỉ với một click.",
      part4: "• Loại văn bản: Quy chế quản trị, Quy định nghiệp vụ, Hợp đồng mẫu, Báo cáo điều hành.\n• Cấp bảo mật: Công khai (Toàn bộ đại lý), Nội bộ (CBNV), Tuyệt mật (Ban Giám Đốc).\n• Dung lượng: Kích thước tệp lưu trữ.",
      part5: "Tài liệu được phân loại vào đúng thư mục chuyên môn, mã hóa an toàn và sẵn sàng cho các phòng ban tra cứu khi đàm phán hợp đồng.",
      part6: "Q: Báo cáo BI sau khi xuất ở Bước 5 có tự lưu vào đây không?\nA: Có, các báo cáo đã ký duyệt chính thức sẽ được tạo bản ghi tham chiếu trong kho tài liệu.\nQ: Ai có quyền xem tài liệu 'Tuyệt mật'?\nA: Chỉ tài khoản cấp Lãnh đạo hoặc Ban Giám Đốc mới có quyền xem nội dung chi tiết.",
      part7: "Nếu file tải về không mở được, vui lòng kiểm tra phần mở rộng tệp (.doc, .xlsx, .pdf) đã được cài đặt ứng dụng tương ứng."
    },
    communication: {
      title: "Hệ Thống Truyền Thông Nội Bộ & Trợ Lý Ảo (Internal Communication)",
      icon: "💬",
      part1: "Kênh phát ngôn và truyền đạt chỉ đạo chính thức từ Ban Giám Đốc HA UIEN SYSTEMS tới toàn thể cán bộ nhân viên 3 miền; tích hợp trợ lý trò chuyện Trí tuệ nhân tạo Ha Uien hỗ trợ giải đáp 24/7.",
      part2: "Soạn thảo tiêu đề thông báo ngắn gọn, nội dung rõ ràng, phân loại đối tượng áp dụng và mức độ khẩn cấp.",
      part3: "1. Bấm '+ Tạo Thông Báo Mới'.\n2. Nhập tiêu đề, người phát hành, đối tượng nhận và mức độ (Hỏa tốc, Quan trọng, Bình thường).\n3. Viết toàn văn thông báo và bấm 'Phát Hành'.\n4. Sử dụng khung chat AI ở góc dưới bên phải để hỏi đáp tức thì về chính sách công ty.",
      part4: "• Mức độ: Hỏa tốc (bật thông báo đỏ), Quan trọng (vàng), Bình thường (xanh).\n• Đối tượng: Toàn thể CBNV, Phòng PTKD, Khối Kỹ thuật, Đại lý ủy quyền.\n• Trạng thái: Đã gửi, Tỷ lệ đọc.",
      part5: "Thông báo được gửi tới giao diện của tất cả người dùng thuộc nhóm thụ hưởng và lưu vào lịch sử truyền thông nội bộ.",
      part6: "Q: Tôi có thể chỉnh sửa thông báo đã phát hành không?\nA: Có, cán bộ phát hành có thể bấm '✏️ Sửa' để cập nhật nội dung bổ sung.\nQ: Trợ lý Chat AI có thể tra cứu thông tin hợp đồng không?\nA: Trí tuệ nhân tạo Ha Uien có thể tra cứu nhanh các quy chế, tiêu chuẩn bán kính 3km và điều kiện Tier 1.",
      part7: "Nếu tin nhắn chat không nhận được phản hồi, kiểm tra kết nối mạng cục bộ tới Localhost."
    },
    admin: {
      title: "Hệ Thống Quản Trị Hệ Thống & Kiểm Toán (System Administration)",
      icon: "🛡️",
      part1: "Giám sát trạng thái vận hành của toàn bộ máy chủ Localhost, kiểm soát phân quyền tài khoản người dùng, rà soát nhật ký kiểm toán (Audit Trail) và bảo đảm an toàn dữ liệu doanh nghiệp.",
      part2: "Quyền truy cập dành riêng cho Quản trị viên hệ thống (Administrator) hoặc Ban Giám Đốc HA UIEN SYSTEMS.",
      part3: "1. Xem bảng điều khiển trạng thái hệ thống (Uptime, RAM, Bộ nhớ Cache, Số kết nối an toàn).\n2. Rà soát danh sách Audit Trail ghi lại mọi thao tác Thêm, Sửa, Xóa, Xuất file.\n3. Bấm 'Dọn Dẹp Cache' hoặc 'Sao Lưu Dự Phòng' khi cần bảo trì hệ thống.",
      part4: "• Thời gian: Mốc thời gian chính xác theo chuẩn ISO và giờ Việt Nam.\n• IP / Máy trạm: Địa chỉ máy trạm thực hiện thao tác (Localhost 127.0.0.1).\n• Cấp độ: INFO (thông tin), SUCCESS (thành công), WARNING (cảnh báo), SYSTEM (hệ thống).",
      part5: "Mọi thay đổi nhạy cảm đều được ghi nhận vĩnh viễn, ngăn chặn các hành vi gian lận hoặc can thiệp dữ liệu trái phép.",
      part6: "Q: Dữ liệu được lưu ở đâu?\nA: Dữ liệu được lưu trữ an toàn ngay trên máy chủ cục bộ (Localhost) của bạn, không gửi ra ngoài Internet mà không có sự cho phép.\nQ: Tôi có thể xóa nhật ký Audit Log không?\nA: Không, nhật ký kiểm toán được khóa bảo vệ chỉ đọc (Read-only) để đảm bảo tính minh bạch theo tiêu chuẩn quản trị.",
      part7: "Nếu hệ thống báo đầy bộ nhớ tạm, bấm nút 'Dọn Dẹp Cache' để giải phóng bộ nhớ trình duyệt."
    }
  };

  // -------------------------------------------------------------------------
  // INITIALIZATION & STATE MANAGEMENT
  // -------------------------------------------------------------------------
  function init() {
    loadStateFromStorage();
    renderModuleTabs();
    renderActiveModuleView();
    setupHeaderSearch();
  }

  function loadStateFromStorage() {
    try {
      const isLoaded = localStorage.getItem(DATA_LOADED_KEY) === "true";
      state.isDataLoaded = isLoaded;
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved && isLoaded) {
        state.data = JSON.parse(saved);
      } else {
        state.data = {
          hr: [],
          finance: [],
          crm: [],
          project: [],
          operations: [],
          documents: [],
          communication: [],
          admin: []
        };
      }
    } catch (e) {
      console.warn("Storage error, fallback to empty standby", e);
      state.isDataLoaded = false;
      state.data = {
        hr: [],
        finance: [],
        crm: [],
        project: [],
        operations: [],
        documents: [],
        communication: [],
        admin: []
      };
    }
  }

  function saveStateToStorage() {
    try {
      if (state.isDataLoaded && state.data) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(state.data));
        localStorage.setItem(DATA_LOADED_KEY, "true");
      }
    } catch (e) {
      console.error("Save state failed", e);
    }
  }

  function loadDemoSampleData() {
    state.data = JSON.parse(JSON.stringify(DEFAULT_DATA));
    state.isDataLoaded = true;
    localStorage.setItem(DATA_LOADED_KEY, "true");
    saveStateToStorage();
    renderModuleTabs();
    renderActiveModuleView();
    if (typeof playSuccessChime === "function") playSuccessChime();
    showToastNotification("✨ Đã nạp thành công bộ dữ liệu mẫu doanh nghiệp (10 phân hệ)!");
    alert("🎉 NẠP DỮ LIỆU DOANH NGHIỆP THÀNH CÔNG!\n\nĐã nạp đầy đủ dữ liệu mẫu cho 10 phân hệ điều hành HA UIEN SYSTEMS:\n• Executive Dashboard (Tổng quan tài chính & KPI)\n• Quản trị Nhân sự & Headcount\n• Quản lý Tài chính & Dòng tiền\n• CRM & Mạng lưới đối tác\n• Quản lý Dự án & Vận hành chuỗi điểm bán\n• Hồ sơ tài liệu & Truyền thông nội bộ\n\nBạn có thể tự do trải nghiệm biểu đồ tương tác, tìm kiếm, lọc, thêm, sửa, xóa và xuất Excel.");
  }

  function clearDataToStandby() {
    if (confirm("Xác nhận đưa hệ thống về trạng thái Chờ (Standby)?\n\nToàn bộ dữ liệu trong phiên làm việc sẽ được giải phóng theo tiêu chuẩn BI để sẵn sàng cho tệp dữ liệu mới.")) {
      state.isDataLoaded = false;
      state.data = {
        hr: [],
        finance: [],
        crm: [],
        project: [],
        operations: [],
        documents: [],
        communication: [],
        admin: []
      };
      localStorage.removeItem(DATA_LOADED_KEY);
      localStorage.removeItem(STORAGE_KEY);
      renderModuleTabs();
      renderActiveModuleView();
      if (typeof playBeep === "function") playBeep(450, "sine", 0.08);
      showToastNotification("Hệ thống đã đưa về trạng thái chờ nạp dữ liệu.");
    }
  }

  function triggerEnterpriseFileUpload() {
    let input = document.getElementById("enterpriseFileInput");
    if (!input) {
      input = document.createElement("input");
      input.type = "file";
      input.id = "enterpriseFileInput";
      input.accept = ".xlsx,.xls,.csv,.json";
      input.style.display = "none";
      document.body.appendChild(input);
      input.addEventListener("change", (e) => {
        const file = e.target.files ? e.target.files[0] : null;
        if (file) handleEnterpriseFileUpload(file);
        input.value = "";
      });
    }
    input.click();
  }

  function handleEnterpriseFileUpload(file) {
    const fileName = file.name;
    const ext = fileName.split(".").pop().toLowerCase();

    if (ext === "json") {
      const reader = new FileReader();
      reader.onload = function(e) {
        try {
          const parsed = JSON.parse(e.target.result);
          if (parsed && typeof parsed === "object") {
            if (parsed.hr || parsed.finance || parsed.crm || parsed.project) {
              state.data = Object.assign({}, DEFAULT_DATA, parsed);
            } else if (Array.isArray(parsed)) {
              const currentMod = state.activeModule === "executive" ? "crm" : state.activeModule;
              state.data[currentMod] = parsed;
            }
            state.isDataLoaded = true;
            localStorage.setItem(DATA_LOADED_KEY, "true");
            saveStateToStorage();
            renderModuleTabs();
            renderActiveModuleView();
            if (typeof playSuccessChime === "function") playSuccessChime();
            showToastNotification(`Đã nạp thành công dữ liệu từ tệp: ${fileName}`);
            alert(`✅ ĐÃ NẠP DỮ LIỆU TỆP THÀNH CÔNG!\n\nTệp: ${fileName}\nDữ liệu đã được nạp vào hệ thống phân tích HA UIEN SYSTEMS.`);
          }
        } catch(err) {
          alert("Lỗi đọc tệp JSON: " + err.message);
        }
      };
      reader.readAsText(file);
    } else if (ext === "xlsx" || ext === "xls" || ext === "csv") {
      const reader = new FileReader();
      reader.onload = function(e) {
        try {
          if (typeof XLSX === "undefined") {
            alert("Thư viện SheetJS chưa sẵn sàng!");
            return;
          }
          const data = new Uint8Array(e.target.result);
          const workbook = XLSX.read(data, { type: "array" });
          
          let loadedAny = false;
          const newData = JSON.parse(JSON.stringify(DEFAULT_DATA));
          
          workbook.SheetNames.forEach(sheetName => {
            const lower = sheetName.toLowerCase();
            const ws = workbook.Sheets[sheetName];
            const rows = XLSX.utils.sheet_to_json(ws);
            if (rows && rows.length > 0) {
              loadedAny = true;
              if (lower.includes("nhan su") || lower.includes("hr")) newData.hr = rows;
              else if (lower.includes("tai chinh") || lower.includes("finance")) newData.finance = rows;
              else if (lower.includes("crm") || lower.includes("doi tac") || lower.includes("khach hang")) newData.crm = rows;
              else if (lower.includes("du an") || lower.includes("project")) newData.project = rows;
              else if (lower.includes("van hanh") || lower.includes("operation")) newData.operations = rows;
              else if (lower.includes("tai lieu") || lower.includes("doc")) newData.documents = rows;
              else {
                const currentMod = state.activeModule === "executive" ? "crm" : state.activeModule;
                newData[currentMod] = rows;
              }
            }
          });

          if (!loadedAny) {
            alert("Không tìm thấy dòng dữ liệu nào trong tệp Excel!");
            return;
          }

          state.data = newData;
          state.isDataLoaded = true;
          localStorage.setItem(DATA_LOADED_KEY, "true");
          saveStateToStorage();
          renderModuleTabs();
          renderActiveModuleView();
          if (typeof playSuccessChime === "function") playSuccessChime();
          showToastNotification(`Đã nạp và cấu trúc hóa dữ liệu từ: ${fileName}`);
          alert(`✅ ĐÃ NẠP TỆP DỮ LIỆU DOANH NGHIỆP THÀNH CÔNG!\n\nTệp: ${fileName}\nSố trang tính: ${workbook.SheetNames.length}\nTrí tuệ nhân tạo Ha Uien đã cập nhật biểu đồ và bảng dữ liệu!`);
        } catch(err) {
          console.error("Upload error:", err);
          alert("Lỗi khi xử lý tệp: " + err.message);
        }
      };
      reader.readAsArrayBuffer(file);
    }
  }

  // -------------------------------------------------------------------------
  // MODULE SWITCHING & NAVIGATION
  // -------------------------------------------------------------------------
  function switchModule(moduleId) {
    if (!moduleId) return;
    state.activeModule = moduleId;
    state.searchQuery = "";
    state.filterValue = "ALL";
    state.editingRecordId = null;

    // Update Tab UI
    document.querySelectorAll(".enterprise-tab-btn").forEach(btn => {
      const id = btn.getAttribute("data-module");
      if (id === moduleId) {
        btn.className = "enterprise-tab-btn active px-3.5 py-2 rounded-2xl bg-gradient-to-r from-lemon-500 to-amber-500 text-brand-dark font-black text-xs shadow-md shadow-lemon-500/20 flex items-center space-x-2 transition transform scale-105 cursor-pointer whitespace-nowrap";
      } else {
        btn.className = "enterprise-tab-btn px-3.5 py-2 rounded-2xl bg-slate-100 dark:bg-brand-card hover:bg-slate-200 dark:hover:bg-brand-border text-slate-700 dark:text-slate-300 font-bold text-xs border border-slate-200 dark:border-brand-border flex items-center space-x-2 transition cursor-pointer whitespace-nowrap";
      }
    });

    // Update Breadcrumb if present
    const bc = document.getElementById("headerBreadcrumb");
    if (bc && USER_GUIDES[moduleId]) {
      bc.textContent = `Hệ Điều Hành > ${USER_GUIDES[moduleId].title.split("(")[0].trim()}`;
    }

    // Scroll to view if needed
    const section = document.getElementById("enterprise-ecosystem");
    if (section && window.scrollY > 400) {
      section.scrollIntoView({ behavior: "smooth", block: "start" });
    }

    renderActiveModuleView();
    try { playBeep(520, "triangle", 0.04); } catch (e) {}
  }

  // -------------------------------------------------------------------------
  // RENDER MODULE TABS BAR
  // -------------------------------------------------------------------------
  function renderModuleTabs() {
    const container = document.getElementById("enterpriseTabsContainer");
    if (!container) return;

        const isEn = (window.currentLang === 'en' || localStorage.getItem('app_lang') === 'en' || localStorage.getItem('HA_UIEN_LANG') === 'en');
    const modules = isEn ? [
      { id: "executive", name: "Executive Dashboard", icon: "🏢" },
      { id: "hr", name: "HR Management", icon: "👥" },
      { id: "finance", name: "Financial Management", icon: "💰" },
      { id: "crm", name: "CRM & Partner Network", icon: "🤝" },
      { id: "project", name: "Project Management", icon: "🚀" },
      { id: "operations", name: "Retail Operations", icon: "⚙️" },
      { id: "analytics", name: "BI Analytics (AI Agent)", icon: "🧠" },
      { id: "documents", name: "Document Management", icon: "📁" },
      { id: "communication", name: "Internal Comms", icon: "💬" },
      { id: "admin", name: "System Administration", icon: "🛡️" }
    ] : [
      { id: "executive", name: "Executive Dashboard", icon: "🏢" },
      { id: "hr", name: "Quản trị Nhân sự", icon: "👥" },
      { id: "finance", name: "Quản lý Tài chính", icon: "💰" },
      { id: "crm", name: "CRM & Đối tác", icon: "🤝" },
      { id: "project", name: "Quản lý Dự án", icon: "🚀" },
      { id: "operations", name: "Vận hành Điểm bán", icon: "⚙️" },
      { id: "analytics", name: "Phân tích BI (AI Agent)", icon: "🧠" },
      { id: "documents", name: "Quản lý Tài liệu", icon: "📁" },
      { id: "communication", name: "Truyền thông Nội bộ", icon: "💬" },
      { id: "admin", name: "Quản trị Hệ thống", icon: "🛡️" }
    ];

    let html = "";
    modules.forEach(m => {
      const isActive = m.id === state.activeModule;
      const cls = isActive
        ? "enterprise-tab-btn active px-3.5 py-2 rounded-2xl bg-gradient-to-r from-lemon-500 to-amber-500 text-brand-dark font-black text-xs shadow-md shadow-lemon-500/20 flex items-center space-x-2 transition transform scale-105 cursor-pointer whitespace-nowrap"
        : "enterprise-tab-btn px-3.5 py-2 rounded-2xl bg-slate-100 dark:bg-brand-card hover:bg-slate-200 dark:hover:bg-brand-border text-slate-700 dark:text-slate-300 font-bold text-xs border border-slate-200 dark:border-brand-border flex items-center space-x-2 transition cursor-pointer whitespace-nowrap";
      html += `
        <button type="button" onclick="EnterpriseEcosystem.switchModule('${m.id}')" data-module="${m.id}" class="${cls}">
          <span class="text-base">${m.icon}</span>
          <span>${m.name}</span>
        </button>
      `;
    });
    container.innerHTML = html;
  }

  // -------------------------------------------------------------------------
  // RENDER ACTIVE MODULE VIEW
  // -------------------------------------------------------------------------
  function renderActiveModuleView() {
    const mainEl = document.getElementById("enterpriseContentArea");
    if (!mainEl) return;

    const m = state.activeModule;

    // Special case: AI Analytics embeds link to 5-Step BI Engine
    if (m === "analytics") {
      renderAnalyticsModuleView(mainEl);
      return;
    }

    const guide = USER_GUIDES[m] || { title: m.toUpperCase(), icon: "📊" };

    let actionButtonsHtml = "";
    if (state.isDataLoaded) {
      actionButtonsHtml = `
        <button onclick="EnterpriseEcosystem.openUserGuide('${m}')" class="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-brand-input hover:bg-slate-200 dark:hover:bg-brand-border text-slate-800 dark:text-slate-200 font-bold text-xs border border-slate-300 dark:border-brand-border flex items-center space-x-1.5 transition cursor-pointer">
          <span>📖 Hướng dẫn sử dụng</span>
        </button>
        <button onclick="EnterpriseEcosystem.exportCurrentModuleData()" class="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs shadow-md shadow-emerald-600/20 flex items-center space-x-1.5 transition cursor-pointer">
          <span>📗 Xuất Excel / CSV</span>
        </button>
        <button onclick="EnterpriseEcosystem.triggerEnterpriseFileUpload()" class="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-brand-input hover:bg-slate-200 dark:hover:bg-brand-border text-slate-800 dark:text-slate-200 font-bold text-xs border border-slate-300 dark:border-brand-border flex items-center space-x-1.5 transition cursor-pointer" title="Nạp tệp mới">
          <span>📤 Tải tệp khác</span>
        </button>
        <button onclick="EnterpriseEcosystem.clearDataToStandby()" class="px-3.5 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-500 dark:text-rose-400 font-bold text-xs border border-rose-500/30 flex items-center space-x-1.5 transition cursor-pointer" title="Đưa hệ thống về trạng thái Chờ (Standby)">
          <span>🔄 Xóa DL (Standby)</span>
        </button>
        ${m !== 'executive' && m !== 'admin' ? `
        <button onclick="EnterpriseEcosystem.openAddModal()" class="px-4 py-2 rounded-xl bg-gradient-to-r from-lemon-500 to-amber-500 hover:from-lemon-400 text-brand-dark font-black text-xs shadow-md shadow-lemon-500/30 flex items-center space-x-1.5 transition transform active:scale-95 cursor-pointer">
          <span>+ Thêm mới</span>
        </button>` : ''}
      `;
    } else {
      actionButtonsHtml = `
        <button onclick="EnterpriseEcosystem.openUserGuide('${m}')" class="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-brand-input hover:bg-slate-200 dark:hover:bg-brand-border text-slate-800 dark:text-slate-200 font-bold text-xs border border-slate-300 dark:border-brand-border flex items-center space-x-1.5 transition cursor-pointer">
          <span>📖 Hướng dẫn sử dụng</span>
        </button>
        <button onclick="EnterpriseEcosystem.triggerEnterpriseFileUpload()" class="px-4 py-2 rounded-xl bg-gradient-to-r from-lemon-500 to-amber-500 hover:from-lemon-400 text-brand-dark font-black text-xs shadow-md shadow-lemon-500/30 flex items-center space-x-1.5 transition transform active:scale-95 cursor-pointer">
          <span>📤 Tải Lên Tệp (.xlsx, .csv)</span>
        </button>
        <button onclick="EnterpriseEcosystem.loadDemoSampleData()" class="px-4 py-2 rounded-xl bg-white dark:bg-brand-input hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-900 dark:text-white font-extrabold text-xs border border-slate-300 dark:border-brand-border shadow-sm flex items-center space-x-1.5 transition cursor-pointer">
          <span>🧪 Nạp Dữ Liệu Mẫu Demo</span>
        </button>
      `;
    }

    let html = `
      <!-- Module Header Bar -->
      <div class="p-5 sm:p-6 rounded-3xl bg-white dark:bg-brand-card border border-slate-200 dark:border-brand-border shadow-xl space-y-4">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div class="space-y-1">
            <div class="flex items-center space-x-2.5">
              <span class="text-2xl">${guide.icon}</span>
              <h2 class="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight">${guide.title}</h2>
              <span class="px-2.5 py-0.5 rounded-full ${state.isDataLoaded ? 'bg-lemon-500/10 text-lemon-500 border border-lemon-500/30' : 'bg-amber-500/10 text-amber-500 border border-amber-500/30'} text-[10px] font-extrabold uppercase">
                ${state.isDataLoaded ? 'HA UIEN SYSTEMS · ĐANG VẬN HÀNH' : 'STANDBY · CHỜ DỮ LIỆU'}
              </span>
            </div>
            <p class="text-xs sm:text-sm text-slate-500 dark:text-slate-400 max-w-3xl">${guide.part1}</p>
          </div>

          <div class="flex items-center flex-wrap gap-2.5 shrink-0">
            ${actionButtonsHtml}
          </div>
        </div>

        <!-- KPI Metric Cards Grid -->
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 pt-2">
          ${getKpiCardsHtmlForModule(m)}
        </div>
      </div>

      <!-- Charts & Visual Analytics Section -->
      ${getChartsHtmlForModule(m)}

      <!-- Data Table Management Section -->
      ${getDataTableHtmlForModule(m)}
    `;

    mainEl.innerHTML = html;

    // Render charts
    if (state.isDataLoaded) {
      setTimeout(() => {
        initChartsForModule(m);
      }, 50);
    }
  }

  // -------------------------------------------------------------------------
  // KPI CARDS GENERATOR
  // -------------------------------------------------------------------------
  function getKpiCardsHtmlForModule(m) {
    if (!state.isDataLoaded) {
      return `
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Trạng Thái Dữ Liệu</div>
          <div class="text-xl sm:text-2xl font-black text-amber-500 mt-1">Chờ Nạp Tệp</div>
          <div class="text-[10px] text-slate-400 font-bold mt-1">Hệ thống BI ở chế độ Standby</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Chỉ Số Phân Hệ</div>
          <div class="text-xl sm:text-2xl font-black text-slate-400 mt-1">-- / --</div>
          <div class="text-[10px] text-slate-500 font-bold mt-1">Chưa nạp bản ghi</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Tổng Số Bản Ghi</div>
          <div class="text-xl sm:text-2xl font-black text-slate-400 mt-1">0 bản ghi</div>
          <div class="text-[10px] text-slate-500 font-bold mt-1">Bấm Nạp dữ liệu để kích hoạt</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Độ Sẵn Sàng</div>
          <div class="text-xl sm:text-2xl font-black text-lemon-400 mt-1">Sẵn sàng</div>
          <div class="text-[10px] text-lemon-500 font-bold mt-1">Hỗ trợ Excel, CSV, JSON</div>
        </div>
      `;
    }
    const data = state.data;
    if (m === "executive") {
      return `
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border relative overflow-hidden group">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Doanh thu luỹ kế</div>
          <div class="text-xl sm:text-2xl font-black text-emerald-500 mt-1">18.450.000.000 đ</div>
          <div class="text-[10px] text-emerald-400 font-bold mt-1">↑ +18.4% so với cùng kỳ</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border relative overflow-hidden group">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Chi phí vận hành</div>
          <div class="text-xl sm:text-2xl font-black text-rose-500 mt-1">11.230.000.000 đ</div>
          <div class="text-[10px] text-slate-400 font-bold mt-1">Kiểm soát 60.8% ngân sách</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border relative overflow-hidden group">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Lợi nhuận ròng</div>
          <div class="text-xl sm:text-2xl font-black text-lemon-400 mt-1">7.220.000.000 đ</div>
          <div class="text-[10px] text-lemon-500 font-bold mt-1">Biên lợi nhuận 39.1%</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border relative overflow-hidden group">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Đối tác & Đại lý toàn quốc</div>
          <div class="text-xl sm:text-2xl font-black text-sky-400 mt-1">320 Đại lý</div>
          <div class="text-[10px] text-sky-300 font-bold mt-1">3 Khu vực: Bắc · Trung · Nam</div>
        </div>
      `;
    }

    if (m === "hr") {
      const count = data.hr ? data.hr.length : 0;
      const avgKpi = count > 0 ? (data.hr.reduce((a, b) => a + (b.kpi || 0), 0) / count).toFixed(1) : 0;
      return `
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Tổng nhân sự</div>
          <div class="text-xl sm:text-2xl font-black text-white mt-1">${count} CBNV</div>
          <div class="text-[10px] text-emerald-400 font-bold mt-1">96% Định biên chuẩn</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Hiệu suất KPI TB</div>
          <div class="text-xl sm:text-2xl font-black text-lemon-400 mt-1">${avgKpi} / 100</div>
          <div class="text-[10px] text-lemon-500 font-bold mt-1">Đánh giá tháng 11/2026</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Phòng ban vận hành</div>
          <div class="text-xl sm:text-2xl font-black text-grape-400 mt-1">5 Khối</div>
          <div class="text-[10px] text-slate-400 font-bold mt-1">Hội sở & 3 Chi nhánh</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Tỷ lệ giữ chân</div>
          <div class="text-xl sm:text-2xl font-black text-emerald-500 mt-1">98.2%</div>
          <div class="text-[10px] text-emerald-400 font-bold mt-1">Môi trường làm việc Data-driven</div>
        </div>
      `;
    }

    if (m === "finance") {
      const items = data.finance || [];
      const thu = items.filter(x => x.type === "THU").reduce((a, b) => a + (b.amount || 0), 0);
      const chi = items.filter(x => x.type === "CHI").reduce((a, b) => a + (b.amount || 0), 0);
      return `
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Tổng Thu trong kỳ</div>
          <div class="text-xl sm:text-2xl font-black text-emerald-500 mt-1">${(thu / 1e9).toFixed(2)} Tỷ đ</div>
          <div class="text-[10px] text-emerald-400 font-bold mt-1">Dòng tiền đại lý về đúng hạn</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Tổng Chi vận hành</div>
          <div class="text-xl sm:text-2xl font-black text-rose-500 mt-1">${(chi / 1e9).toFixed(2)} Tỷ đ</div>
          <div class="text-[10px] text-slate-400 font-bold mt-1">Đã giải ngân hợp lệ</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Dòng tiền tự do (FCF)</div>
          <div class="text-xl sm:text-2xl font-black text-lemon-400 mt-1">+${((thu - chi) / 1e9).toFixed(2)} Tỷ đ</div>
          <div class="text-[10px] text-lemon-500 font-bold mt-1">Thặng dư khả dụng</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Tỷ lệ thu hồi nợ</div>
          <div class="text-xl sm:text-2xl font-black text-sky-400 mt-1">99.1%</div>
          <div class="text-[10px] text-sky-300 font-bold mt-1">0% Nợ xấu phát sinh mới</div>
        </div>
      `;
    }

    if (m === "crm") {
      const items = data.crm || [];
      const t1Count = items.filter(x => x.tier === "Tier 1").length;
      return `
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Tổng mạng lưới đại lý</div>
          <div class="text-xl sm:text-2xl font-black text-white mt-1">${items.length} Đại lý</div>
          <div class="text-[10px] text-slate-400 font-bold mt-1">Đã ký kết hợp đồng</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Tier 1 Chiến Lược</div>
          <div class="text-xl sm:text-2xl font-black text-emerald-500 mt-1">${t1Count} Điểm bán</div>
          <div class="text-[10px] text-emerald-400 font-bold mt-1">Cấp trần nợ 500 tr/đại lý</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Doanh số TB / Đại lý</div>
          <div class="text-xl sm:text-2xl font-black text-lemon-400 mt-1">1.45 Tỷ / Qúy</div>
          <div class="text-[10px] text-lemon-500 font-bold mt-1">Đạt 112% Chỉ tiêu năm</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Độ hài lòng đối tác</div>
          <div class="text-xl sm:text-2xl font-black text-grape-400 mt-1">4.9 / 5.0 ⭐</div>
          <div class="text-[10px] text-grape-300 font-bold mt-1">Hỗ trợ kỹ thuật 24/7</div>
        </div>
      `;
    }

    if (m === "project") {
      const items = data.project || [];
      const onTrack = items.filter(x => x.progress >= 80).length;
      return `
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Tổng dự án trọng điểm</div>
          <div class="text-xl sm:text-2xl font-black text-white mt-1">${items.length} Dự án</div>
          <div class="text-[10px] text-slate-400 font-bold mt-1">Đang triển khai toàn quốc</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Tiến độ đúng hạn</div>
          <div class="text-xl sm:text-2xl font-black text-emerald-500 mt-1">${onTrack} Dự án</div>
          <div class="text-[10px] text-emerald-400 font-bold mt-1">Tiến độ ≥80% kế hoạch</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Ngân sách dự án</div>
          <div class="text-xl sm:text-2xl font-black text-lemon-400 mt-1">6.62 Tỷ đ</div>
          <div class="text-[10px] text-lemon-500 font-bold mt-1">Giải ngân 82.5%</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Chỉ số rủi ro SLA</div>
          <div class="text-xl sm:text-2xl font-black text-sky-400 mt-1">0.4%</div>
          <div class="text-[10px] text-sky-300 font-bold mt-1">Mức an toàn tối ưu</div>
        </div>
      `;
    }

    if (m === "operations") {
      const items = data.operations || [];
      return `
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Tổng Showroom & Kho</div>
          <div class="text-xl sm:text-2xl font-black text-white mt-1">${items.length} Điểm</div>
          <div class="text-[10px] text-slate-400 font-bold mt-1">Hà Nội · Đà Nẵng · TP.HCM</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Tuân thủ cự ly 3km</div>
          <div class="text-xl sm:text-2xl font-black text-emerald-500 mt-1">94.2%</div>
          <div class="text-[10px] text-emerald-400 font-bold mt-1">Bảo hộ độc quyền vùng bán</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Tổng diện tích mặt bằng</div>
          <div class="text-xl sm:text-2xl font-black text-lemon-400 mt-1">2.690 m²</div>
          <div class="text-[10px] text-lemon-500 font-bold mt-1">Chuẩn nhận diện thương hiệu</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Thời gian giao hàng</div>
          <div class="text-xl sm:text-2xl font-black text-sky-400 mt-1">&lt; 24 Giờ</div>
          <div class="text-[10px] text-sky-300 font-bold mt-1">Giao từ kho tổng gần nhất</div>
        </div>
      `;
    }

    if (m === "documents") {
      const items = data.documents || [];
      return `
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Văn bản & Hồ sơ lưu trữ</div>
          <div class="text-xl sm:text-2xl font-black text-white mt-1">${items.length} Văn bản</div>
          <div class="text-[10px] text-slate-400 font-bold mt-1">Đã số hóa 100%</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Hợp đồng nguyên tắc</div>
          <div class="text-xl sm:text-2xl font-black text-emerald-500 mt-1">128 Bản</div>
          <div class="text-[10px] text-emerald-400 font-bold mt-1">Hiệu lực pháp lý</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Báo cáo thẩm định BI</div>
          <div class="text-xl sm:text-2xl font-black text-lemon-400 mt-1">84 Báo cáo</div>
          <div class="text-[10px] text-lemon-500 font-bold mt-1">Niêm phong chữ ký số</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Cấp bảo mật cao</div>
          <div class="text-xl sm:text-2xl font-black text-grape-400 mt-1">100% Mã hóa</div>
          <div class="text-[10px] text-grape-300 font-bold mt-1">Tiêu chuẩn ISO/IEC 27001</div>
        </div>
      `;
    }

    if (m === "communication") {
      const items = data.communication || [];
      return `
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Thông báo điều hành</div>
          <div class="text-xl sm:text-2xl font-black text-white mt-1">${items.length} Bản tin</div>
          <div class="text-[10px] text-slate-400 font-bold mt-1">Chỉ đạo từ Ban Giám Đốc</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Tỷ lệ đọc thông báo</div>
          <div class="text-xl sm:text-2xl font-black text-emerald-500 mt-1">98.5%</div>
          <div class="text-[10px] text-emerald-400 font-bold mt-1">Phản hồi trong 2 giờ</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Trợ lý AI Ha Uien</div>
          <div class="text-xl sm:text-2xl font-black text-lemon-400 mt-1">24/7 Trực tuyến</div>
          <div class="text-[10px] text-lemon-500 font-bold mt-1">Tức thì 1 giây</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Độ thông suốt thông tin</div>
          <div class="text-xl sm:text-2xl font-black text-sky-400 mt-1">100%</div>
          <div class="text-[10px] text-sky-300 font-bold mt-1">Không gián đoạn</div>
        </div>
      `;
    }

    if (m === "admin") {
      const items = data.admin || [];
      return `
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Máy chủ Localhost</div>
          <div class="text-xl sm:text-2xl font-black text-emerald-500 mt-1">Port 8080 Active</div>
          <div class="text-[10px] text-emerald-400 font-bold mt-1">100% Uptime liên tục</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Nhật ký Audit Trail</div>
          <div class="text-xl sm:text-2xl font-black text-white mt-1">${items.length} Sự kiện</div>
          <div class="text-[10px] text-slate-400 font-bold mt-1">Ghi vết chi tiết từng tác vụ</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Bộ nhớ Cache lưu trữ</div>
          <div class="text-xl sm:text-2xl font-black text-lemon-400 mt-1">12.4 MB</div>
          <div class="text-[10px] text-lemon-500 font-bold mt-1">Tối ưu tốc độ tức thì</div>
        </div>
        <div class="p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Cấp độ an toàn hệ thống</div>
          <div class="text-xl sm:text-2xl font-black text-sky-400 mt-1">Enterprise Grade</div>
          <div class="text-[10px] text-sky-300 font-bold mt-1">Zero Breach Detected</div>
        </div>
      `;
    }

    return "";
  }

  // -------------------------------------------------------------------------
  // CHARTS GENERATOR HTML
  // -------------------------------------------------------------------------
  function getChartsHtmlForModule(m) {
    if (!state.isDataLoaded) {
      return `
        <div class="p-6 sm:p-8 rounded-3xl bg-white dark:bg-brand-card border border-dashed border-lemon-500/40 shadow-xl text-center space-y-4">
          <div class="w-16 h-16 rounded-2xl bg-lemon-500/10 text-lemon-400 border border-lemon-500/20 flex items-center justify-center text-3xl mx-auto shadow-inner">
            🛡️
          </div>
          <div class="space-y-1.5 max-w-xl mx-auto">
            <div class="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-[10px] font-black text-slate-600 dark:text-slate-300 uppercase tracking-wider">
              <span class="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
              <span>BI STANDBY · CHỜ DỮ LIỆU ĐƯỢC NẠP</span>
            </div>
            <h3 class="text-lg sm:text-xl font-black text-slate-900 dark:text-white">Biểu Đồ & Phân Tích Đang Ở Chế Độ Chờ</h3>
            <p class="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Theo đúng quy chuẩn phân tích Business Intelligence (BI), dữ liệu không được phép có sẵn hay tự ý chạy ngầm. Vui lòng bấm nạp tệp hoặc nạp dữ liệu mẫu để kích hoạt hệ thống trực quan hóa.
            </p>
          </div>
          <div class="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button onclick="EnterpriseEcosystem.triggerEnterpriseFileUpload()" class="px-5 py-2.5 rounded-2xl bg-gradient-to-r from-lemon-500 to-amber-500 hover:from-lemon-400 text-brand-dark font-black text-xs shadow-lg shadow-lemon-500/25 flex items-center space-x-2 transition transform active:scale-95 cursor-pointer">
              <span>📤 Tải Lên Tệp Dữ Liệu (.xlsx, .csv, .json)</span>
            </button>
            <button onclick="EnterpriseEcosystem.loadDemoSampleData()" class="px-5 py-2.5 rounded-2xl bg-white dark:bg-brand-input hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-900 dark:text-white font-extrabold text-xs border border-slate-300 dark:border-brand-border shadow-sm flex items-center space-x-2 transition cursor-pointer">
              <span>🧪 Nạp Bộ Dữ Liệu Mẫu Demo (10 Phân Hệ)</span>
            </button>
          </div>
        </div>
      `;
    }

    if (m === "executive") {
      return `
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <!-- Chart 1: Doanh thu & Chi phí (lg:col-span-8) -->
          <div class="lg:col-span-8 p-5 sm:p-6 rounded-3xl bg-white dark:bg-brand-card border border-slate-200 dark:border-brand-border shadow-xl space-y-3">
            <div class="flex items-center justify-between">
              <div>
                <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Xu Hướng Doanh Thu & Chi Phí 6 Tháng Gần Nhất</h3>
                <p class="text-xs text-slate-500 dark:text-slate-400">Đơn vị: Tỷ VNĐ · Tỷ suất lợi nhuận duy trì &gt;35%</p>
              </div>
              <span class="px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-500 text-[11px] font-bold">Tăng trưởng +18.4%</span>
            </div>
            <div class="relative h-64 sm:h-72 w-full">
              <canvas id="chartExecRevCost"></canvas>
            </div>
          </div>

          <!-- Chart 2: Cơ cấu chi phí (lg:col-span-4) -->
          <div class="lg:col-span-4 p-5 sm:p-6 rounded-3xl bg-white dark:bg-brand-card border border-slate-200 dark:border-brand-border shadow-xl space-y-3">
            <div>
              <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Cơ Cấu Chi Phí Vận Hành</h3>
              <p class="text-xs text-slate-500 dark:text-slate-400">Tỷ trọng các hạng mục chi</p>
            </div>
            <div class="relative h-56 sm:h-64 w-full flex items-center justify-center">
              <canvas id="chartExecCostStructure"></canvas>
            </div>
          </div>
        </div>
      `;
    }

    if (m === "hr") {
      return `
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <div class="p-5 sm:p-6 rounded-3xl bg-white dark:bg-brand-card border border-slate-200 dark:border-brand-border shadow-xl space-y-3">
            <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Phân Bổ Nhân Sự Theo Phòng Ban</h3>
            <div class="relative h-64 w-full">
              <canvas id="chartHrDept"></canvas>
            </div>
          </div>
          <div class="p-5 sm:p-6 rounded-3xl bg-white dark:bg-brand-card border border-slate-200 dark:border-brand-border shadow-xl space-y-3">
            <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Hiệu Suất KPI Trung Bình Theo Khối</h3>
            <div class="relative h-64 w-full">
              <canvas id="chartHrKpi"></canvas>
            </div>
          </div>
        </div>
      `;
    }

    if (m === "finance") {
      return `
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <div class="p-5 sm:p-6 rounded-3xl bg-white dark:bg-brand-card border border-slate-200 dark:border-brand-border shadow-xl space-y-3">
            <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Tỷ Trọng Dòng Tiền Thu Theo Kênh</h3>
            <div class="relative h-64 w-full">
              <canvas id="chartFinanceInflow"></canvas>
            </div>
          </div>
          <div class="p-5 sm:p-6 rounded-3xl bg-white dark:bg-brand-card border border-slate-200 dark:border-brand-border shadow-xl space-y-3">
            <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Kiểm Soát Hạn Mức Tín Dụng & Công Nợ</h3>
            <div class="relative h-64 w-full">
              <canvas id="chartFinanceCredit"></canvas>
            </div>
          </div>
        </div>
      `;
    }

    if (m === "crm") {
      return `
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <div class="p-5 sm:p-6 rounded-3xl bg-white dark:bg-brand-card border border-slate-200 dark:border-brand-border shadow-xl space-y-3">
            <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Phân Bổ Đại Lý Theo Phân Hạng Tier</h3>
            <div class="relative h-64 w-full">
              <canvas id="chartCrmTiers"></canvas>
            </div>
          </div>
          <div class="p-5 sm:p-6 rounded-3xl bg-white dark:bg-brand-card border border-slate-200 dark:border-brand-border shadow-xl space-y-3">
            <h3 class="text-base font-extrabold text-slate-900 dark:text-white">Doanh Số Bình Quân Theo 3 Khu Vực</h3>
            <div class="relative h-64 w-full">
              <canvas id="chartCrmRegions"></canvas>
            </div>
          </div>
        </div>
      `;
    }

    return "";
  }

  // -------------------------------------------------------------------------
  // INITIALIZE CHARTS WITH CHART.JS
  // -------------------------------------------------------------------------
  function initChartsForModule(m) {
    if (!state.isDataLoaded) return;
    if (typeof Chart === "undefined") return;

    // Destroy existing
    Object.keys(state.chartInstances).forEach(k => {
      try { state.chartInstances[k].destroy(); } catch (e) {}
    });
    state.chartInstances = {};

    const isDark = document.documentElement.classList.contains("dark");
    const textColor = isDark ? "#94A3B8" : "#64748B";
    const gridColor = isDark ? "#1F2943" : "#E2E8F0";

    if (m === "executive") {
      const ctx1 = document.getElementById("chartExecRevCost");
      if (ctx1) {
        state.chartInstances.revCost = new Chart(ctx1, {
          type: "bar",
          data: {
            labels: ["Tháng 6", "Tháng 7", "Tháng 8", "Tháng 9", "Tháng 10", "Tháng 11"],
            datasets: [
              { label: "Doanh thu (Tỷ đ)", data: [2.4, 2.7, 3.1, 3.3, 3.4, 3.55], backgroundColor: "#10B981", borderRadius: 8 },
              { label: "Chi phí (Tỷ đ)", data: [1.6, 1.8, 1.9, 1.95, 2.0, 1.98], backgroundColor: "#F43F5E", borderRadius: 8 },
              { type: "line", label: "Biên LN (%)", data: [33, 33, 38, 40, 41, 44], borderColor: "#FFD027", tension: 0.3, yAxisID: "y1" }
            ]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
              x: { ticks: { color: textColor }, grid: { display: false } },
              y: { ticks: { color: textColor }, grid: { color: gridColor } },
              y1: { position: "right", grid: { display: false }, ticks: { color: "#FFD027" } }
            },
            plugins: { legend: { labels: { color: textColor, boxWidth: 12 } } }
          }
        });
      }

      const ctx2 = document.getElementById("chartExecCostStructure");
      if (ctx2) {
        state.chartInstances.costStructure = new Chart(ctx2, {
          type: "doughnut",
          data: {
            labels: ["Giá vốn linh kiện", "Logistics & Kho bãi", "Lương thưởng CBNV", "Hạ tầng Cloud BI", "Marketing & Khác"],
            datasets: [{
              data: [45, 18, 22, 8, 7],
              backgroundColor: ["#38BDF8", "#F59E0B", "#10B981", "#8B5CF6", "#F43F5E"]
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { position: "bottom", labels: { color: textColor, boxWidth: 10, font: { size: 10 } } } }
          }
        });
      }
    }

    if (m === "hr") {
      const c1 = document.getElementById("chartHrDept");
      if (c1) {
        state.chartInstances.hrDept = new Chart(c1, {
          type: "bar",
          data: {
            labels: ["Ban Giám Đốc", "PTKD (Kinh doanh)", "Tài chính - Kế toán", "Công nghệ & BI", "Kỹ thuật & BH"],
            datasets: [{ label: "Số lượng CBNV", data: [4, 65, 14, 25, 40], backgroundColor: "#38BDF8", borderRadius: 8 }]
          },
          options: {
            responsive: true, maintainAspectRatio: false,
            scales: { x: { ticks: { color: textColor } }, y: { ticks: { color: textColor }, grid: { color: gridColor } } },
            plugins: { legend: { display: false } }
          }
        });
      }

      const c2 = document.getElementById("chartHrKpi");
      if (c2) {
        state.chartInstances.hrKpi = new Chart(c2, {
          type: "line",
          data: {
            labels: ["Tháng 7", "Tháng 8", "Tháng 9", "Tháng 10", "Tháng 11"],
            datasets: [{ label: "Điểm KPI Trung bình", data: [88.5, 90.2, 92.0, 93.5, 94.8], borderColor: "#10B981", backgroundColor: "rgba(16, 185, 129, 0.15)", fill: true, tension: 0.3 }]
          },
          options: {
            responsive: true, maintainAspectRatio: false,
            scales: { x: { ticks: { color: textColor } }, y: { min: 80, max: 100, ticks: { color: textColor }, grid: { color: gridColor } } },
            plugins: { legend: { display: false } }
          }
        });
      }
    }

    if (m === "finance") {
      const c1 = document.getElementById("chartFinanceInflow");
      if (c1) {
        state.chartInstances.financeIn = new Chart(c1, {
          type: "pie",
          data: {
            labels: ["KV1 (Miền Bắc)", "KV2 (Miền Trung)", "KV3 (Miền Nam)"],
            datasets: [{ data: [48, 22, 30], backgroundColor: ["#10B981", "#FFD027", "#38BDF8"] }]
          },
          options: {
            responsive: true, maintainAspectRatio: false,
            plugins: { legend: { position: "bottom", labels: { color: textColor } } }
          }
        });
      }

      const c2 = document.getElementById("chartFinanceCredit");
      if (c2) {
        state.chartInstances.financeCredit = new Chart(c2, {
          type: "bar",
          data: {
            labels: ["Tổng hạn mức cấp", "Đã sử dụng", "Hạn mức còn lại", "Nợ quá hạn"],
            datasets: [{ data: [25, 18.2, 6.8, 0.1], backgroundColor: ["#8B5CF6", "#F59E0B", "#10B981", "#F43F5E"], borderRadius: 8 }]
          },
          options: {
            responsive: true, maintainAspectRatio: false,
            scales: { x: { ticks: { color: textColor } }, y: { ticks: { color: textColor }, grid: { color: gridColor } } },
            plugins: { legend: { display: false } }
          }
        });
      }
    }

    if (m === "crm") {
      const c1 = document.getElementById("chartCrmTiers");
      if (c1) {
        state.chartInstances.crmTiers = new Chart(c1, {
          type: "doughnut",
          data: {
            labels: ["Tier 1 (Chiến lược)", "Tier 2 (Cần bổ sung)", "Tier 3 (Loại trừ/Nợ xấu)"],
            datasets: [{ data: [48, 32, 20], backgroundColor: ["#10B981", "#F59E0B", "#F43F5E"] }]
          },
          options: {
            responsive: true, maintainAspectRatio: false,
            plugins: { legend: { position: "bottom", labels: { color: textColor } } }
          }
        });
      }

      const c2 = document.getElementById("chartCrmRegions");
      if (c2) {
        state.chartInstances.crmRegions = new Chart(c2, {
          type: "bar",
          data: {
            labels: ["Miền Bắc (KV1)", "Miền Trung (KV2)", "Miền Nam (KV3)"],
            datasets: [{ label: "Doanh số (Tỷ đ)", data: [8.5, 4.2, 5.75], backgroundColor: ["#38BDF8", "#FFD027", "#10B981"], borderRadius: 8 }]
          },
          options: {
            responsive: true, maintainAspectRatio: false,
            scales: { x: { ticks: { color: textColor } }, y: { ticks: { color: textColor }, grid: { color: gridColor } } },
            plugins: { legend: { display: false } }
          }
        });
      }
    }
  }

  // -------------------------------------------------------------------------
  // DATA TABLE GENERATOR HTML
  // -------------------------------------------------------------------------
  function getDataTableHtmlForModule(m) {
    const dataList = getFilteredDataList(m);

    return `
      <div class="p-5 sm:p-6 rounded-3xl bg-white dark:bg-brand-card border border-slate-200 dark:border-brand-border shadow-xl space-y-4">
        <!-- Table Search & Filter Toolbar -->
        <div class="flex flex-col sm:flex-row items-center justify-between gap-3">
          <div class="flex items-center space-x-2 w-full sm:w-auto">
            <span class="text-xs font-bold text-slate-500 uppercase">Tìm kiếm:</span>
            <input 
              type="text" 
              placeholder="🔍 Tìm kiếm theo tên, mã, nội dung..." 
              value="${state.searchQuery}"
              oninput="EnterpriseEcosystem.handleSearch(event)"
              class="w-full sm:w-72 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-slate-800 dark:text-white focus:outline-none focus:border-lemon-500"
            />
          </div>

          <div class="flex items-center space-x-2.5 w-full sm:w-auto justify-end">
            <span class="text-xs font-bold text-slate-500 uppercase">Bộ lọc:</span>
            <select onchange="EnterpriseEcosystem.handleFilter(event)" class="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs font-bold text-slate-800 dark:text-white focus:outline-none focus:border-lemon-500 cursor-pointer">
              <option value="ALL" ${state.filterValue === 'ALL' ? 'selected' : ''}>Tất cả bản ghi</option>
              ${getFilterOptionsForModule(m)}
            </select>
            <span class="px-3 py-1 rounded-xl bg-lemon-500/10 text-lemon-500 border border-lemon-500/30 text-xs font-extrabold whitespace-nowrap">
              ${dataList.length} bản ghi
            </span>
          </div>
        </div>

        <!-- The Table -->
        <div class="overflow-x-auto rounded-2xl border border-slate-200 dark:border-brand-border">
          <table class="w-full text-left text-xs">
            <thead class="bg-slate-100 dark:bg-brand-dark text-slate-600 dark:text-slate-400 font-extrabold border-b border-slate-200 dark:border-brand-border">
              ${getTableHeadersForModule(m)}
            </thead>
            <tbody class="divide-y divide-slate-100 dark:divide-brand-border text-slate-800 dark:text-slate-200 font-medium">
              ${getTableRowsForModule(m, dataList)}
            </tbody>
          </table>
        </div>
      </div>
    `;
  }

  function getFilterOptionsForModule(m) {
    if (m === "hr") {
      return `
        <option value="Ban Giám Đốc" ${state.filterValue === 'Ban Giám Đốc' ? 'selected' : ''}>Ban Giám Đốc</option>
        <option value="Phát triển Kinh doanh" ${state.filterValue === 'Phát triển Kinh doanh' ? 'selected' : ''}>Phát triển Kinh doanh</option>
        <option value="Tài chính - Kế toán" ${state.filterValue === 'Tài chính - Kế toán' ? 'selected' : ''}>Tài chính - Kế toán</option>
        <option value="Khối Công nghệ & BI" ${state.filterValue === 'Khối Công nghệ & BI' ? 'selected' : ''}>Khối Công nghệ & BI</option>
      `;
    }
    if (m === "finance") {
      return `
        <option value="THU" ${state.filterValue === 'THU' ? 'selected' : ''}>Khoản Thu</option>
        <option value="CHI" ${state.filterValue === 'CHI' ? 'selected' : ''}>Khoản Chi</option>
        <option value="TÍN DỤNG" ${state.filterValue === 'TÍN DỤNG' ? 'selected' : ''}>Bảo lãnh Tín dụng</option>
      `;
    }
    if (m === "crm") {
      return `
        <option value="Tier 1" ${state.filterValue === 'Tier 1' ? 'selected' : ''}>Tier 1 (Chiến lược)</option>
        <option value="Tier 2" ${state.filterValue === 'Tier 2' ? 'selected' : ''}>Tier 2 (Cần bổ sung)</option>
        <option value="Tier 3" ${state.filterValue === 'Tier 3' ? 'selected' : ''}>Tier 3 (Loại trừ/Nợ xấu)</option>
      `;
    }
    if (m === "project") {
      return `
        <option value="Khẩn cấp" ${state.filterValue === 'Khẩn cấp' ? 'selected' : ''}>Ưu tiên Khẩn cấp</option>
        <option value="Cao" ${state.filterValue === 'Cao' ? 'selected' : ''}>Ưu tiên Cao</option>
        <option value="Đang thực hiện" ${state.filterValue === 'Đang thực hiện' ? 'selected' : ''}>Đang thực hiện</option>
      `;
    }
    return `
      <option value="Miền Bắc (KV1)" ${state.filterValue === 'Miền Bắc (KV1)' ? 'selected' : ''}>Miền Bắc (KV1)</option>
      <option value="Miền Trung (KV2)" ${state.filterValue === 'Miền Trung (KV2)' ? 'selected' : ''}>Miền Trung (KV2)</option>
      <option value="Miền Nam (KV3)" ${state.filterValue === 'Miền Nam (KV3)' ? 'selected' : ''}>Miền Nam (KV3)</option>
    `;
  }

  function getTableHeadersForModule(m) {
    if (m === "executive") {
      return `
        <tr>
          <th class="py-3 px-4">Hạng mục chỉ đạo</th>
          <th class="py-3 px-4">Phòng ban</th>
          <th class="py-3 px-4">Mức độ ưu tiên</th>
          <th class="py-3 px-4">Thời hạn</th>
          <th class="py-3 px-4">Trạng thái</th>
          <th class="py-3 px-4 text-right">Tác vụ</th>
        </tr>
      `;
    }

    if (m === "hr") {
      return `
        <tr>
          <th class="py-3 px-4">Mã NV</th>
          <th class="py-3 px-4">Họ và Tên</th>
          <th class="py-3 px-4">Chức danh / Vị trí</th>
          <th class="py-3 px-4">Phòng ban</th>
          <th class="py-3 px-4">Khu vực</th>
          <th class="py-3 px-4">Điểm KPI</th>
          <th class="py-3 px-4">Mức lương</th>
          <th class="py-3 px-4 text-right">Tác vụ</th>
        </tr>
      `;
    }

    if (m === "finance") {
      return `
        <tr>
          <th class="py-3 px-4">Mã GD</th>
          <th class="py-3 px-4">Loại</th>
          <th class="py-3 px-4">Đối tác / Khách hàng</th>
          <th class="py-3 px-4">Hạng mục</th>
          <th class="py-3 px-4">Số tiền (VNĐ)</th>
          <th class="py-3 px-4">Ngày hạch toán</th>
          <th class="py-3 px-4">Trạng thái</th>
          <th class="py-3 px-4 text-right">Tác vụ</th>
        </tr>
      `;
    }

    if (m === "crm") {
      return `
        <tr>
          <th class="py-3 px-4">Mã ĐL</th>
          <th class="py-3 px-4">Tên Đại Lý / Doanh Nghiệp</th>
          <th class="py-3 px-4">Người đại diện</th>
          <th class="py-3 px-4">Khu vực</th>
          <th class="py-3 px-4">Phân hạng Tier</th>
          <th class="py-3 px-4">Hạn mức tín dụng</th>
          <th class="py-3 px-4">Doanh số Quý</th>
          <th class="py-3 px-4 text-right">Tác vụ</th>
        </tr>
      `;
    }

    if (m === "project") {
      return `
        <tr>
          <th class="py-3 px-4">Mã DA</th>
          <th class="py-3 px-4">Tên Dự Án</th>
          <th class="py-3 px-4">Trưởng DA (PM)</th>
          <th class="py-3 px-4">Ngân sách</th>
          <th class="py-3 px-4">Tiến độ</th>
          <th class="py-3 px-4">Ưu tiên</th>
          <th class="py-3 px-4">Hạn chót</th>
          <th class="py-3 px-4 text-right">Tác vụ</th>
        </tr>
      `;
    }

    if (m === "operations") {
      return `
        <tr>
          <th class="py-3 px-4">Mã Điểm</th>
          <th class="py-3 px-4">Tên Điểm Bán / Showroom / Kho</th>
          <th class="py-3 px-4">Địa chỉ cụ thể</th>
          <th class="py-3 px-4">Khu vực</th>
          <th class="py-3 px-4">Mặt bằng (m²)</th>
          <th class="py-3 px-4">Cự ly 3km</th>
          <th class="py-3 px-4">Trạng thái</th>
          <th class="py-3 px-4 text-right">Tác vụ</th>
        </tr>
      `;
    }

    if (m === "documents") {
      return `
        <tr>
          <th class="py-3 px-4">Mã TL</th>
          <th class="py-3 px-4">Tên Văn Bản / Hồ Sơ Pháp Lý</th>
          <th class="py-3 px-4">Loại văn bản</th>
          <th class="py-3 px-4">Tác giả</th>
          <th class="py-3 px-4">Ngày ban hành</th>
          <th class="py-3 px-4">Bảo mật</th>
          <th class="py-3 px-4">Dung lượng</th>
          <th class="py-3 px-4 text-right">Tác vụ</th>
        </tr>
      `;
    }

    if (m === "communication") {
      return `
        <tr>
          <th class="py-3 px-4">Mã TB</th>
          <th class="py-3 px-4">Tiêu đề thông báo</th>
          <th class="py-3 px-4">Người phát hành</th>
          <th class="py-3 px-4">Đối tượng nhận</th>
          <th class="py-3 px-4">Mức độ</th>
          <th class="py-3 px-4">Ngày gửi</th>
          <th class="py-3 px-4 text-right">Tác vụ</th>
        </tr>
      `;
    }

    if (m === "admin") {
      return `
        <tr>
          <th class="py-3 px-4">Thời gian</th>
          <th class="py-3 px-4">Người thực hiện</th>
          <th class="py-3 px-4">IP / Trạm</th>
          <th class="py-3 px-4">Phân hệ</th>
          <th class="py-3 px-4">Hành động ghi vết</th>
          <th class="py-3 px-4">Cấp độ</th>
          <th class="py-3 px-4 text-right">Tác vụ</th>
        </tr>
      `;
    }

    return "";
  }

  function getTableRowsForModule(m, list) {
    if (!list || list.length === 0) {
      if (!state.isDataLoaded) {
        return `
          <tr>
            <td colspan="8" class="text-center py-12 text-slate-400">
              <div class="text-3xl mb-2">📭</div>
              <div class="font-black text-sm text-slate-300">Hệ thống đang ở trạng thái Chờ (Standby)</div>
              <div class="text-xs text-slate-500 mt-1 max-w-md mx-auto">Chưa có dữ liệu nào được nạp vào phân hệ này. Bấm nút <strong>"Tải Lên Tệp"</strong> hoặc <strong>"Nạp Bộ Dữ Liệu Mẫu Demo"</strong> ở trên để khởi tạo.</div>
            </td>
          </tr>
        `;
      }
      return `
        <tr>
          <td colspan="8" class="text-center py-8 text-slate-400">
            <div class="text-2xl mb-1">📭</div>
            <div class="font-bold">Không tìm thấy bản ghi nào phù hợp.</div>
            <div class="text-[11px] mt-0.5">Thử thay đổi từ khóa tìm kiếm hoặc bấm '+ Thêm mới' để nhập liệu.</div>
          </td>
        </tr>
      `;
    }

    if (m === "executive") {
      return list.map((item, idx) => `
        <tr class="hover:bg-slate-50 dark:hover:bg-brand-dark/50 transition">
          <td class="py-3 px-4 font-bold text-slate-900 dark:text-white">${item.task}</td>
          <td class="py-3 px-4 text-slate-600 dark:text-slate-400">${item.dept}</td>
          <td class="py-3 px-4"><span class="px-2 py-0.5 rounded-full ${item.priority === 'Khẩn cấp' ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30' : 'bg-lemon-500/20 text-lemon-400 border border-lemon-500/30'} text-[10px] font-bold">${item.priority}</span></td>
          <td class="py-3 px-4 font-mono text-[11px]">${item.dueDate}</td>
          <td class="py-3 px-4"><span class="text-emerald-400 font-bold">✓ Đang xử lý</span></td>
          <td class="py-3 px-4 text-right">
            <button onclick="EnterpriseEcosystem.openDetailModal('${item.id}')" class="px-2.5 py-1 rounded-lg bg-brand-input hover:bg-brand-border text-xs font-bold text-slate-200 cursor-pointer">👁️ Chi tiết</button>
          </td>
        </tr>
      `).join("");
    }

    if (m === "hr") {
      return list.map(item => `
        <tr class="hover:bg-slate-50 dark:hover:bg-brand-dark/50 transition">
          <td class="py-3 px-4 font-mono font-bold text-lemon-400">${item.id}</td>
          <td class="py-3 px-4 font-bold text-slate-900 dark:text-white">${item.name}</td>
          <td class="py-3 px-4 text-slate-600 dark:text-slate-400">${item.role}</td>
          <td class="py-3 px-4"><span class="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-brand-input border border-slate-200 dark:border-brand-border text-[11px]">${item.dept}</span></td>
          <td class="py-3 px-4">${item.region}</td>
          <td class="py-3 px-4"><span class="font-bold text-emerald-400">${item.kpi}/100</span></td>
          <td class="py-3 px-4 font-mono font-bold">${Number(item.salary).toLocaleString('vi-VN')} đ</td>
          <td class="py-3 px-4 text-right space-x-1.5 whitespace-nowrap">
            <button onclick="EnterpriseEcosystem.openDetailModal('${item.id}')" class="px-2 py-1 rounded-lg bg-slate-100 dark:bg-brand-input hover:bg-slate-200 dark:hover:bg-brand-border text-xs font-bold cursor-pointer" title="Xem chi tiết">👁️</button>
            <button onclick="EnterpriseEcosystem.openEditModal('${item.id}')" class="px-2 py-1 rounded-lg bg-lemon-500/20 hover:bg-lemon-500/30 text-lemon-400 text-xs font-bold cursor-pointer" title="Chỉnh sửa">✏️</button>
            <button onclick="EnterpriseEcosystem.confirmDelete('${item.id}')" class="px-2 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-400 text-xs font-bold cursor-pointer" title="Xóa">🗑️</button>
          </td>
        </tr>
      `).join("");
    }

    if (m === "finance") {
      return list.map(item => `
        <tr class="hover:bg-slate-50 dark:hover:bg-brand-dark/50 transition">
          <td class="py-3 px-4 font-mono font-bold text-lemon-400">${item.id}</td>
          <td class="py-3 px-4"><span class="px-2 py-0.5 rounded-full ${item.type === 'THU' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : (item.type === 'CHI' ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30' : 'bg-purple-500/20 text-purple-400 border border-purple-500/30')} text-[10px] font-bold">${item.type}</span></td>
          <td class="py-3 px-4 font-bold text-slate-900 dark:text-white">${item.partner}</td>
          <td class="py-3 px-4 text-slate-600 dark:text-slate-400">${item.category}</td>
          <td class="py-3 px-4 font-mono font-bold ${item.type === 'THU' ? 'text-emerald-400' : 'text-rose-400'}">${Number(item.amount).toLocaleString('vi-VN')} đ</td>
          <td class="py-3 px-4 font-mono text-[11px]">${item.date}</td>
          <td class="py-3 px-4"><span class="text-xs font-bold text-emerald-400">✓ ${item.status}</span></td>
          <td class="py-3 px-4 text-right space-x-1.5 whitespace-nowrap">
            <button onclick="EnterpriseEcosystem.openDetailModal('${item.id}')" class="px-2 py-1 rounded-lg bg-slate-100 dark:bg-brand-input hover:bg-slate-200 dark:hover:bg-brand-border text-xs font-bold cursor-pointer" title="Xem chi tiết">👁️</button>
            <button onclick="EnterpriseEcosystem.openEditModal('${item.id}')" class="px-2 py-1 rounded-lg bg-lemon-500/20 hover:bg-lemon-500/30 text-lemon-400 text-xs font-bold cursor-pointer" title="Chỉnh sửa">✏️</button>
            <button onclick="EnterpriseEcosystem.confirmDelete('${item.id}')" class="px-2 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-400 text-xs font-bold cursor-pointer" title="Xóa">🗑️</button>
          </td>
        </tr>
      `).join("");
    }

    if (m === "crm") {
      return list.map(item => `
        <tr class="hover:bg-slate-50 dark:hover:bg-brand-dark/50 transition">
          <td class="py-3 px-4 font-mono font-bold text-lemon-400">${item.id}</td>
          <td class="py-3 px-4 font-bold text-slate-900 dark:text-white">${item.name}</td>
          <td class="py-3 px-4 text-slate-600 dark:text-slate-400">${item.rep}</td>
          <td class="py-3 px-4">${item.region}</td>
          <td class="py-3 px-4"><span class="px-2.5 py-0.5 rounded-full ${item.tier === 'Tier 1' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-black' : (item.tier === 'Tier 2' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30 font-bold' : 'bg-rose-500/20 text-rose-400 border border-rose-500/30')} text-[10px]">${item.tier}</span></td>
          <td class="py-3 px-4 font-mono font-bold text-slate-300">${Number(item.creditLimit).toLocaleString('vi-VN')} đ</td>
          <td class="py-3 px-4 font-mono text-emerald-400 font-bold">${Number(item.qtrSales).toLocaleString('vi-VN')} đ</td>
          <td class="py-3 px-4 text-right space-x-1.5 whitespace-nowrap">
            <button onclick="EnterpriseEcosystem.openDetailModal('${item.id}')" class="px-2 py-1 rounded-lg bg-slate-100 dark:bg-brand-input hover:bg-slate-200 dark:hover:bg-brand-border text-xs font-bold cursor-pointer" title="Xem chi tiết">👁️</button>
            <button onclick="EnterpriseEcosystem.openEditModal('${item.id}')" class="px-2 py-1 rounded-lg bg-lemon-500/20 hover:bg-lemon-500/30 text-lemon-400 text-xs font-bold cursor-pointer" title="Chỉnh sửa">✏️</button>
            <button onclick="EnterpriseEcosystem.confirmDelete('${item.id}')" class="px-2 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-400 text-xs font-bold cursor-pointer" title="Xóa">🗑️</button>
          </td>
        </tr>
      `).join("");
    }

    if (m === "project") {
      return list.map(item => `
        <tr class="hover:bg-slate-50 dark:hover:bg-brand-dark/50 transition">
          <td class="py-3 px-4 font-mono font-bold text-lemon-400">${item.id}</td>
          <td class="py-3 px-4 font-bold text-slate-900 dark:text-white">${item.name}</td>
          <td class="py-3 px-4 text-slate-600 dark:text-slate-400">${item.pm}</td>
          <td class="py-3 px-4 font-mono">${(item.budget / 1e9).toFixed(2)} Tỷ đ</td>
          <td class="py-3 px-4">
            <div class="w-24 bg-brand-dark rounded-full h-2 border border-brand-border overflow-hidden">
              <div class="bg-gradient-to-r from-lemon-500 to-mint-500 h-2 rounded-full" style="width: ${item.progress}%"></div>
            </div>
            <span class="text-[10px] font-mono font-bold mt-0.5 inline-block">${item.progress}%</span>
          </td>
          <td class="py-3 px-4"><span class="px-2 py-0.5 rounded-full ${item.priority === 'Khẩn cấp' ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30' : 'bg-lemon-500/20 text-lemon-400 border border-lemon-500/30'} text-[10px] font-bold">${item.priority}</span></td>
          <td class="py-3 px-4 font-mono text-[11px]">${item.dueDate}</td>
          <td class="py-3 px-4 text-right space-x-1.5 whitespace-nowrap">
            <button onclick="EnterpriseEcosystem.openDetailModal('${item.id}')" class="px-2 py-1 rounded-lg bg-slate-100 dark:bg-brand-input hover:bg-slate-200 dark:hover:bg-brand-border text-xs font-bold cursor-pointer" title="Xem chi tiết">👁️</button>
            <button onclick="EnterpriseEcosystem.openEditModal('${item.id}')" class="px-2 py-1 rounded-lg bg-lemon-500/20 hover:bg-lemon-500/30 text-lemon-400 text-xs font-bold cursor-pointer" title="Chỉnh sửa">✏️</button>
            <button onclick="EnterpriseEcosystem.confirmDelete('${item.id}')" class="px-2 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-400 text-xs font-bold cursor-pointer" title="Xóa">🗑️</button>
          </td>
        </tr>
      `).join("");
    }

    if (m === "operations") {
      return list.map(item => `
        <tr class="hover:bg-slate-50 dark:hover:bg-brand-dark/50 transition">
          <td class="py-3 px-4 font-mono font-bold text-lemon-400">${item.id}</td>
          <td class="py-3 px-4 font-bold text-slate-900 dark:text-white">${item.name}</td>
          <td class="py-3 px-4 text-slate-600 dark:text-slate-400">${item.address}</td>
          <td class="py-3 px-4">${item.region}</td>
          <td class="py-3 px-4 font-mono font-bold">${item.area} m²</td>
          <td class="py-3 px-4"><span class="px-2 py-0.5 rounded-md ${item.compliance.includes('Cảnh báo') ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30 font-bold' : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'} text-[11px]">${item.compliance}</span></td>
          <td class="py-3 px-4"><span class="text-xs font-bold text-slate-300">${item.status}</span></td>
          <td class="py-3 px-4 text-right space-x-1.5 whitespace-nowrap">
            <button onclick="EnterpriseEcosystem.openDetailModal('${item.id}')" class="px-2 py-1 rounded-lg bg-slate-100 dark:bg-brand-input hover:bg-slate-200 dark:hover:bg-brand-border text-xs font-bold cursor-pointer" title="Xem chi tiết">👁️</button>
            <button onclick="EnterpriseEcosystem.openEditModal('${item.id}')" class="px-2 py-1 rounded-lg bg-lemon-500/20 hover:bg-lemon-500/30 text-lemon-400 text-xs font-bold cursor-pointer" title="Chỉnh sửa">✏️</button>
            <button onclick="EnterpriseEcosystem.confirmDelete('${item.id}')" class="px-2 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-400 text-xs font-bold cursor-pointer" title="Xóa">🗑️</button>
          </td>
        </tr>
      `).join("");
    }

    if (m === "documents") {
      return list.map(item => `
        <tr class="hover:bg-slate-50 dark:hover:bg-brand-dark/50 transition">
          <td class="py-3 px-4 font-mono font-bold text-lemon-400">${item.id}</td>
          <td class="py-3 px-4 font-bold text-slate-900 dark:text-white">${item.title}</td>
          <td class="py-3 px-4"><span class="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-brand-input border border-slate-200 dark:border-brand-border text-[11px]">${item.type}</span></td>
          <td class="py-3 px-4 text-slate-600 dark:text-slate-400">${item.author}</td>
          <td class="py-3 px-4 font-mono text-[11px]">${item.issueDate}</td>
          <td class="py-3 px-4"><span class="px-2 py-0.5 rounded-full ${item.security === 'Tuyệt mật' ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30 font-bold' : 'bg-purple-500/20 text-purple-400 border border-purple-500/30'} text-[10px]">${item.security}</span></td>
          <td class="py-3 px-4 font-mono">${item.size}</td>
          <td class="py-3 px-4 text-right space-x-1.5 whitespace-nowrap">
            <button onclick="EnterpriseEcosystem.openDetailModal('${item.id}')" class="px-2 py-1 rounded-lg bg-slate-100 dark:bg-brand-input hover:bg-slate-200 dark:hover:bg-brand-border text-xs font-bold cursor-pointer" title="Xem chi tiết">👁️</button>
            <button onclick="EnterpriseEcosystem.openEditModal('${item.id}')" class="px-2 py-1 rounded-lg bg-lemon-500/20 hover:bg-lemon-500/30 text-lemon-400 text-xs font-bold cursor-pointer" title="Chỉnh sửa">✏️</button>
            <button onclick="EnterpriseEcosystem.confirmDelete('${item.id}')" class="px-2 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-400 text-xs font-bold cursor-pointer" title="Xóa">🗑️</button>
          </td>
        </tr>
      `).join("");
    }

    if (m === "communication") {
      return list.map(item => `
        <tr class="hover:bg-slate-50 dark:hover:bg-brand-dark/50 transition">
          <td class="py-3 px-4 font-mono font-bold text-lemon-400">${item.id}</td>
          <td class="py-3 px-4 font-bold text-slate-900 dark:text-white">${item.title}</td>
          <td class="py-3 px-4 text-slate-600 dark:text-slate-400">${item.author}</td>
          <td class="py-3 px-4">${item.target}</td>
          <td class="py-3 px-4"><span class="px-2 py-0.5 rounded-full ${item.urgency === 'Hỏa tốc' ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30 font-black' : 'bg-lemon-500/20 text-lemon-400 border border-lemon-500/30'} text-[10px]">${item.urgency}</span></td>
          <td class="py-3 px-4 font-mono text-[11px]">${item.date}</td>
          <td class="py-3 px-4 text-right space-x-1.5 whitespace-nowrap">
            <button onclick="EnterpriseEcosystem.openDetailModal('${item.id}')" class="px-2 py-1 rounded-lg bg-slate-100 dark:bg-brand-input hover:bg-slate-200 dark:hover:bg-brand-border text-xs font-bold cursor-pointer" title="Xem chi tiết">👁️</button>
            <button onclick="EnterpriseEcosystem.openEditModal('${item.id}')" class="px-2 py-1 rounded-lg bg-lemon-500/20 hover:bg-lemon-500/30 text-lemon-400 text-xs font-bold cursor-pointer" title="Chỉnh sửa">✏️</button>
            <button onclick="EnterpriseEcosystem.confirmDelete('${item.id}')" class="px-2 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-400 text-xs font-bold cursor-pointer" title="Xóa">🗑️</button>
          </td>
        </tr>
      `).join("");
    }

    if (m === "admin") {
      return list.map(item => `
        <tr class="hover:bg-slate-50 dark:hover:bg-brand-dark/50 transition">
          <td class="py-3 px-4 font-mono text-[11px] text-slate-400">${item.time}</td>
          <td class="py-3 px-4 font-bold text-slate-900 dark:text-white">${item.user}</td>
          <td class="py-3 px-4 font-mono text-[11px]">${item.ip}</td>
          <td class="py-3 px-4"><span class="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-brand-input border border-slate-200 dark:border-brand-border text-[11px]">${item.module}</span></td>
          <td class="py-3 px-4 text-slate-300 font-medium">${item.action}</td>
          <td class="py-3 px-4"><span class="px-2 py-0.5 rounded-full ${item.level === 'WARNING' ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30 font-bold' : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'} text-[10px] font-bold">${item.level}</span></td>
          <td class="py-3 px-4 text-right">
            <span class="text-xs text-slate-500 font-mono">Đã lưu trữ</span>
          </td>
        </tr>
      `).join("");
    }

    return "";
  }

  // Filter & Search Logic
  function getFilteredDataList(m) {
    if (!state.isDataLoaded) return [];

    if (m === "executive") {
      return [
        { id: "EX-1", task: "Ký kết hợp đồng phân phối 48 đại lý Tier 1", dept: "Phát triển Kinh doanh", priority: "Khẩn cấp", dueDate: "2026-11-25", status: "Đang xử lý" },
        { id: "EX-2", task: "Duyệt phương án giải quyết điểm bán 2.8km KV3", dept: "Vận hành & Pháp chế", priority: "Khẩn cấp", dueDate: "2026-11-22", status: "Đang xử lý" },
        { id: "EX-3", task: "Kiểm tra quyết toán dòng tiền quý 4 và quỹ FCF", dept: "Tài chính - Kế toán", priority: "Cao", dueDate: "2026-11-30", status: "Đang xử lý" },
        { id: "EX-4", task: "Đánh giá xếp loại KPI đợt 2 toàn thể CBNV", dept: "Quản trị Nhân sự", priority: "Trung bình", dueDate: "2026-12-05", status: "Đang xử lý" }
      ];
    }

    let list = state.data[m] || [];
    if (!Array.isArray(list)) return [];

    // Filter by category/region/type
    if (state.filterValue && state.filterValue !== "ALL") {
      list = list.filter(item => {
        return (item.region === state.filterValue) ||
               (item.dept === state.filterValue) ||
               (item.type === state.filterValue) ||
               (item.tier === state.filterValue) ||
               (item.priority === state.filterValue);
      });
    }

    // Search query
    if (state.searchQuery && state.searchQuery.trim() !== "") {
      const q = state.searchQuery.toLowerCase().trim();
      list = list.filter(item => {
        return Object.values(item).some(val => String(val).toLowerCase().includes(q));
      });
    }

    return list;
  }

  function handleSearch(e) {
    state.searchQuery = e.target.value;
    renderActiveModuleView();
  }

  function handleFilter(e) {
    state.filterValue = e.target.value;
    renderActiveModuleView();
  }

  // Special view for AI Analytics Module (Links directly into 5-Step BI Engine)
  function renderAnalyticsModuleView(container) {
    const guide = USER_GUIDES.analytics;
    container.innerHTML = `
      <div class="p-5 sm:p-6 rounded-3xl bg-white dark:bg-brand-card border border-slate-200 dark:border-brand-border shadow-xl space-y-5">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div class="space-y-1">
            <div class="flex items-center space-x-2.5">
              <span class="text-2xl">${guide.icon}</span>
              <h2 class="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight">${guide.title}</h2>
              <span class="px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-500 border border-emerald-500/30 text-[10px] font-extrabold uppercase">AI BI ENGINE v2.5</span>
            </div>
            <p class="text-xs sm:text-sm text-slate-500 dark:text-slate-400 max-w-3xl">${guide.part1}</p>
          </div>

          <div class="flex items-center flex-wrap gap-2.5 shrink-0">
            <button onclick="EnterpriseEcosystem.openUserGuide('analytics')" class="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-brand-input hover:bg-slate-200 dark:hover:bg-brand-border text-slate-800 dark:text-slate-200 font-bold text-xs border border-slate-300 dark:border-brand-border flex items-center space-x-1.5 transition cursor-pointer">
              <span>📖 Hướng dẫn sử dụng phân hệ</span>
            </button>
            <button onclick="document.getElementById('workspace').scrollIntoView({ behavior: 'smooth' });" class="px-4 py-2 rounded-xl bg-gradient-to-r from-lemon-500 via-amber-500 to-mint-500 text-brand-dark font-black text-xs shadow-lg shadow-lemon-500/25 flex items-center space-x-2 transition transform active:scale-95 cursor-pointer">
              <span>⚡ Mở Ngay Workspace 5 Bước BI</span>
              <span>↓</span>
            </button>
          </div>
        </div>

        <!-- 5 Steps Quick Nav Cards -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 pt-2">
          <div onclick="goToStep(1); document.getElementById('workspace').scrollIntoView({behavior:'smooth'});" class="p-3.5 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border hover:border-lemon-500 cursor-pointer transition transform hover:-translate-y-1">
            <span class="text-xs font-black text-lemon-400">BƯỚC 1</span>
            <div class="text-sm font-extrabold text-white mt-1">Data Profiling</div>
            <p class="text-[11px] text-slate-400 mt-0.5">Kiểm tra dòng/cột, tỷ lệ missing & xác nhận kế hoạch.</p>
          </div>
          <div onclick="goToStep(2); document.getElementById('workspace').scrollIntoView({behavior:'smooth'});" class="p-3.5 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border hover:border-amber-500 cursor-pointer transition transform hover:-translate-y-1">
            <span class="text-xs font-black text-amber-400">BƯỚC 2</span>
            <div class="text-sm font-extrabold text-white mt-1">Sổ Cái Báo Lỗi</div>
            <p class="text-[11px] text-slate-400 mt-0.5">Chi tiết số dòng, cột lỗi & biện pháp xử lý chuẩn.</p>
          </div>
          <div onclick="goToStep(3); document.getElementById('workspace').scrollIntoView({behavior:'smooth'});" class="p-3.5 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border hover:border-mint-500 cursor-pointer transition transform hover:-translate-y-1">
            <span class="text-xs font-black text-mint-400">BƯỚC 3</span>
            <div class="text-sm font-extrabold text-white mt-1">Kết Quả AI & Feedback</div>
            <p class="text-[11px] text-slate-400 mt-0.5">Chấm điểm Tier, nhận định và vòng lặp phản hồi người dùng.</p>
          </div>
          <div onclick="goToStep(4); document.getElementById('workspace').scrollIntoView({behavior:'smooth'});" class="p-3.5 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border hover:border-purple-500 cursor-pointer transition transform hover:-translate-y-1">
            <span class="text-xs font-black text-purple-400">BƯỚC 4</span>
            <div class="text-sm font-extrabold text-white mt-1">Đánh Giá & Ký Duyệt</div>
            <p class="text-[11px] text-slate-400 mt-0.5">Rà soát, bổ sung góc nhìn và chốt nhận định Lãnh đạo.</p>
          </div>
          <div onclick="goToStep(5); document.getElementById('workspace').scrollIntoView({behavior:'smooth'});" class="p-3.5 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border hover:border-sky-500 cursor-pointer transition transform hover:-translate-y-1">
            <span class="text-xs font-black text-sky-400">BƯỚC 5</span>
            <div class="text-sm font-extrabold text-white mt-1">Multi-Dashboard Suite</div>
            <p class="text-[11px] text-slate-400 mt-0.5">Bộ 6 Dashboard tình trạng & Xuất Excel, Word, HTML.</p>
          </div>
        </div>
      </div>
    `;
  }

  // -------------------------------------------------------------------------
  // CRUD OPERATIONS (ADD, EDIT, DELETE, DETAIL)
  // -------------------------------------------------------------------------
  function openAddModal() {
    state.editingRecordId = null;
    const m = state.activeModule;
    const modal = document.getElementById("enterpriseFormModal");
    const title = document.getElementById("enterpriseFormTitle");
    const body = document.getElementById("enterpriseFormFields");
    if (!modal || !title || !body) return;

    title.textContent = `Thêm Mới Bản Ghi · ${USER_GUIDES[m] ? USER_GUIDES[m].title.split("(")[0].trim() : m.toUpperCase()}`;
    body.innerHTML = getFormFieldsForModule(m, null);

    modal.classList.remove("hidden");
    modal.style.display = "flex";
  }

  function openEditModal(recordId) {
    const m = state.activeModule;
    const list = state.data[m] || [];
    const item = list.find(x => x.id === recordId);
    if (!item) return;

    state.editingRecordId = recordId;
    const modal = document.getElementById("enterpriseFormModal");
    const title = document.getElementById("enterpriseFormTitle");
    const body = document.getElementById("enterpriseFormFields");
    if (!modal || !title || !body) return;

    title.textContent = `Chỉnh Sửa Bản Ghi [${recordId}] · ${USER_GUIDES[m] ? USER_GUIDES[m].title.split("(")[0].trim() : m.toUpperCase()}`;
    body.innerHTML = getFormFieldsForModule(m, item);

    modal.classList.remove("hidden");
    modal.style.display = "flex";
  }

  function closeFormModal() {
    const modal = document.getElementById("enterpriseFormModal");
    if (modal) {
      modal.classList.add("hidden");
      modal.style.display = "none";
    }
  }

  function getFormFieldsForModule(m, data) {
    const isEdit = !!data;

    if (m === "hr") {
      return `
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Mã Nhân Viên *</label>
            <input type="text" id="ef_id" value="${data ? data.id : 'NV-' + String(Date.now()).slice(-3)}" ${isEdit ? 'readonly' : ''} class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white font-mono" required />
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Họ và Tên *</label>
            <input type="text" id="ef_name" value="${data ? data.name : ''}" placeholder="Nhập họ và tên..." class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white" required />
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Chức danh / Vị trí *</label>
            <input type="text" id="ef_role" value="${data ? data.role : ''}" placeholder="Ví dụ: Chuyên viên Kinh doanh..." class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white" required />
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Phòng ban *</label>
            <select id="ef_dept" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white">
              <option value="Phát triển Kinh doanh" ${data && data.dept === 'Phát triển Kinh doanh' ? 'selected' : ''}>Phát triển Kinh doanh</option>
              <option value="Tài chính - Kế toán" ${data && data.dept === 'Tài chính - Kế toán' ? 'selected' : ''}>Tài chính - Kế toán</option>
              <option value="Khối Công nghệ & BI" ${data && data.dept === 'Khối Công nghệ & BI' ? 'selected' : ''}>Khối Công nghệ & BI</option>
              <option value="Kỹ thuật & Dịch vụ" ${data && data.dept === 'Kỹ thuật & Dịch vụ' ? 'selected' : ''}>Kỹ thuật & Dịch vụ</option>
              <option value="Ban Giám Đốc" ${data && data.dept === 'Ban Giám Đốc' ? 'selected' : ''}>Ban Giám Đốc</option>
            </select>
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Khu vực làm việc</label>
            <select id="ef_region" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white">
              <option value="Miền Bắc (KV1)" ${data && data.region.includes('Bắc') ? 'selected' : ''}>Miền Bắc (KV1)</option>
              <option value="Miền Trung (KV2)" ${data && data.region.includes('Trung') ? 'selected' : ''}>Miền Trung (KV2)</option>
              <option value="Miền Nam (KV3)" ${data && data.region.includes('Nam') ? 'selected' : ''}>Miền Nam (KV3)</option>
              <option value="Toàn Quốc" ${data && data.region.includes('Toàn') ? 'selected' : ''}>Toàn Quốc (Hội sở)</option>
            </select>
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Mức lương cơ bản (VNĐ)</label>
            <input type="number" id="ef_salary" value="${data ? data.salary : 25000000}" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white font-mono" />
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Điểm KPI (0 - 100)</label>
            <input type="number" min="0" max="100" id="ef_kpi" value="${data ? data.kpi : 90}" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white font-mono" />
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Số điện thoại liên hệ</label>
            <input type="text" id="ef_phone" value="${data ? data.phone : '0912345678'}" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white" />
          </div>
        </div>
      `;
    }

    if (m === "finance") {
      return `
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Mã Giao Dịch *</label>
            <input type="text" id="ef_id" value="${data ? data.id : 'TC-' + String(Date.now()).slice(-3)}" ${isEdit ? 'readonly' : ''} class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white font-mono" required />
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Loại Nghiệp Vụ *</label>
            <select id="ef_type" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white">
              <option value="THU" ${data && data.type === 'THU' ? 'selected' : ''}>Khoản Thu (Doanh thu về)</option>
              <option value="CHI" ${data && data.type === 'CHI' ? 'selected' : ''}>Khoản Chi (Giải ngân)</option>
              <option value="TÍN DỤNG" ${data && data.type === 'TÍN DỤNG' ? 'selected' : ''}>Bảo lãnh Tín dụng</option>
            </select>
          </div>
          <div class="sm:col-span-2">
            <label class="block text-xs font-bold text-slate-400 mb-1">Đối tác / Đơn vị thụ hưởng *</label>
            <input type="text" id="ef_partner" value="${data ? data.partner : ''}" placeholder="Tên công ty hoặc đại lý..." class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white" required />
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Số tiền (VNĐ) *</label>
            <input type="number" id="ef_amount" value="${data ? data.amount : 100000000}" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white font-mono" required />
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Hạng mục chi phí</label>
            <input type="text" id="ef_category" value="${data ? data.category : 'Doanh thu đại lý'}" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white" />
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Ngày hạch toán</label>
            <input type="date" id="ef_date" value="${data ? data.date : new Date().toISOString().slice(0, 10)}" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white" />
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Cán bộ phê duyệt</label>
            <input type="text" id="ef_approver" value="${data ? data.approver : 'Lê Hoàng Yến'}" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white" />
          </div>
        </div>
      `;
    }

    if (m === "crm") {
      return `
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Mã Đại Lý *</label>
            <input type="text" id="ef_id" value="${data ? data.id : 'DL-' + String(Date.now()).slice(-3)}" ${isEdit ? 'readonly' : ''} class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white font-mono" required />
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Phân hạng Tier *</label>
            <select id="ef_tier" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white font-bold">
              <option value="Tier 1" ${data && data.tier === 'Tier 1' ? 'selected' : ''}>Tier 1 (Đạt chuẩn ký kết ≥80đ)</option>
              <option value="Tier 2" ${data && data.tier === 'Tier 2' ? 'selected' : ''}>Tier 2 (Cần bổ sung 65-79đ)</option>
              <option value="Tier 3" ${data && data.tier === 'Tier 3' ? 'selected' : ''}>Tier 3 (Từ chối / Nợ xấu)</option>
            </select>
          </div>
          <div class="sm:col-span-2">
            <label class="block text-xs font-bold text-slate-400 mb-1">Tên Doanh Nghiệp / Đại Lý *</label>
            <input type="text" id="ef_name" value="${data ? data.name : ''}" placeholder="Nhập tên đại lý..." class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white" required />
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Người đại diện pháp luật</label>
            <input type="text" id="ef_rep" value="${data ? data.rep : ''}" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white" />
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Khu vực phân bổ</label>
            <select id="ef_region" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white">
              <option value="Miền Bắc (KV1)" ${data && data.region.includes('Bắc') ? 'selected' : ''}>Miền Bắc (KV1)</option>
              <option value="Miền Trung (KV2)" ${data && data.region.includes('Trung') ? 'selected' : ''}>Miền Trung (KV2)</option>
              <option value="Miền Nam (KV3)" ${data && data.region.includes('Nam') ? 'selected' : ''}>Miền Nam (KV3)</option>
            </select>
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Hạn mức tín dụng đề xuất (VNĐ)</label>
            <input type="number" id="ef_creditLimit" value="${data ? data.creditLimit : 500000000}" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white font-mono" />
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Số điện thoại liên hệ</label>
            <input type="text" id="ef_phone" value="${data ? data.phone : '0903112233'}" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white" />
          </div>
        </div>
      `;
    }

    if (m === "project") {
      return `
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Mã Dự Án *</label>
            <input type="text" id="ef_id" value="${data ? data.id : 'DA-' + String(Date.now()).slice(-3)}" ${isEdit ? 'readonly' : ''} class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white font-mono" required />
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Mức độ ưu tiên</label>
            <select id="ef_priority" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white">
              <option value="Khẩn cấp" ${data && data.priority === 'Khẩn cấp' ? 'selected' : ''}>Khẩn cấp</option>
              <option value="Cao" ${data && data.priority === 'Cao' ? 'selected' : ''}>Cao</option>
              <option value="Trung bình" ${data && data.priority === 'Trung bình' ? 'selected' : ''}>Trung bình</option>
            </select>
          </div>
          <div class="sm:col-span-2">
            <label class="block text-xs font-bold text-slate-400 mb-1">Tên Dự Án *</label>
            <input type="text" id="ef_name" value="${data ? data.name : ''}" placeholder="Nhập tên dự án..." class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white" required />
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Trưởng Dự Án (PM)</label>
            <input type="text" id="ef_pm" value="${data ? data.pm : 'Trần Minh Quân'}" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white" />
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Ngân sách (VNĐ)</label>
            <input type="number" id="ef_budget" value="${data ? data.budget : 1000000000}" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white font-mono" />
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Tiến độ (%)</label>
            <input type="number" min="0" max="100" id="ef_progress" value="${data ? data.progress : 50}" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white font-mono" />
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Hạn chót bàn giao</label>
            <input type="date" id="ef_dueDate" value="${data ? data.dueDate : '2026-12-31'}" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white" />
          </div>
        </div>
      `;
    }

    if (m === "operations") {
      return `
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Mã Điểm *</label>
            <input type="text" id="ef_id" value="${data ? data.id : 'OP-' + String(Date.now()).slice(-3)}" ${isEdit ? 'readonly' : ''} class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white font-mono" required />
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Khu vực *</label>
            <select id="ef_region" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white">
              <option value="Miền Bắc (KV1)" ${data && data.region.includes('Bắc') ? 'selected' : ''}>Miền Bắc (KV1)</option>
              <option value="Miền Trung (KV2)" ${data && data.region.includes('Trung') ? 'selected' : ''}>Miền Trung (KV2)</option>
              <option value="Miền Nam (KV3)" ${data && data.region.includes('Nam') ? 'selected' : ''}>Miền Nam (KV3)</option>
            </select>
          </div>
          <div class="sm:col-span-2">
            <label class="block text-xs font-bold text-slate-400 mb-1">Tên Điểm Bán / Showroom / Kho *</label>
            <input type="text" id="ef_name" value="${data ? data.name : ''}" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white" required />
          </div>
          <div class="sm:col-span-2">
            <label class="block text-xs font-bold text-slate-400 mb-1">Địa chỉ chi tiết</label>
            <input type="text" id="ef_address" value="${data ? data.address : ''}" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white" />
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Diện tích (m²)</label>
            <input type="number" id="ef_area" value="${data ? data.area : 150}" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white font-mono" />
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Đánh giá bán kính 3km</label>
            <input type="text" id="ef_compliance" value="${data ? data.compliance : '100% Đạt (>3.2km)'}" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white" />
          </div>
        </div>
      `;
    }

    if (m === "documents") {
      return `
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Mã Tài Liệu *</label>
            <input type="text" id="ef_id" value="${data ? data.id : 'TL-' + String(Date.now()).slice(-3)}" ${isEdit ? 'readonly' : ''} class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white font-mono" required />
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Loại văn bản</label>
            <select id="ef_type" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white">
              <option value="Quy chế quản trị" ${data && data.type.includes('Quy chế') ? 'selected' : ''}>Quy chế quản trị</option>
              <option value="Hợp đồng mẫu" ${data && data.type.includes('Hợp đồng') ? 'selected' : ''}>Hợp đồng mẫu</option>
              <option value="Báo cáo điều hành" ${data && data.type.includes('Báo cáo') ? 'selected' : ''}>Báo cáo điều hành</option>
              <option value="Quy định nghiệp vụ" ${data && data.type.includes('Quy định') ? 'selected' : ''}>Quy định nghiệp vụ</option>
            </select>
          </div>
          <div class="sm:col-span-2">
            <label class="block text-xs font-bold text-slate-400 mb-1">Tên Văn Bản / Hồ Sơ *</label>
            <input type="text" id="ef_title" value="${data ? data.title : ''}" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white" required />
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Cán bộ soạn thảo</label>
            <input type="text" id="ef_author" value="${data ? data.author : 'Bùi Hà Uyên'}" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white" />
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Cấp bảo mật</label>
            <select id="ef_security" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white">
              <option value="Nội bộ" ${data && data.security === 'Nội bộ' ? 'selected' : ''}>Nội bộ</option>
              <option value="Tuyệt mật" ${data && data.security === 'Tuyệt mật' ? 'selected' : ''}>Tuyệt mật</option>
              <option value="Lưu hành nội bộ" ${data && data.security.includes('Lưu hành') ? 'selected' : ''}>Lưu hành nội bộ</option>
            </select>
          </div>
        </div>
      `;
    }

    if (m === "communication") {
      return `
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Mã Thông Báo *</label>
            <input type="text" id="ef_id" value="${data ? data.id : 'TB-' + String(Date.now()).slice(-3)}" ${isEdit ? 'readonly' : ''} class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white font-mono" required />
          </div>
          <div>
            <label class="block text-xs font-bold text-slate-400 mb-1">Mức độ khẩn cấp</label>
            <select id="ef_urgency" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white font-bold">
              <option value="Hỏa tốc" ${data && data.urgency === 'Hỏa tốc' ? 'selected' : ''}>Hỏa tốc</option>
              <option value="Quan trọng" ${data && data.urgency === 'Quan trọng' ? 'selected' : ''}>Quan trọng</option>
              <option value="Bình thường" ${data && data.urgency === 'Bình thường' ? 'selected' : ''}>Bình thường</option>
            </select>
          </div>
          <div class="sm:col-span-2">
            <label class="block text-xs font-bold text-slate-400 mb-1">Tiêu Đề Thông Báo *</label>
            <input type="text" id="ef_title" value="${data ? data.title : ''}" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white" required />
          </div>
          <div class="sm:col-span-2">
            <label class="block text-xs font-bold text-slate-400 mb-1">Đối tượng nhận thông báo</label>
            <input type="text" id="ef_target" value="${data ? data.target : 'Toàn thể CBNV & Các Giám đốc Vùng'}" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white" />
          </div>
          <div class="sm:col-span-2">
            <label class="block text-xs font-bold text-slate-400 mb-1">Nội dung thông báo chi tiết</label>
            <textarea id="ef_content" rows="4" class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white">${data ? data.content : ''}</textarea>
          </div>
        </div>
      `;
    }

    return `
      <div>
        <label class="block text-xs font-bold text-slate-400 mb-1">Mã Định Danh *</label>
        <input type="text" id="ef_id" value="${data ? data.id : 'REC-' + Date.now()}" ${isEdit ? 'readonly' : ''} class="w-full px-3 py-2 rounded-xl bg-slate-100 dark:bg-brand-input border border-slate-300 dark:border-brand-border text-xs text-white font-mono" required />
      </div>
    `;
  }

  function saveRecord(e) {
    if (e && e.preventDefault) e.preventDefault();
    const m = state.activeModule;
    if (!state.data[m]) state.data[m] = [];

    const idInput = document.getElementById("ef_id");
    if (!idInput || !idInput.value.trim()) {
      alert("Vui lòng điền mã định danh!");
      return;
    }

    const id = idInput.value.trim();
    const isEdit = !!state.editingRecordId;
    let newRecord = { id };

    // Extract dynamic fields based on module
    if (m === "hr") {
      newRecord.name = document.getElementById("ef_name").value.trim();
      newRecord.role = document.getElementById("ef_role").value.trim();
      newRecord.dept = document.getElementById("ef_dept").value;
      newRecord.region = document.getElementById("ef_region").value;
      newRecord.salary = Number(document.getElementById("ef_salary").value) || 20000000;
      newRecord.kpi = Number(document.getElementById("ef_kpi").value) || 90;
      newRecord.phone = document.getElementById("ef_phone").value.trim();
      newRecord.status = "Chính thức";
      newRecord.joinDate = new Date().toISOString().slice(0, 10);
    } else if (m === "finance") {
      newRecord.type = document.getElementById("ef_type").value;
      newRecord.partner = document.getElementById("ef_partner").value.trim();
      newRecord.amount = Number(document.getElementById("ef_amount").value) || 0;
      newRecord.category = document.getElementById("ef_category").value.trim();
      newRecord.date = document.getElementById("ef_date").value;
      newRecord.approver = document.getElementById("ef_approver").value.trim();
      newRecord.status = "Đã khớp lệnh";
    } else if (m === "crm") {
      newRecord.tier = document.getElementById("ef_tier").value;
      newRecord.name = document.getElementById("ef_name").value.trim();
      newRecord.rep = document.getElementById("ef_rep").value.trim();
      newRecord.region = document.getElementById("ef_region").value;
      newRecord.creditLimit = Number(document.getElementById("ef_creditLimit").value) || 500000000;
      newRecord.phone = document.getElementById("ef_phone").value.trim();
      newRecord.qtrSales = newRecord.creditLimit * 3;
      newRecord.status = "Đang hợp tác";
      newRecord.rating = "Xuất sắc";
    } else if (m === "project") {
      newRecord.name = document.getElementById("ef_name").value.trim();
      newRecord.priority = document.getElementById("ef_priority").value;
      newRecord.pm = document.getElementById("ef_pm").value.trim();
      newRecord.budget = Number(document.getElementById("ef_budget").value) || 1000000000;
      newRecord.progress = Number(document.getElementById("ef_progress").value) || 0;
      newRecord.dueDate = document.getElementById("ef_dueDate").value;
      newRecord.status = "Đang thực hiện";
    } else if (m === "operations") {
      newRecord.name = document.getElementById("ef_name").value.trim();
      newRecord.region = document.getElementById("ef_region").value;
      newRecord.address = document.getElementById("ef_address").value.trim();
      newRecord.area = Number(document.getElementById("ef_area").value) || 120;
      newRecord.compliance = document.getElementById("ef_compliance").value.trim();
      newRecord.status = "Hoạt động tốt";
    } else if (m === "documents") {
      newRecord.title = document.getElementById("ef_title").value.trim();
      newRecord.type = document.getElementById("ef_type").value;
      newRecord.author = document.getElementById("ef_author").value.trim();
      newRecord.security = document.getElementById("ef_security").value;
      newRecord.issueDate = new Date().toISOString().slice(0, 10);
      newRecord.size = "2.1 MB";
    } else if (m === "communication") {
      newRecord.title = document.getElementById("ef_title").value.trim();
      newRecord.urgency = document.getElementById("ef_urgency").value;
      newRecord.author = "Ban Giám Đốc";
      newRecord.target = document.getElementById("ef_target").value.trim();
      newRecord.content = document.getElementById("ef_content").value.trim();
      newRecord.date = new Date().toISOString().slice(0, 10);
    }

    if (isEdit) {
      const idx = state.data[m].findIndex(x => x.id === id);
      if (idx >= 0) {
        state.data[m][idx] = { ...state.data[m][idx], ...newRecord };
      }
      showToastNotification(`Đã cập nhật thành công bản ghi [${id}]`);
    } else {
      state.data[m].unshift(newRecord);
      showToastNotification(`Đã thêm mới thành công bản ghi [${id}]`);
    }

    // Add Audit Log Entry
    if (state.data.admin) {
      state.data.admin.unshift({
        time: new Date().toLocaleString("vi-VN"),
        user: "Quản trị viên (Admin)",
        ip: "127.0.0.1",
        module: m.toUpperCase(),
        action: `${isEdit ? 'Cập nhật' : 'Thêm mới'} bản ghi [${id}]`,
        level: "INFO"
      });
    }

    saveStateToStorage();
    closeFormModal();
    renderActiveModuleView();
    try { playSuccessChime(); } catch (e) {}
  }

  // -------------------------------------------------------------------------
  // DELETE CONFIRMATION
  // -------------------------------------------------------------------------
  function confirmDelete(recordId) {
    state.deletingRecordId = recordId;
    const modal = document.getElementById("enterpriseDeleteModal");
    const label = document.getElementById("enterpriseDeleteTargetLabel");
    if (!modal) return;
    if (label) label.textContent = `Bản ghi mã: [${recordId}]`;

    modal.classList.remove("hidden");
    modal.style.display = "flex";
  }

  function closeDeleteModal() {
    state.deletingRecordId = null;
    const modal = document.getElementById("enterpriseDeleteModal");
    if (modal) {
      modal.classList.add("hidden");
      modal.style.display = "none";
    }
  }

  function executeDelete() {
    const id = state.deletingRecordId;
    if (!id) return;
    const m = state.activeModule;

    if (state.data[m]) {
      state.data[m] = state.data[m].filter(x => x.id !== id);
    }

    // Add Audit Log
    if (state.data.admin) {
      state.data.admin.unshift({
        time: new Date().toLocaleString("vi-VN"),
        user: "Quản trị viên (Admin)",
        ip: "127.0.0.1",
        module: m.toUpperCase(),
        action: `Xóa bản ghi [${id}]`,
        level: "WARNING"
      });
    }

    saveStateToStorage();
    closeDeleteModal();
    renderActiveModuleView();
    showToastNotification(`Đã xóa thành công bản ghi [${id}] khỏi hệ thống`);
    try { playBeep(420, "sine", 0.08); } catch (e) {}
  }

  // -------------------------------------------------------------------------
  // DETAIL VIEW MODAL
  // -------------------------------------------------------------------------
  function openDetailModal(recordId) {
    const m = state.activeModule;
    const list = state.data[m] || (m === "executive" ? getFilteredDataList("executive") : []);
    const item = list.find(x => x.id === recordId);
    if (!item) return;

    const modal = document.getElementById("enterpriseDetailModal");
    const title = document.getElementById("enterpriseDetailTitle");
    const body = document.getElementById("enterpriseDetailBody");
    if (!modal || !title || !body) return;

    title.textContent = `Hồ Sơ Chi Tiết [${recordId}] · ${USER_GUIDES[m] ? USER_GUIDES[m].title.split("(")[0].trim() : m.toUpperCase()}`;

    let html = `<div class="space-y-4">`;
    html += `
      <div class="p-4 rounded-2xl bg-slate-100 dark:bg-brand-dark border border-slate-200 dark:border-brand-border flex items-center justify-between">
        <div>
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Mã Hồ Sơ Quản Trị</div>
          <div class="text-xl font-black text-lemon-400 font-mono">${item.id}</div>
        </div>
        <span class="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-extrabold">Đã Kiểm Định</span>
      </div>
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
    `;

    Object.keys(item).forEach(key => {
      if (key === "id") return;
      let val = item[key];
      if (typeof val === "number" && (key.includes("salary") || key.includes("amount") || key.includes("budget") || key.includes("credit") || key.includes("Sales"))) {
        val = Number(val).toLocaleString("vi-VN") + " VNĐ";
      }
      html += `
        <div class="p-3 rounded-xl bg-slate-50 dark:bg-brand-input/40 border border-slate-200 dark:border-brand-border/60">
          <div class="text-[10px] font-extrabold text-slate-500 uppercase">${key}</div>
          <div class="text-xs font-bold text-slate-900 dark:text-white mt-0.5 break-words">${val}</div>
        </div>
      `;
    });

    html += `
      </div>
      <div class="p-3.5 rounded-2xl bg-lemon-500/10 border border-lemon-500/30 text-xs space-y-1">
        <div class="font-extrabold text-lemon-400">Niêm Phong Chứng Thực HA UIEN SYSTEMS</div>
        <p class="text-[11px] text-slate-400">Bản ghi được đồng bộ trên hạ tầng cơ sở dữ liệu nội bộ New York và 3 khu vực toàn quốc. Được giám sát bởi Trí tuệ nhân tạo Ha Uien.</p>
      </div>
    </div>`;

    body.innerHTML = html;
    modal.classList.remove("hidden");
    modal.style.display = "flex";
  }

  function closeDetailModal() {
    const modal = document.getElementById("enterpriseDetailModal");
    if (modal) {
      modal.classList.add("hidden");
      modal.style.display = "none";
    }
  }

  // -------------------------------------------------------------------------
  // 7-PART COMPREHENSIVE USER GUIDE MODAL
  // -------------------------------------------------------------------------
  function openUserGuide(moduleId) {
    const g = USER_GUIDES[moduleId] || USER_GUIDES.executive;
    const modal = document.getElementById("enterpriseGuideModal");
    const title = document.getElementById("enterpriseGuideTitle");
    const body = document.getElementById("enterpriseGuideBody");
    if (!modal || !title || !body) return;

    title.innerHTML = `<span>${g.icon}</span><span>Hướng Dẫn Sử Dụng: ${g.title}</span>`;

    body.innerHTML = `
      <div class="space-y-6 text-xs leading-relaxed text-slate-700 dark:text-slate-300">
        <!-- 1. Giới thiệu chức năng -->
        <div class="space-y-2 p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="flex items-center space-x-2 text-sm font-black text-lemon-400">
            <span>1.</span>
            <span>Giới Thiệu Chức Năng & Vai Trò</span>
          </div>
          <p>${g.part1}</p>
        </div>

        <!-- 2. Hướng dẫn bắt đầu -->
        <div class="space-y-2 p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="flex items-center space-x-2 text-sm font-black text-sky-400">
            <span>2.</span>
            <span>Hướng Dẫn Bắt Đầu & Điều Kiện Tiên Quyết</span>
          </div>
          <p>${g.part2}</p>
        </div>

        <!-- 3. Các bước thực hiện -->
        <div class="space-y-2 p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="flex items-center space-x-2 text-sm font-black text-mint-400">
            <span>3.</span>
            <span>Quy Trình Các Bước Thao Tác Chuẩn</span>
          </div>
          <div class="whitespace-pre-line font-medium">${g.part3}</div>
        </div>

        <!-- 4. Giải thích các trường dữ liệu -->
        <div class="space-y-2 p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="flex items-center space-x-2 text-sm font-black text-amber-400">
            <span>4.</span>
            <span>Giải Thích Các Trường Dữ Liệu & Quy Tắc Hợp Lệ</span>
          </div>
          <div class="whitespace-pre-line font-medium">${g.part4}</div>
        </div>

        <!-- 5. Hướng dẫn kết quả sau thao tác -->
        <div class="space-y-2 p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="flex items-center space-x-2 text-sm font-black text-purple-400">
            <span>5.</span>
            <span>Kết Quả Đầu Ra & Liên Đới Giữa Các Phân Hệ</span>
          </div>
          <p>${g.part5}</p>
        </div>

        <!-- 6. FAQ -->
        <div class="space-y-2 p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="flex items-center space-x-2 text-sm font-black text-rose-400">
            <span>6.</span>
            <span>Câu Hỏi Thường Gặp (FAQ)</span>
          </div>
          <div class="whitespace-pre-line font-medium">${g.part6}</div>
        </div>

        <!-- 7. Trợ giúp khi xảy ra lỗi -->
        <div class="space-y-2 p-4 rounded-2xl bg-slate-50 dark:bg-brand-dark border border-slate-200 dark:border-brand-border">
          <div class="flex items-center space-x-2 text-sm font-black text-rose-400">
            <span>7.</span>
            <span>Trợ Giúp Khắc Phục Lỗi & Hỗ Trợ 24/7</span>
          </div>
          <p>${g.part7}</p>
          <div class="pt-2 text-[11px] text-slate-400 border-t border-brand-border flex items-center justify-between">
            <span>Hotline Kỹ Thuật HA UIEN: <strong>0816710189</strong></span>
            <span>Email: <strong>buihauyen121007@gmail.com</strong></span>
          </div>
        </div>
      </div>
    `;

    modal.classList.remove("hidden");
    modal.style.display = "flex";
  }

  function closeUserGuideModal() {
    const modal = document.getElementById("enterpriseGuideModal");
    if (modal) {
      modal.classList.add("hidden");
      modal.style.display = "none";
    }
  }

  // -------------------------------------------------------------------------
  // EXPORT CURRENT MODULE DATA TO EXCEL / CSV
  // -------------------------------------------------------------------------
  function exportCurrentModuleData() {
    const m = state.activeModule;
    const list = getFilteredDataList(m);
    if (!list || list.length === 0) {
      alert("Không có dữ liệu để xuất!");
      return;
    }

    if (typeof XLSX === "undefined") {
      alert("Thư viện SheetJS chưa sẵn sàng!");
      return;
    }

    const ws = XLSX.utils.json_to_sheet(list);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, m.toUpperCase());

    const dateStr = new Date().toISOString().slice(0, 10);
    const fileName = `HA_UIEN_SYSTEMS_${m.toUpperCase()}_${dateStr}.xlsx`;
    XLSX.writeFile(wb, fileName);

    showToastNotification(`Đã xuất thành công: ${fileName}`);
    try { playSuccessChime(); } catch (e) {}
  }

  // -------------------------------------------------------------------------
  // HEADER SEARCH INTEGRATION
  // -------------------------------------------------------------------------
  function setupHeaderSearch() {
    const input = document.getElementById("siteSearchInput");
    const results = document.getElementById("siteSearchResults");
    if (!input || !results) return;

    input.addEventListener("input", (e) => {
      const q = e.target.value.toLowerCase().trim();
      if (!q || q.length < 2) {
        results.classList.add("hidden");
        results.innerHTML = "";
        return;
      }

      // Search across all modules
      let matches = [];
      const modules = [
        { id: "executive", name: "Executive Dashboard", icon: "🏢" },
        { id: "hr", name: "Quản trị Nhân sự", icon: "👥" },
        { id: "finance", name: "Tài chính & Dòng tiền", icon: "💰" },
        { id: "crm", name: "CRM & Mạng lưới Đối tác", icon: "🤝" },
        { id: "project", name: "Quản lý Dự án", icon: "🚀" },
        { id: "operations", name: "Vận hành Điểm bán", icon: "⚙️" },
        { id: "analytics", name: "Phân tích Dữ liệu BI", icon: "🧠" },
        { id: "documents", name: "Quản lý Tài liệu", icon: "📁" },
        { id: "communication", name: "Truyền thông Nội bộ", icon: "💬" },
        { id: "admin", name: "Quản trị Hệ thống", icon: "🛡️" }
      ];

      // Match module names
      modules.forEach(mod => {
        if (mod.name.toLowerCase().includes(q)) {
          matches.push({ type: "Phân hệ", title: mod.name, icon: mod.icon, action: () => switchModule(mod.id) });
        }
      });

      // Match records inside modules
      ["hr", "finance", "crm", "project", "operations", "documents", "communication"].forEach(modKey => {
        const arr = state.data[modKey] || [];
        arr.forEach(item => {
          const text = Object.values(item).join(" ").toLowerCase();
          if (text.includes(q)) {
            const title = item.name || item.title || item.partner || item.id;
            matches.push({
              type: modKey.toUpperCase(),
              title: `${title} (${item.id})`,
              icon: "📄",
              action: () => {
                switchModule(modKey);
                setTimeout(() => openDetailModal(item.id), 150);
              }
            });
          }
        });
      });

      if (matches.length === 0) {
        results.innerHTML = `<div class="p-3 text-xs text-slate-400 text-center">Không tìm thấy kết quả nào cho "${q}"</div>`;
      } else {
        let html = `<div class="p-1 space-y-1 max-h-72 overflow-y-auto">`;
        matches.slice(0, 8).forEach((m, idx) => {
          html += `
            <div onclick="EnterpriseEcosystem.handleSearchResultClick(${idx})" class="p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-brand-card cursor-pointer flex items-center justify-between text-xs transition">
              <div class="flex items-center space-x-2 font-bold text-slate-800 dark:text-white">
                <span>${m.icon}</span>
                <span>${m.title}</span>
              </div>
              <span class="text-[10px] text-lemon-400 font-extrabold uppercase">${m.type}</span>
            </div>
          `;
        });
        html += `</div>`;
        results.innerHTML = html;
        window.__activeSearchMatches = matches;
      }

      results.classList.remove("hidden");
    });

    document.addEventListener("click", (e) => {
      if (!input.contains(e.target) && !results.contains(e.target)) {
        results.classList.add("hidden");
      }
    });
  }

  function handleSearchResultClick(idx) {
    const results = document.getElementById("siteSearchResults");
    if (results) results.classList.add("hidden");
    const matches = window.__activeSearchMatches;
    if (matches && matches[idx] && typeof matches[idx].action === "function") {
      matches[idx].action();
    }
  }

  // Toast Notification
  function showToastNotification(msg) {
    if (typeof showNotification === "function") {
      showNotification(msg);
      return;
    }
    const el = document.createElement("div");
    el.className = "fixed bottom-5 right-5 z-[99999] bg-brand-card text-white text-xs font-bold px-4 py-3 rounded-2xl border border-lemon-500/50 shadow-2xl flex items-center space-x-2 animate-bounce";
    el.innerHTML = `<span>⚡</span><span>${msg}</span>`;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 4000);
  }

  // Public API
  return {
    refreshLanguage: function(lang) { renderModuleTabs(); renderActiveModuleView(); },
    init,
    switchModule,
    handleSearch,
    handleFilter,
    openAddModal,
    openEditModal,
    closeFormModal,
    saveRecord,
    confirmDelete,
    closeDeleteModal,
    executeDelete,
    openDetailModal,
    closeDetailModal,
    openUserGuide,
    closeUserGuideModal,
    exportCurrentModuleData,
    handleSearchResultClick,
    loadDemoSampleData,
    clearDataToStandby,
    triggerEnterpriseFileUpload,
    handleEnterpriseFileUpload
  };
})();

// Auto-run on DOMContentLoaded
window.addEventListener("DOMContentLoaded", () => {
  EnterpriseEcosystem.init();
});

