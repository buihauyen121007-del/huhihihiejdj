/**
 * HA UIEN SYSTEMS PARTNER AI AGENT - CORE ENGINE
 * Implements Multi-Skill Business Rules, Entity Resolution, Territory Geofencing,
 * Credit Policy Audit, Sales Commitment Verification, Scoring Matrix & Email Generation.
 */

// 1. Master Data: Existing Active Partners of HA UIEN SYSTEMS across 3 Regions
const MASTER_PARTNERS = [
  {
    partner_id: "DT-MB-001",
    name: "Công ty TNHH Điện máy Việt Long",
    tax_id: "0102345678",
    owner: "Trần Văn Long",
    phone: "0912345678",
    region_id: "KV1",
    region_name: "Miền Bắc",
    store_address: "Số 142 Đường Cầu Giấy, Phường Quan Hoa, Quận Cầu Giấy, Hà Nội",
    district: "Quận Cầu Giấy",
    lat: 21.0365,
    lng: 105.7958,
    protection_status: "Độc quyền Cấp 1",
    protection_radius_km: 3.0,
    credit_status: "Tốt - Hạn mức 800tr (đã có bảo lãnh)",
    monthly_volume: 1200
  },
  {
    partner_id: "DT-MB-002",
    name: "Điện máy Thành Phát",
    tax_id: "0103456789",
    owner: "Hoàng Văn Tuấn",
    phone: "0987654321",
    region_id: "KV1",
    region_name: "Miền Bắc",
    store_address: "Số 58 Lê Duẩn, Phường Cửa Nam, Quận Hoàn Kiếm, Hà Nội",
    district: "Quận Hoàn Kiếm",
    lat: 21.0227,
    lng: 105.8415,
    protection_status: "Độc quyền Cấp 1",
    protection_radius_km: 3.0,
    credit_status: "Tốt - Hạn mức 500tr",
    monthly_volume: 850
  },
  {
    partner_id: "DT-MB-003",
    name: "Đại lý Hoàng Phát (Cũ - Nợ xấu)",
    tax_id: "0109988776",
    owner: "Nguyễn Văn Đạt",
    phone: "0903334455",
    region_id: "KV1",
    region_name: "Miền Bắc",
    store_address: "Số 210 Quang Trung, Phường Quang Trung, Quận Hà Đông, Hà Nội",
    district: "Quận Hà Đông",
    lat: 20.9723,
    lng: 105.7774,
    protection_status: "Đã chấm dứt do nợ xấu",
    protection_radius_km: 0,
    credit_status: "Nợ xấu Nhóm 3 (Còn nợ quá hạn 180 triệu VNĐ)",
    monthly_volume: 0
  },
  {
    partner_id: "DT-MT-001",
    name: "Công ty Cổ phần Thương mại Sông Hàn",
    tax_id: "0401122334",
    owner: "Lê Quang Vinh",
    phone: "0905123456",
    region_id: "KV2",
    region_name: "Miền Trung",
    store_address: "Số 320 Nguyễn Tri Phương, Phường Hòa Thuận Tây, Quận Hải Châu, Đà Nẵng",
    district: "Quận Hải Châu",
    lat: 16.0544,
    lng: 108.2022,
    protection_status: "Độc quyền Cấp 1",
    protection_radius_km: 3.0,
    credit_status: "Tốt - Hạn mức 600tr",
    monthly_volume: 950
  },
  {
    partner_id: "DT-MT-002",
    name: "Điện gia dụng Cố Đô",
    tax_id: "3300554433",
    owner: "Phạm Thị Hương",
    phone: "0914567890",
    region_id: "KV2",
    region_name: "Miền Trung",
    store_address: "Số 15 Hùng Vương, Phường Phú Hội, TP. Huế, Thừa Thiên Huế",
    district: "TP. Huế",
    lat: 16.4674,
    lng: 107.5905,
    protection_status: "Độc quyền Cấp 1",
    protection_radius_km: 3.0,
    credit_status: "Tốt - Hạn mức 400tr",
    monthly_volume: 600
  },
  {
    partner_id: "DT-MN-001",
    name: "Công ty TNHH Bách Khoa Sài Gòn",
    tax_id: "0304567891",
    owner: "Võ Văn Kiệt",
    phone: "0908889900",
    region_id: "KV3",
    region_name: "Miền Nam",
    store_address: "Số 450 Cách Mạng Tháng Tám, Phường 11, Quận 3, TP. Hồ Chí Minh",
    district: "Quận 3",
    lat: 10.7831,
    lng: 106.6715,
    protection_status: "Độc quyền Cấp 1",
    protection_radius_km: 3.0,
    credit_status: "Tốt - Hạn mức 1 tỷ (Bảo lãnh Vietcombank)",
    monthly_volume: 1800
  },
  {
    partner_id: "DT-MN-002",
    name: "Hệ thống Phân phối Miền Tây Xanh",
    tax_id: "1801239876",
    owner: "Đặng Minh Tâm",
    phone: "0939112233",
    region_id: "KV3",
    region_name: "Miền Nam",
    store_address: "Số 88 Đường 30 Tháng 4, Phường An Phú, Quận Ninh Kiều, Cần Thơ",
    district: "Quận Ninh Kiều",
    lat: 10.0342,
    lng: 105.7825,
    protection_status: "Độc quyền Cấp 1",
    protection_radius_km: 3.0,
    credit_status: "Tốt - Hạn mức 700tr",
    monthly_volume: 1100
  }
];

// 2. Company Policies and Rules
const COMPANY_POLICIES = {
  company_name: "HA UIEN SYSTEMS",
  territory: {
    protection_radius_km: 3.0,
    borderline_radius_km: 3.5,
    exclusive_district_protection: true
  },
  credit: {
    standard_max_days: 30,
    standard_max_limit_vnd: 500000000,
    exception_max_days: 45,
    exception_max_limit_vnd: 1000000000,
    knockout_days_threshold: 45,
    knockout_limit_threshold: 1000000000
  },
  warranty: {
    min_technicians: 2,
    max_sla_hours: 48,
    require_service_center: true
  },
  sales_audit: {
    unverified_high_threshold: 1000,
    min_volume_per_sqm: 5
  },
  scoring_weights: {
    location: 25,
    warranty: 25,
    financial: 25,
    commitment: 25
  }
};

// 3. Pre-built Datasets
const SAMPLE_DATASETS = {
  standard: [
    {
      id: "HS-2026-001",
      applicant_name: "Công ty Cổ phần Thương mại Minh Châu",
      brand_name: "Siêu thị Gia dụng Minh Châu",
      tax_id: "0108876543",
      representative: "Lê Minh Châu",
      phone: "0918776655",
      email: "contact@minhchau-appliances.vn",
      region_id: "KV1",
      region_name: "Miền Bắc",
      store_address: "Số 420 Nguyễn Văn Cừ, Phường Gia Thụy, Quận Long Biên, Hà Nội",
      district: "Quận Long Biên",
      lat: 21.0489,
      lng: 105.8821,
      showroom_area_sqm: 160,
      has_warehouse: true,
      warranty_capacity: {
        has_service_center: true,
        center_address: "Số 420 Nguyễn Văn Cừ, Long Biên",
        certified_technicians_count: 4,
        commit_sla_hours: 24,
        warranty_evidence_attached: true
      },
      sales_commitment: {
        monthly_volume_units: 800,
        quarterly_turnover_vnd: 2400000000,
        has_past_vat_invoices: true,
        notes: "Đã kinh doanh điện tử gia dụng 5 năm tại Long Biên, có tệp 12.000 khách hàng thân thiết."
      },
      commercial_requests: {
        requested_credit_days: 25,
        requested_credit_limit_vnd: 400000000,
        requested_discount_pct: 12.5,
        has_bank_guarantee: false,
        signboard_support_requested: true
      }
    },
    {
      id: "HS-2026-002",
      applicant_name: "Công ty TNHH Thương mại Dịch vụ Phát Đạt Mới",
      brand_name: "Điện máy Phát Đạt 88",
      tax_id: "0109988776",
      representative: "Nguyễn Văn Đạt",
      phone: "0903334455",
      email: "phatdatmoi88@gmail.com",
      region_id: "KV1",
      region_name: "Miền Bắc",
      store_address: "Số 218 Quang Trung, Phường Quang Trung, Quận Hà Đông, Hà Nội",
      district: "Quận Hà Đông",
      lat: 20.9728,
      lng: 105.7780,
      showroom_area_sqm: 120,
      has_warehouse: true,
      warranty_capacity: {
        has_service_center: true,
        center_address: "218 Quang Trung, Hà Đông",
        certified_technicians_count: 2,
        commit_sla_hours: 48,
        warranty_evidence_attached: false
      },
      sales_commitment: {
        monthly_volume_units: 900,
        quarterly_turnover_vnd: 2700000000,
        has_past_vat_invoices: false,
        notes: "Cam kết nhập 900 quạt và nồi cơm/tháng."
      },
      commercial_requests: {
        requested_credit_days: 30,
        requested_credit_limit_vnd: 500000000,
        requested_discount_pct: 15.0,
        has_bank_guarantee: false,
        signboard_support_requested: true
      }
    },
    {
      id: "HS-2026-003",
      applicant_name: "Công ty TNHH Thiết bị Điện máy Ánh Dương",
      brand_name: "Điện máy Ánh Dương Cầu Giấy",
      tax_id: "0107765412",
      representative: "Vũ Ánh Dương",
      phone: "0934567123",
      email: "anhduong.appliance@gmail.com",
      region_id: "KV1",
      region_name: "Miền Bắc",
      store_address: "Số 198 Đường Cầu Giấy, Phường Dịch Vọng, Quận Cầu Giấy, Hà Nội",
      district: "Quận Cầu Giấy",
      lat: 21.0348,
      lng: 105.7925,
      showroom_area_sqm: 110,
      has_warehouse: true,
      warranty_capacity: {
        has_service_center: true,
        center_address: "Ngõ 198 Cầu Giấy",
        certified_technicians_count: 3,
        commit_sla_hours: 24,
        warranty_evidence_attached: true
      },
      sales_commitment: {
        monthly_volume_units: 750,
        quarterly_turnover_vnd: 2250000000,
        has_past_vat_invoices: true,
        notes: "Mở rộng kênh bán thiết bị gia dụng HA UIEN SYSTEMS tại trục Cầu Giấy."
      },
      commercial_requests: {
        requested_credit_days: 30,
        requested_credit_limit_vnd: 450000000,
        requested_discount_pct: 13.0,
        has_bank_guarantee: false,
        signboard_support_requested: true
      }
    },
    {
      id: "HS-2026-004",
      applicant_name: "Công ty CP Đầu tư & Xuất Nhập Khẩu Toàn Cầu Thịnh Vượng",
      brand_name: "Mega Mart Thịnh Vượng",
      tax_id: "0316654321",
      representative: "Bùi Quốc Toàn",
      phone: "0977889911",
      email: "ceo@thinhvuongglobal.vn",
      region_id: "KV3",
      region_name: "Miền Nam",
      store_address: "Số 52 Võ Văn Tần, Phường Võ Thị Sáu, Quận 3, TP. Hồ Chí Minh",
      district: "Quận 3",
      lat: 10.7765,
      lng: 106.6892,
      showroom_area_sqm: 35,
      has_warehouse: false,
      warranty_capacity: {
        has_service_center: false,
        center_address: "",
        certified_technicians_count: 0,
        commit_sla_hours: 72,
        warranty_evidence_attached: false
      },
      sales_commitment: {
        monthly_volume_units: 6000,
        quarterly_turnover_vnd: 18000000000,
        has_past_vat_invoices: false,
        notes: "Cam kết số lượng cực lớn 6.000 máy/tháng khắp miền Nam. Nhân viên kinh doanh sơ bộ rất ưu tiên vì doanh số lớn."
      },
      commercial_requests: {
        requested_credit_days: 90,
        requested_credit_limit_vnd: 2500000000,
        requested_discount_pct: 25.0,
        has_bank_guarantee: false,
        signboard_support_requested: true
      }
    },
    {
      id: "HS-2026-005",
      applicant_name: "Công ty TNHH Điện máy Sông Hương",
      brand_name: "Trung tâm Mua sắm Sông Hương",
      tax_id: "3300991122",
      representative: "Nguyễn Hoàng Nam",
      phone: "0913456781",
      email: "dienmaysonghuong@hue.vn",
      region_id: "KV2",
      region_name: "Miền Trung",
      store_address: "Số 245 Bà Triệu, Phường Xuân Phú, TP. Huế, Thừa Thiên Huế",
      district: "TP. Huế",
      lat: 16.4601,
      lng: 107.6015,
      showroom_area_sqm: 95,
      has_warehouse: true,
      warranty_capacity: {
        has_service_center: true,
        center_address: "245 Bà Triệu, TP. Huế",
        certified_technicians_count: 1,
        commit_sla_hours: 48,
        warranty_evidence_attached: false
      },
      sales_commitment: {
        monthly_volume_units: 450,
        quarterly_turnover_vnd: 1350000000,
        has_past_vat_invoices: true,
        notes: "Có cửa hàng mặt tiền Bà Triệu, muốn làm đại lý quạt điện và máy lọc nước."
      },
      commercial_requests: {
        requested_credit_days: 30,
        requested_credit_limit_vnd: 350000000,
        requested_discount_pct: 12.0,
        has_bank_guarantee: false,
        signboard_support_requested: true
      }
    },
    {
      id: "HS-2026-006",
      applicant_name: "Công ty Cổ phần Đầu tư & Thương mại Bình Dương Eco",
      brand_name: "Gia dụng Xanh Bình Dương",
      tax_id: "3702112233",
      representative: "Phạm Văn Bình",
      phone: "0909667788",
      email: "info@binhduongeco.com.vn",
      region_id: "KV3",
      region_name: "Miền Nam",
      store_address: "Số 150 Đại lộ Bình Dương, Phường Phú Hòa, TP. Thủ Dầu Một, Bình Dương",
      district: "TP. Thủ Dầu Một",
      lat: 10.9805,
      lng: 106.6745,
      showroom_area_sqm: 220,
      has_warehouse: true,
      warranty_capacity: {
        has_service_center: true,
        center_address: "Số 150 Đại lộ Bình Dương",
        certified_technicians_count: 3,
        commit_sla_hours: 24,
        warranty_evidence_attached: true
      },
      sales_commitment: {
        monthly_volume_units: 1100,
        quarterly_turnover_vnd: 3300000000,
        has_past_vat_invoices: true,
        notes: "Showroom 220m2 mặt tiền lớn, trung tâm bảo hành đạt chuẩn, có hóa đơn VAT chứng minh doanh thu năm 2025."
      },
      commercial_requests: {
        requested_credit_days: 30,
        requested_credit_limit_vnd: 500000000,
        requested_discount_pct: 13.5,
        has_bank_guarantee: false,
        signboard_support_requested: true
      }
    },
    {
      id: "HS-2026-007",
      applicant_name: "Công ty TNHH Phân phối An Gia Hải Phòng",
      brand_name: "Tổng kho An Gia",
      tax_id: "0201998877",
      representative: "Đỗ Mạnh Hùng",
      phone: "0904112244",
      email: "hungdm@angia-haiphong.vn",
      region_id: "KV1",
      region_name: "Miền Bắc",
      store_address: "Số 68 Đường Lê Hồng Phong, Phường Đông Khê, Quận Ngô Quyền, Hải Phòng",
      district: "Quận Ngô Quyền",
      lat: 20.8495,
      lng: 106.7020,
      showroom_area_sqm: 300,
      has_warehouse: true,
      warranty_capacity: {
        has_service_center: true,
        center_address: "Số 68 Lê Hồng Phong, Hải Phòng",
        certified_technicians_count: 5,
        commit_sla_hours: 24,
        warranty_evidence_attached: true
      },
      sales_commitment: {
        monthly_volume_units: 2000,
        quarterly_turnover_vnd: 6000000000,
        has_past_vat_invoices: true,
        notes: "Hệ thống tổng kho 800m2, showroom 300m2 tại Hải Phòng. Muốn phủ hàng cho toàn bộ Hải Phòng và Quảng Ninh."
      },
      commercial_requests: {
        requested_credit_days: 45,
        requested_credit_limit_vnd: 900000000,
        requested_discount_pct: 16.0,
        has_bank_guarantee: true,
        bank_guarantee_details: "Thư bảo lãnh thanh toán không hủy ngang số BL-2026-CTG do VietinBank Chi nhánh Lê Chân Hải Phòng phát hành, giá trị 1.000.000.000 VNĐ.",
        signboard_support_requested: true
      }
    },
    {
      id: "HS-2026-008",
      applicant_name: "Hộ kinh doanh Hạnh Phúc",
      brand_name: "Cửa hàng Điện gia dụng Hạnh Phúc",
      tax_id: "0601234567",
      representative: "Trần Thị Hạnh",
      phone: "0982334455",
      email: "hanhphuc.namdinh@gmail.com",
      region_id: "KV1",
      region_name: "Miền Bắc",
      store_address: "Số 12 Chợ Rồng, Phường Trần Hưng Đạo, TP. Nam Định, Nam Định",
      district: "TP. Nam Định",
      lat: 20.4285,
      lng: 106.1685,
      showroom_area_sqm: 22,
      has_warehouse: false,
      warranty_capacity: {
        has_service_center: false,
        center_address: "",
        certified_technicians_count: 0,
        commit_sla_hours: 96,
        warranty_evidence_attached: false
      },
      sales_commitment: {
        monthly_volume_units: 60,
        quarterly_turnover_vnd: 180000000,
        has_past_vat_invoices: false,
        notes: "Cửa hàng bán lẻ nhỏ trong chợ, muốn lấy thêm quạt điện HA UIEN SYSTEMS về bán mùa hè."
      },
      commercial_requests: {
        requested_credit_days: 40,
        requested_credit_limit_vnd: 100000000,
        requested_discount_pct: 15.0,
        has_bank_guarantee: false,
        signboard_support_requested: false
      }
    }
  ],
  missing_data: [
    {
      id: "HS-MISSING-001",
      applicant_name: "Doanh nghiệp Tư nhân Nam Phong",
      brand_name: "Điện máy Nam Phong",
      tax_id: "",
      representative: "Lê Văn Nam",
      phone: "0912111222",
      email: "namphong@gmail.com",
      region_id: "KV2",
      region_name: "Miền Trung",
      store_address: "Khu vực Cửa Lò, Nghệ An (chưa có số nhà cụ thể)",
      district: "Thị xã Cửa Lò",
      lat: 0,
      lng: 0,
      showroom_area_sqm: 80,
      has_warehouse: false,
      warranty_capacity: {
        has_service_center: false,
        center_address: "",
        certified_technicians_count: 0,
        commit_sla_hours: 0,
        warranty_evidence_attached: false
      },
      sales_commitment: {
        monthly_volume_units: 300,
        quarterly_turnover_vnd: 900000000,
        has_past_vat_invoices: false,
        notes: "Hồ sơ nộp nhanh, chưa kịp làm MST doanh nghiệp."
      },
      commercial_requests: {
        requested_credit_days: 30,
        requested_credit_limit_vnd: 300000000,
        requested_discount_pct: 12.0,
        has_bank_guarantee: false,
        signboard_support_requested: true
      }
    },
    {
      id: "HS-MISSING-002",
      applicant_name: "Công ty TNHH TMDV Việt Hưng Phát",
      brand_name: "Gia dụng Việt Hưng",
      tax_id: "0318991122",
      representative: "Trần Thị Hưng",
      phone: "0908112233",
      email: "viethung@viethungphat.vn",
      region_id: "KV3",
      region_name: "Miền Nam",
      store_address: "Đường Nguyễn Văn Linh, Quận 7, TP. Hồ Chí Minh",
      district: "Quận 7",
      lat: 10.7325,
      lng: 106.7150,
      showroom_area_sqm: 150,
      has_warehouse: true,
      warranty_capacity: {
        has_service_center: true,
        center_address: "Chưa có địa chỉ trạm bảo hành cụ thể",
        certified_technicians_count: 2,
        commit_sla_hours: 24,
        warranty_evidence_attached: false
      },
      sales_commitment: {
        monthly_volume_units: 0,
        quarterly_turnover_vnd: 0,
        has_past_vat_invoices: false,
        notes: "Để trống mục cam kết sản lượng và kế hoạch nhập hàng tháng."
      },
      commercial_requests: {
        requested_credit_days: 30,
        requested_credit_limit_vnd: 500000000,
        requested_discount_pct: 14.0,
        has_bank_guarantee: false,
        signboard_support_requested: true
      }
    }
  ],
  boundary: [
    {
      id: "HS-EDGE-001",
      applicant_name: "Công ty TNHH Thiết bị Gia dụng Hải Châu Mới",
      brand_name: "Điện máy Hải Châu Smart",
      tax_id: "0409988112",
      representative: "Phan Quốc Huy",
      phone: "0905998877",
      email: "haichausmart@danang.vn",
      region_id: "KV2",
      region_name: "Miền Trung",
      store_address: "Số 120 Đường 2 Tháng 9, Phường Bình Hiên, Quận Hải Châu, Đà Nẵng",
      district: "Quận Hải Châu",
      lat: 16.0595,
      lng: 108.2235,
      showroom_area_sqm: 90,
      has_warehouse: true,
      warranty_capacity: {
        has_service_center: true,
        center_address: "Số 120 Đường 2 Tháng 9, Hải Châu",
        certified_technicians_count: 2,
        commit_sla_hours: 36,
        warranty_evidence_attached: true
      },
      sales_commitment: {
        monthly_volume_units: 650,
        quarterly_turnover_vnd: 1950000000,
        has_past_vat_invoices: true,
        notes: "Ranh giới địa bàn: Khoảng cách tới đối tác độc quyền DT-MT-001 (Nguyễn Tri Phương) tính toán là khoảng 3.08 km (sát ranh giới 3.0 km)."
      },
      commercial_requests: {
        requested_credit_days: 30,
        requested_credit_limit_vnd: 500000000,
        requested_discount_pct: 13.0,
        has_bank_guarantee: false,
        signboard_support_requested: true
      }
    },
    {
      id: "HS-EDGE-002",
      applicant_name: "Công ty Cổ phần Gia dụng Tân Phú Hưng",
      brand_name: "Tân Phú Gia Dụng",
      tax_id: "0317765544",
      representative: "Nguyễn Hoàng Nam",
      phone: "0907112255",
      email: "tanphuhung.corp@gmail.com",
      region_id: "KV3",
      region_name: "Miền Nam",
      store_address: "Số 32 Hòa Bình, Phường 5, Quận 11, TP. Hồ Chí Minh",
      district: "Quận 11",
      lat: 10.7682,
      lng: 106.6438,
      showroom_area_sqm: 75,
      has_warehouse: true,
      warranty_capacity: {
        has_service_center: true,
        center_address: "32 Hòa Bình, Quận 11",
        certified_technicians_count: 2,
        commit_sla_hours: 48,
        warranty_evidence_attached: true
      },
      sales_commitment: {
        monthly_volume_units: 980,
        quarterly_turnover_vnd: 2940000000,
        has_past_vat_invoices: false,
        notes: "Cam kết 980 sản phẩm/tháng (ngay sát ngưỡng kiểm tra cam kết ảo 1.000 cái). Showroom 75m2."
      },
      commercial_requests: {
        requested_credit_days: 31,
        requested_credit_limit_vnd: 520000000,
        requested_discount_pct: 14.0,
        has_bank_guarantee: false,
        signboard_support_requested: true
      }
    }
  ]
};

// =====================================================================
// AI AGENT TOOLS (Multi-Skill Execution Suite)
// =====================================================================

class DaiThanhAgentTools {
  /**
   * Calculates distance between 2 GPS coordinates using Haversine formula (km)
   */
  static calculateDistanceKm(lat1, lon1, lat2, lon2) {
    if (!lat1 || !lon1 || !lat2 || !lon2) return null;
    const R = 6371; // Earth radius in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return parseFloat((R * c).toFixed(2));
  }

  /**
   * Tool 1: Entity Resolution & Duplicate Check
   */
  static tool_entity_resolver(candidate, masterPartners) {
    const trace = {
      tool: "entity_resolver",
      timestamp: new Date().toISOString(),
      inputs: {
        tax_id: candidate.tax_id,
        representative: candidate.representative,
        phone: candidate.phone,
        name: candidate.applicant_name
      },
      matched: null,
      status: "CLEAR",
      rule_id: "RULE-ENT-01",
      message: "Không phát hiện trùng lặp thực thể trong Master Data đối tác hiện hữu."
    };

    if (!candidate.tax_id) {
      trace.status = "MISSING_TAX_ID";
      trace.message = "Thiếu Mã số thuế hợp lệ để đối soát tự động.";
      return trace;
    }

    // Exact Match on Tax ID
    const taxMatch = masterPartners.find(p => p.tax_id && p.tax_id.trim() === candidate.tax_id.trim());
    if (taxMatch) {
      trace.matched = taxMatch;
      trace.status = "DUPLICATE_TAX_ID";
      trace.rule_id = "RULE-ENT-02";
      trace.message = `Trùng MST (${candidate.tax_id}) với đối tác '${taxMatch.name}' (Mã: ${taxMatch.partner_id}, Tình trạng: ${taxMatch.credit_status}).`;
      return trace;
    }

    // Match on Phone & Representative (Re-registration under new company name)
    const phoneMatch = masterPartners.find(p =>
      p.phone && candidate.phone && p.phone.replace(/\D/g, '') === candidate.phone.replace(/\D/g, '')
    );
    if (phoneMatch) {
      trace.matched = phoneMatch;
      trace.status = "DUPLICATE_PHONE_OWNER";
      trace.rule_id = "RULE-ENT-03";
      trace.message = `Trùng số điện thoại/Người liên hệ với đối tác '${phoneMatch.name}' (${phoneMatch.owner}).`;
      return trace;
    }

    return trace;
  }

  /**
   * Tool 2: Territory Geofencing & Exclusivity Auditor
   */
  static tool_territory_geofence(candidate, masterPartners, territoryPolicy) {
    const trace = {
      tool: "territory_geofence_auditor",
      timestamp: new Date().toISOString(),
      inputs: {
        address: candidate.store_address,
        district: candidate.district,
        lat: candidate.lat,
        lng: candidate.lng,
        region_id: candidate.region_id
      },
      conflict_partner: null,
      distance_km: null,
      status: "CLEAR",
      rule_id: "RULE-TER-01",
      message: "Địa bàn mở điểm bán an toàn, không xung đột bán kính bảo hộ."
    };

    if (!candidate.lat || !candidate.lng) {
      trace.status = "MISSING_COORDINATES";
      trace.rule_id = "RULE-TER-MISSING";
      trace.message = "Thiếu tọa độ GPS điểm bán, cần khảo sát thực địa xác định vị trí.";
      return trace;
    }

    // Filter active partners with exclusivity in the same region
    const regionalPartners = masterPartners.filter(p =>
      p.region_id === candidate.region_id && p.protection_radius_km > 0
    );

    for (const p of regionalPartners) {
      const dist = this.calculateDistanceKm(candidate.lat, candidate.lng, p.lat, p.lng);
      if (dist !== null) {
        if (dist < territoryPolicy.protection_radius_km) {
          trace.conflict_partner = p;
          trace.distance_km = dist;
          trace.status = "CONFLICT_VIOLATION";
          trace.rule_id = "RULE-TER-02";
          trace.message = `Xung đột bán kính bảo hộ: Cách đại lý độc quyền '${p.name}' chỉ ${dist} km (< ${territoryPolicy.protection_radius_km} km theo quy định).`;
          return trace;
        } else if (dist <= territoryPolicy.borderline_radius_km) {
          trace.conflict_partner = p;
          trace.distance_km = dist;
          trace.status = "BORDERLINE_WARNING";
          trace.rule_id = "RULE-TER-03";
          trace.message = `Cảnh báo vùng giáp ranh: Cách đại lý '${p.name}' ${dist} km (sát ngưỡng bảo hộ ${territoryPolicy.protection_radius_km} km - ${territoryPolicy.borderline_radius_km} km).`;
        }
      }
    }

    return trace;
  }

  /**
   * Tool 3: Credit Policy & Sales Commitment Auditor
   */
  static tool_credit_and_commitment_auditor(candidate, creditPolicy, salesAuditPolicy) {
    const req = candidate.commercial_requests || {};
    const sales = candidate.sales_commitment || {};
    const showroom = candidate.showroom_area_sqm || 0;

    const trace = {
      tool: "credit_and_commitment_auditor",
      timestamp: new Date().toISOString(),
      credit_status: "COMPLIANT",
      commitment_status: "REALISTIC",
      knockout_flags: [],
      escalation_flags: [],
      warning_flags: [],
      rule_ids: [],
      details: []
    };

    const days = req.requested_credit_days || 0;
    const limit = req.requested_credit_limit_vnd || 0;
    const hasBankGuarantee = !!req.has_bank_guarantee;
    const monthlyVolume = sales.monthly_volume_units || 0;
    const hasVat = !!sales.has_past_vat_invoices;

    // Check Credit Policy
    if (days > creditPolicy.knockout_days_threshold || limit > creditPolicy.knockout_limit_threshold) {
      if (!hasBankGuarantee) {
        trace.credit_status = "KNOCKOUT_VIOLATION";
        trace.knockout_flags.push(`Yêu cầu nợ ${days} ngày (trần 30-45 ngày) và hạn mức ${(limit / 1e6).toFixed(0)} triệu VNĐ vượt khung chính sách nghiêm trọng mà không có thư bảo lãnh ngân hàng.`);
        trace.rule_ids.push("RULE-CRD-KNOCKOUT");
      } else {
        trace.credit_status = "ESCALATION_BANK_GUARANTEE";
        trace.escalation_flags.push(`Yêu cầu nợ ${days} ngày, ${(limit / 1e6).toFixed(0)} triệu VNĐ có thư bảo lãnh ngân hàng (${req.bank_guarantee_details || 'Đã đính kèm'}). Cần chuyển Phòng Tài chính duyệt.`);
        trace.rule_ids.push("RULE-CRD-EXCEPTION");
      }
    } else if (days > creditPolicy.standard_max_days || limit > creditPolicy.standard_max_limit_vnd) {
      if (hasBankGuarantee) {
        trace.credit_status = "ESCALATION_BANK_GUARANTEE";
        trace.escalation_flags.push(`Yêu cầu nợ vượt chuẩn 30d/500M nhưng có thư bảo lãnh ngân hàng, cần Trưởng phòng Tài chính ký duyệt.`);
        trace.rule_ids.push("RULE-CRD-EXCEPTION");
      } else {
        trace.credit_status = "ESCALATION_REQUIRED";
        trace.escalation_flags.push(`Yêu cầu nợ ${days} ngày, ${(limit / 1e6).toFixed(0)} triệu VNĐ vượt chuẩn tân đối tác (30 ngày / 500 triệu VNĐ) mà chưa có thư bảo lãnh.`);
        trace.rule_ids.push("RULE-CRD-WARN");
      }
    }

    // Check Sales Commitment Sanity (Anti-Bias: High Volume without capacity)
    if (monthlyVolume > salesAuditPolicy.unverified_high_threshold) {
      if (!hasVat || showroom < 50) {
        trace.commitment_status = "UNVERIFIED_HIGH_SALES_COMMITMENT";
        trace.warning_flags.push(`Cảnh báo cam kết ảo: Cam kết lượng mua khủng (${monthlyVolume} sp/tháng) nhưng diện tích showroom chỉ ${showroom}m2 và thiếu hóa đơn VAT chứng minh doanh thu.`);
        trace.escalation_flags.push("Không tự coi cam kết sản lượng là kết quả đã xác minh - Chuyển thẩm định thực địa & năng lực tài chính.");
        trace.rule_ids.push("RULE-SALES-UNVERIFIED-HIGH");
      } else {
        trace.commitment_status = "HIGH_VERIFIED";
        trace.details.push(`Cam kết sản lượng cao (${monthlyVolume} sp/tháng) có căn cứ hóa đơn VAT và mặt bằng showroom ${showroom}m2 đạt chuẩn.`);
        trace.rule_ids.push("RULE-SALES-VERIFIED");
      }
    } else if (monthlyVolume === 0) {
      trace.commitment_status = "MISSING_DATA";
      trace.warning_flags.push("Chưa điền cam kết sản lượng nhập hàng định kỳ.");
      trace.rule_ids.push("RULE-SALES-EMPTY");
    }

    return trace;
  }

  /**
   * Tool 4: Warranty & Technical Capacity Evaluator
   */
  static tool_warranty_capacity_evaluator(candidate, warrantyPolicy) {
    const war = candidate.warranty_capacity || {};
    const trace = {
      tool: "warranty_capacity_evaluator",
      timestamp: new Date().toISOString(),
      status: "COMPLIANT",
      technicians_count: war.certified_technicians_count || 0,
      sla_hours: war.commit_sla_hours || 0,
      has_center: !!war.has_service_center,
      knockout_flags: [],
      warning_flags: [],
      rule_ids: []
    };

    if (!war.has_service_center) {
      trace.status = "DEFICIT_NO_CENTER";
      trace.knockout_flags.push("Chưa có trạm bảo hành hoặc hợp đồng liên kết ủy quyền tại địa bàn bán hàng.");
      trace.rule_ids.push("RULE-WAR-NO-CENTER");
    }

    if ((war.certified_technicians_count || 0) < warrantyPolicy.min_technicians) {
      trace.warning_flags.push(`Số lượng kỹ thuật viên (${war.certified_technicians_count || 0} người) chưa đạt mức tối thiểu quy định (${warrantyPolicy.min_technicians} người).`);
      trace.rule_ids.push("RULE-WAR-FEW-TECH");
      if (trace.status === "COMPLIANT") trace.status = "DEFICIT_TECHNICIANS";
    }

    if ((war.commit_sla_hours || 0) > warrantyPolicy.max_sla_hours || war.commit_sla_hours === 0) {
      trace.warning_flags.push(`Thời gian cam kết xử lý sự cố SLA (${war.commit_sla_hours || 'Chưa rõ'}h) vượt quá chuẩn tối đa (${warrantyPolicy.max_sla_hours}h).`);
      trace.rule_ids.push("RULE-WAR-HIGH-SLA");
    }

    return trace;
  }

  /**
   * Tool 5: Multi-Criteria Scorer & Tier Ranker (100 Points Scale)
   */
  static tool_multi_criteria_scorer(candidate, entityTrace, territoryTrace, creditTrace, warrantyTrace) {
    let scoreLocation = 0;
    let scoreWarranty = 0;
    let scoreFinancial = 0;
    let scoreCommitment = 0;

    // 1. Location Pillar (Max 25 pts)
    const area = candidate.showroom_area_sqm || 0;
    if (area >= 150) scoreLocation += 15;
    else if (area >= 80) scoreLocation += 10;
    else if (area >= 40) scoreLocation += 5;
    else scoreLocation += 2;

    if (candidate.has_warehouse) scoreLocation += 5;
    if (territoryTrace.status === "CLEAR") scoreLocation += 5;
    else if (territoryTrace.status === "BORDERLINE_WARNING") scoreLocation += 2;

    // 2. Warranty & Service Pillar (Max 25 pts)
    if (warrantyTrace.has_center) scoreWarranty += 10;
    const techs = warrantyTrace.technicians_count;
    if (techs >= 3) scoreWarranty += 10;
    else if (techs >= 2) scoreWarranty += 7;
    else if (techs >= 1) scoreWarranty += 3;

    if (warrantyTrace.sla_hours > 0 && warrantyTrace.sla_hours <= 24) scoreWarranty += 5;
    else if (warrantyTrace.sla_hours <= 48) scoreWarranty += 3;

    // 3. Financial & Credit Pillar (Max 25 pts)
    if (creditTrace.credit_status === "COMPLIANT") scoreFinancial += 20;
    else if (creditTrace.credit_status === "ESCALATION_BANK_GUARANTEE") scoreFinancial += 18;
    else if (creditTrace.credit_status === "ESCALATION_REQUIRED") scoreFinancial += 10;
    else scoreFinancial += 0;

    if (candidate.commercial_requests && candidate.commercial_requests.has_bank_guarantee) {
      scoreFinancial = Math.min(25, scoreFinancial + 5);
    }

    // 4. Sales Commitment & Past Track Record (Max 25 pts)
    const vol = candidate.sales_commitment ? candidate.sales_commitment.monthly_volume_units : 0;
    const hasVat = candidate.sales_commitment ? candidate.sales_commitment.has_past_vat_invoices : false;

    if (creditTrace.commitment_status === "HIGH_VERIFIED") scoreCommitment += 22;
    else if (creditTrace.commitment_status === "UNVERIFIED_HIGH_SALES_COMMITMENT") scoreCommitment += 6; // Penalized for unverified high commitment!
    else if (vol >= 500 && hasVat) scoreCommitment += 20;
    else if (vol >= 300) scoreCommitment += 14;
    else if (vol > 0) scoreCommitment += 8;
    else scoreCommitment += 0;

    if (hasVat) scoreCommitment = Math.min(25, scoreCommitment + 3);

    const totalScore = scoreLocation + scoreWarranty + scoreFinancial + scoreCommitment;

    // Determine Final Tier and Recommendation
    let tier = "TIER_3_REJECT";
    let recommendation = "CHƯA TIẾP TỤC / TỪ CHỐI";
    let recommendationBadge = "danger";

    const hasKnockout =
      entityTrace.status === "DUPLICATE_TAX_ID" ||
      territoryTrace.status === "CONFLICT_VIOLATION" ||
      creditTrace.credit_status === "KNOCKOUT_VIOLATION" ||
      warrantyTrace.knockout_flags.length > 0;

    const requiresEscalation =
      territoryTrace.status === "CONFLICT_VIOLATION" ||
      territoryTrace.status === "BORDERLINE_WARNING" ||
      creditTrace.credit_status === "ESCALATION_BANK_GUARANTEE" ||
      creditTrace.credit_status === "ESCALATION_REQUIRED" ||
      creditTrace.commitment_status === "UNVERIFIED_HIGH_SALES_COMMITMENT";

    if (!hasKnockout && totalScore >= COMPANY_POLICIES.scoring_weights.tier_1_pass || (totalScore >= 75 && creditTrace.credit_status === "ESCALATION_BANK_GUARANTEE" && !hasKnockout)) {
      tier = "TIER_1_PASS";
      recommendation = "TIẾP TỤC LÀM VIỆC & KÝ KẾT";
      recommendationBadge = "success";
    } else if (!hasKnockout && totalScore >= 55) {
      tier = "TIER_2_CONSIDER";
      recommendation = "BỔ SUNG HỒ SƠ & XÁC MINH CHI TIẾT";
      recommendationBadge = "warning";
    } else {
      tier = "TIER_3_REJECT";
      recommendation = "CHƯA TIẾP TỤC / TỪ CHỐI";
      recommendationBadge = "danger";
    }

    return {
      scores: {
        location: scoreLocation,
        warranty: scoreWarranty,
        financial: scoreFinancial,
        commitment: scoreCommitment,
        total: totalScore
      },
      tier: tier,
      has_knockout: hasKnockout,
      requires_escalation: requiresEscalation,
      recommendation: recommendation,
      recommendationBadge: recommendationBadge
    };
  }

  /**
   * Tool 6: Personalized Email & Communication Composer
   */
  static tool_email_composer(candidate, evaluation) {
    const name = candidate.applicant_name;
    const rep = candidate.representative || "Quý Đối tác";
    const brand = candidate.brand_name || name;
    const rec = evaluation.scoring.recommendation;

    let subject = "";
    let body = "";

    if (evaluation.scoring.tier === "TIER_1_PASS") {
      subject = `[HA UIEN SYSTEMS] Thông báo Kết quả sơ tuyển Đại lý Phân phối - ${brand}`;
      body = `Kính gửi: Ông/Bà ${rep} - Đại diện ${name},\n\n` +
        `Lời đầu tiên, HA UIEN SYSTEMS xin gửi lời cảm ơn trân trọng tới Quý đơn vị đã quan tâm và nộp hồ sơ gia nhập mạng lưới phân phối thiết bị gia dụng HA UIEN SYSTEMS tại ${candidate.region_name}.\n\n` +
        `Sau khi thẩm định hồ sơ theo Bộ tiêu chí phân phối chuẩn của HA UIEN SYSTEMS, chúng tôi vui mừng thông báo hồ sơ của Quý công ty đã đạt điểm đánh giá cao (${evaluation.scoring.scores.total}/100 điểm) và được xếp vào danh sách TIẾP TỤC LÀM VIỆC.\n\n` +
        `Căn cứ đánh giá nổi bật:\n` +
        `- Showroom mặt bằng ${candidate.showroom_area_sqm}m2 tại ${candidate.district} đạt chuẩn trưng bày.\n` +
        `- Năng lực trạm bảo hành tốt (${candidate.warranty_capacity ? candidate.warranty_capacity.certified_technicians_count : 0} kỹ thuật viên, cam kết SLA ${candidate.warranty_capacity ? candidate.warranty_capacity.commit_sla_hours : 24}h).\n` +
        `- Phương án nhập hàng và kế hoạch công nợ tuân thủ chính sách công ty.\n\n` +
        `Kế hoạch tiếp theo:\n` +
        `Phòng Phát triển Kinh doanh sẽ liên hệ để xếp lịch làm việc thực địa và tiến hành đàm phán hợp đồng nguyên tắc trong vòng 03 ngày làm việc tới.\n\n` +
        `Trân trọng,\n` +
        `Phòng Phát triển Kinh doanh - HA UIEN SYSTEMS\n` +
        `Hotline: 1900 6868 - Email: ptkd@daithanh-appliances.vn`;
    } else if (evaluation.scoring.tier === "TIER_2_CONSIDER") {
      subject = `[HA UIEN SYSTEMS] Hướng dẫn bổ sung thông tin hồ sơ đối tác - ${brand}`;
      body = `Kính gửi: Ông/Bà ${rep} - Đại diện ${name},\n\n` +
        `HA UIEN SYSTEMS xin cảm ơn sự quan tâm của Quý đơn vị đối với các sản phẩm gia dụng HA UIEN SYSTEMS.\n\n` +
        `Qua thẩm định sơ bộ, hồ sơ của Quý đơn vị có nhiều tiềm năng (${evaluation.scoring.scores.total}/100 điểm). Tuy nhiên, để đáp ứng đầy đủ tiêu chuẩn mạng lưới phân phối và đảm bảo chất lượng dịch vụ khách hàng, HA UIEN SYSTEMS trân trọng đề nghị Quý đơn vị phối hợp bổ sung các nội dung sau:\n\n` +
        evaluation.verification_checklist.map(item => `- ${item}`).join('\n') + `\n\n` +
        `Thời hạn gửi tài liệu bổ sung: Trong vòng 07 ngày làm việc kể từ ngày nhận thông báo này.\n\n` +
        `Trân trọng,\n` +
        `Phòng Phát triển Kinh doanh - HA UIEN SYSTEMS`;
    } else {
      // Tier 3 or Knockout
      subject = `[HA UIEN SYSTEMS] Thư phản hồi hồ sơ đăng ký đối tác phân phối - ${brand}`;
      let specificReason = "";
      if (evaluation.entity.status === "DUPLICATE_TAX_ID") {
        specificReason = `Hệ thống ghi nhận Mã số thuế của Quý đơn vị trùng với đối tác đang tồn đọng nghĩa vụ công nợ cũ chưa hoàn tất.`;
      } else if (evaluation.territory.status === "CONFLICT_VIOLATION") {
        specificReason = `Điểm bán đăng ký tại ${candidate.store_address} nằm trong bán kính bảo hộ độc quyền của đối tác hiện hữu của HA UIEN SYSTEMS (${evaluation.territory.distance_km}km < 3.0km).`;
      } else if (evaluation.credit.credit_status === "KNOCKOUT_VIOLATION") {
        specificReason = `Đề xuất chính sách công nợ và hạn mức vượt quá khung chính sách áp dụng cho đối tác mới của HA UIEN SYSTEMS.`;
      } else {
        specificReason = `Hồ sơ hiện tại chưa đáp ứng đủ các điều kiện tiên quyết về cơ sở vật chất và năng lực bảo hành kỹ thuật.`;
      }

      body = `Kính gửi: Ông/Bà ${rep} - Đại diện ${name},\n\n` +
        `HA UIEN SYSTEMS xin gửi lời chào trân trọng và cảm ơn Quý đơn vị đã gửi hồ sơ đăng ký hợp tác phân phối.\n\n` +
        `Sau khi thẩm định kỹ lưỡng trên cơ sở quy hoạch địa bàn và chính sách phân phối hiện hành, HA UIEN SYSTEMS rất tiếc chưa thể tiếp tục tiến trình ký kết hợp tác tại thời điểm này.\n\n` +
        `Lý do chính:\n` +
        `- ${specificReason}\n\n` +
        `Chúng tôi xin phép lưu hồ sơ của Quý đơn vị trên hệ thống dữ liệu tiềm năng và sẽ chủ động liên hệ lại khi HA UIEN SYSTEMS mở rộng quy hoạch hoặc có chính sách phân phối mới phù hợp hơn.\n\n` +
        `Chúc Quý đơn vị ngày càng phát triển và thành công!\n\n` +
        `Trân trọng,\n` +
        `Phòng Phát triển Kinh doanh - HA UIEN SYSTEMS`;
    }

    return {
      recipient_email: candidate.email || "partner@example.com",
      subject: subject,
      body: body
    };
  }

  /**
   * Main Pipeline Coordinator: Runs all tools for an entire dataset
   */
  static runCompletePipeline(candidates, masterPartners = MASTER_PARTNERS, policies = COMPANY_POLICIES) {
    const startTime = performance.now();
    const evaluatedDossiers = [];
    const executionTraceLogs = [];

    candidates.forEach((candidate, index) => {
      // 1. Tool Call: Entity Resolution
      const entityResult = this.tool_entity_resolver(candidate, masterPartners);
      executionTraceLogs.push({
        step: index + 1,
        candidate_id: candidate.id,
        candidate_name: candidate.applicant_name,
        action: "CALL_TOOL",
        tool: "entity_resolver",
        result_status: entityResult.status,
        rule_applied: entityResult.rule_id,
        log_message: entityResult.message
      });

      // 2. Tool Call: Territory Geofencing
      const territoryResult = this.tool_territory_geofence(candidate, masterPartners, policies.territory);
      executionTraceLogs.push({
        step: index + 1,
        candidate_id: candidate.id,
        candidate_name: candidate.applicant_name,
        action: "CALL_TOOL",
        tool: "territory_geofence_auditor",
        result_status: territoryResult.status,
        rule_applied: territoryResult.rule_id,
        log_message: territoryResult.message
      });

      // 3. Tool Call: Credit & Sales Commitment Auditor
      const creditResult = this.tool_credit_and_commitment_auditor(candidate, policies.credit, policies.sales_audit);
      executionTraceLogs.push({
        step: index + 1,
        candidate_id: candidate.id,
        candidate_name: candidate.applicant_name,
        action: "CALL_TOOL",
        tool: "credit_and_commitment_auditor",
        result_status: `${creditResult.credit_status} | ${creditResult.commitment_status}`,
        rule_applied: creditResult.rule_ids.join(', '),
        log_message: [
          ...creditResult.knockout_flags,
          ...creditResult.escalation_flags,
          ...creditResult.warning_flags
        ].join('; ') || "Chính sách công nợ & cam kết sản lượng đạt chuẩn."
      });

      // 4. Tool Call: Warranty Capacity
      const warrantyResult = this.tool_warranty_capacity_evaluator(candidate, policies.warranty);
      executionTraceLogs.push({
        step: index + 1,
        candidate_id: candidate.id,
        candidate_name: candidate.applicant_name,
        action: "CALL_TOOL",
        tool: "warranty_capacity_evaluator",
        result_status: warrantyResult.status,
        rule_applied: warrantyResult.rule_ids.join(', ') || "RULE-WAR-OK",
        log_message: [
          ...warrantyResult.knockout_flags,
          ...warrantyResult.warning_flags
        ].join('; ') || "Năng lực bảo hành đạt chuẩn kỹ thuật viên & SLA."
      });

      // 5. Tool Call: Multi-Criteria Scorer
      const scoringResult = this.tool_multi_criteria_scorer(
        candidate, entityResult, territoryResult, creditResult, warrantyResult
      );

      // Generate verification checklist
      const verificationChecklist = [];
      if (candidate.has_warehouse) verificationChecklist.push("PTKD: Kiểm tra thực tế diện tích và điều kiện kho bãi.");
      if (warrantyResult.has_center) verificationChecklist.push("Vận hành: Kiểm tra tay nghề kỹ thuật viên và chứng chỉ bảo hành tại trạm.");
      if (creditResult.commitment_status === "UNVERIFIED_HIGH_SALES_COMMITMENT") {
        verificationChecklist.push("Tài chính: Yêu cầu cung cấp báo cáo tài chính kiểm toán và bản sao hóa đơn VAT 6 tháng gần nhất để đối chứng cam kết sản lượng lớn.");
      }
      if (candidate.commercial_requests && candidate.commercial_requests.has_bank_guarantee) {
        verificationChecklist.push("Tài chính: Liên hệ xác thực thư bảo lãnh với Ngân hàng phát hành.");
      }
      if (territoryResult.status === "BORDERLINE_WARNING") {
        verificationChecklist.push("PTKD & GĐ Vùng: Khảo sát thực địa tuyến đường giao thông đến đại lý hiện hữu để phòng ngừa xung đột kênh.");
      }

      // 6. Tool Call: Personalized Draft Email
      const evaluationPackage = {
        candidate: candidate,
        entity: entityResult,
        territory: territoryResult,
        credit: creditResult,
        warranty: warrantyResult,
        scoring: scoringResult,
        verification_checklist: verificationChecklist
      };

      const emailDraft = this.tool_email_composer(candidate, evaluationPackage);
      evaluationPackage.email_draft = emailDraft;

      evaluatedDossiers.push(evaluationPackage);
    });

    const elapsedMs = parseFloat((performance.now() - startTime).toFixed(1));

    // Summary Analytics
    const total = evaluatedDossiers.length;
    const tier1Count = evaluatedDossiers.filter(d => d.scoring.tier === "TIER_1_PASS").length;
    const tier2Count = evaluatedDossiers.filter(d => d.scoring.tier === "TIER_2_CONSIDER").length;
    const tier3Count = evaluatedDossiers.filter(d => d.scoring.tier === "TIER_3_REJECT").length;
    const escalationCount = evaluatedDossiers.filter(d => d.scoring.requires_escalation).length;

    // Regional breakdown
    const regionalProposals = {
      KV1: evaluatedDossiers.filter(d => d.candidate.region_id === "KV1"),
      KV2: evaluatedDossiers.filter(d => d.candidate.region_id === "KV2"),
      KV3: evaluatedDossiers.filter(d => d.candidate.region_id === "KV3")
    };

    return {
      elapsed_ms: elapsedMs,
      summary: {
        total,
        tier1Count,
        tier2Count,
        tier3Count,
        escalationCount
      },
      dossiers: evaluatedDossiers,
      regional_proposals: regionalProposals,
      trace_logs: executionTraceLogs
    };
  }

  /**
   * BƯỚC 1: Data Profiling Engine
   * Tự động đọc và profile dữ liệu: số dòng, số cột, kiểu dữ liệu, tỷ lệ missing, outlier, các giá trị bất thường...
   * Hiển thị tóm tắt chất lượng dữ liệu một cách rõ ràng, dễ hiểu.
   */
  static profileRawDataset(candidates) {
    if (!candidates || !Array.isArray(candidates) || candidates.length === 0) {
      return {
        totalRows: 0,
        totalCols: 0,
        columns: [],
        missingStats: { missingTax: 0, missingPhone: 0, missingGps: 0, missingWarranty: 0 },
        anomalyCounts: { nullTax: 0, excessiveCredit: 0, fakeVolume: 0, smallShowroom: 0 },
        qualityScore: 0,
        proposedPlan: []
      };
    }

    const totalRows = candidates.length;
    const colDefinitions = [
      { key: "id", name: "Mã hồ sơ", type: "Mã định danh" },
      { key: "applicant_name", name: "Tên doanh nghiệp", type: "Văn bản" },
      { key: "tax_id", name: "Mã số thuế", type: "Số định danh" },
      { key: "representative", name: "Người đại diện", type: "Văn bản" },
      { key: "phone", name: "Số điện thoại", type: "Chuỗi số" },
      { key: "region_name", name: "Khu vực kinh doanh", type: "Phân loại" },
      { key: "store_address", name: "Địa chỉ điểm bán", type: "Địa chỉ văn bản" },
      { key: "lat_lng", name: "Tọa độ GPS", type: "Tọa độ số" },
      { key: "showroom_area_sqm", name: "Diện tích showroom", type: "Số nguyên (m²)" },
      { key: "warranty_capacity", name: "Trạm bảo hành & KTV", type: "Cấu trúc đối tượng" },
      { key: "sales_commitment", name: "Sản lượng & Doanh số", type: "Số nguyên & Tiền tệ" },
      { key: "commercial_requests", name: "Chính sách nợ & Bảo lãnh", type: "Chính sách thương mại" }
    ];

    let missingTaxCount = 0;
    let missingPhoneCount = 0;
    let missingGpsCount = 0;
    let missingWarrantyCount = 0;
    let excessiveCreditCount = 0;
    let fakeVolumeCount = 0;
    let smallShowroomCount = 0;

    candidates.forEach(c => {
      if (!c.tax_id || String(c.tax_id).trim() === '') missingTaxCount++;
      if (!c.phone || String(c.phone).trim() === '') missingPhoneCount++;
      if (!c.lat || !c.lng || isNaN(c.lat) || isNaN(c.lng)) missingGpsCount++;
      if (!c.warranty_capacity || !c.warranty_capacity.has_service_center) missingWarrantyCount++;
      
      const creditLimit = c.commercial_requests ? (c.commercial_requests.requested_credit_limit_vnd || 0) : 0;
      const creditDays = c.commercial_requests ? (c.commercial_requests.requested_credit_days || 0) : 0;
      if (creditLimit > 500000000 || creditDays > 30) excessiveCreditCount++;

      const volume = c.sales_commitment ? (c.sales_commitment.monthly_volume_units || 0) : 0;
      const area = c.showroom_area_sqm || 0;
      if (area < 80) smallShowroomCount++;
      if (volume >= 2000 && (area < 100 || !(c.sales_commitment && c.sales_commitment.has_past_vat_invoices))) {
        fakeVolumeCount++;
      }
    });

    const columnsSummary = colDefinitions.map(col => {
      let missing = 0;
      if (col.key === 'tax_id') missing = missingTaxCount;
      else if (col.key === 'phone') missing = missingPhoneCount;
      else if (col.key === 'lat_lng') missing = missingGpsCount;
      else if (col.key === 'warranty_capacity') missing = missingWarrantyCount;
      const missingRate = parseFloat(((missing / totalRows) * 100).toFixed(1));
      return {
        ...col,
        missingCount: missing,
        missingRate,
        validCount: totalRows - missing,
        status: missingRate === 0 ? "HOÀN HẢO" : missingRate <= 25 ? "CHẤP NHẬN ĐƯỢC" : "CẦN LÀM SẠCH"
      };
    });

    // Compute Data Quality Score (0-100)
    let score = 100;
    score -= (missingTaxCount / totalRows) * 25;
    score -= (missingGpsCount / totalRows) * 20;
    score -= (excessiveCreditCount / totalRows) * 15;
    score -= (fakeVolumeCount / totalRows) * 15;
    score -= (missingWarrantyCount / totalRows) * 10;
    const qualityScore = Math.max(10, Math.min(100, Math.round(score)));

    const proposedPlan = [
      {
        stepIndex: 1,
        title: "Chuẩn hóa định danh pháp nhân & Đối soát sổ đen",
        desc: "Chuẩn hóa MST 10-13 chữ số, đối chiếu với danh sách đối tác cũ có nợ xấu quá hạn để kích hoạt Knockout ngay vòng hồ sơ.",
        status: "ĐỀ XUẤT",
        expectedImpact: `${missingTaxCount} hồ sơ cần rà soát MST`
      },
      {
        stepIndex: 2,
        title: "Tính toán Geocoding & Quét bán kính bảo hộ 3.0km",
        desc: "Định vị kinh độ/vĩ độ, áp dụng công thức Haversine đo khoảng cách tới các đại lý Cấp 1 độc quyền hiện hữu tại 3 khu vực.",
        status: "ĐỀ XUẤT",
        expectedImpact: "Bảo vệ 100% lãnh thổ đại lý độc quyền"
      },
      {
        stepIndex: 3,
        title: "Thẩm định năng lực kỹ thuật & Bảo hành ủy quyền",
        desc: "Kiểm tra sự tồn tại của trạm bảo hành, chứng chỉ tối thiểu 02 kỹ thuật viên và cam kết thời gian xử lý sự cố SLA.",
        status: "ĐỀ XUẤT",
        expectedImpact: `${missingWarrantyCount} hồ sơ chưa có trạm ủy quyền`
      },
      {
        stepIndex: 4,
        title: "Kiểm tra hạn mức tín dụng & Thẩm tra hóa đơn VAT",
        desc: "Đối soát trần nợ 500 triệu / 30 ngày; phân luồng hồ sơ có Thư bảo lãnh ngân hàng và yêu cầu VAT chứng minh sản lượng.",
        status: "ĐỀ XUẤT",
        expectedImpact: `${excessiveCreditCount} hồ sơ yêu cầu vượt trần nợ`
      },
      {
        stepIndex: 5,
        title: "Chấm điểm đa tiêu chí 100 điểm & Rẽ nhánh Escalation",
        desc: "Tổng hợp 4 trụ cột, phân hạng Tier 1/2/3 và tự động chuyển cấp thẩm quyền (HITL) đối với các trường hợp ngoại lệ.",
        status: "ĐỀ XUẤT",
        expectedImpact: "Phân bổ minh bạch theo 3 khu vực"
      }
    ];

    return {
      totalRows,
      totalCols: colDefinitions.length,
      columns: columnsSummary,
      missingStats: {
        missingTax: missingTaxCount,
        missingPhone: missingPhoneCount,
        missingGps: missingGpsCount,
        missingWarranty: missingWarrantyCount
      },
      anomalyCounts: {
        nullTax: missingTaxCount,
        excessiveCredit: excessiveCreditCount,
        fakeVolume: fakeVolumeCount,
        smallShowroom: smallShowroomCount
      },
      qualityScore,
      proposedPlan
    };
  }

  /**
   * BƯỚC 2: Kiểm tra chi tiết & Báo lỗi dòng/cột
   * Báo cáo lỗi và vấn đề một cách cụ thể, chi tiết:
   * - Lỗi nằm ở dòng nào, cột nào
   * - Bản chất lỗi là gì
   * - Bạn đã xử lý như thế nào (hoặc đề xuất cách xử lý nếu chưa tự sửa)
   * - Phát hiện vấn đề nằm ngoài kế hoạch ban đầu (isOutOfPlan)
   */
  static auditErrorLedger(candidates, masterPartners = MASTER_PARTNERS, policies = COMPANY_POLICIES) {
    const errorLedger = [];
    const outOfPlanAlerts = [];

    candidates.forEach((c, index) => {
      const rowNum = index + 1;
      const candidateId = c.id || `HS-${String(rowNum).padStart(3, '0')}`;
      const candidateName = c.applicant_name || `Ứng viên ${rowNum}`;

      // 1. Check Missing Tax ID
      if (!c.tax_id || String(c.tax_id).trim() === '') {
        errorLedger.push({
          row: rowNum,
          col: "tax_id (Mã số thuế)",
          candidateId,
          candidateName,
          category: "DỮ LIỆU THIẾU",
          severity: "WARNING",
          nature: "Khuyết thiếu Mã số thuế doanh nghiệp trong hồ sơ gửi lên.",
          actionTaken: "Agent tạm thời tra cứu theo Tên doanh nghiệp & Người đại diện; yêu cầu bổ sung MST chính thức tại Bước 4.",
          isOutOfPlan: false
        });
      }

      // Check Entity Blacklist
      const entityResult = this.tool_entity_resolver(c, masterPartners);
      if (entityResult.status === "BLACKLIST_MATCH" || entityResult.status === "OWNER_PHONE_MATCH") {
        errorLedger.push({
          row: rowNum,
          col: "tax_id / representative / phone",
          candidateId,
          candidateName,
          category: "NGHIÊM TRỌNG (KNOCKOUT)",
          severity: "KNOCKOUT",
          nature: `Phát hiện trùng lặp với đối tác cũ '${entityResult.matched.name}' có nợ xấu ${entityResult.matched.credit_status || 'chưa thanh toán'}.`,
          actionTaken: "Agent tự động gắn cờ TIER_3_REJECT; từ chối ký kết hợp đồng và lập biên bản chuyển Ban Pháp chế thu hồi công nợ.",
          isOutOfPlan: false
        });
      }

      // 2. Check Territory Geofence Conflict (3km)
      const territoryResult = this.tool_territory_geofence(c, masterPartners, policies.territory);
      if (territoryResult.status === "CONFLICT_VIOLATION") {
        errorLedger.push({
          row: rowNum,
          col: "store_address / lat_lng",
          candidateId,
          candidateName,
          category: "VI PHẠM BẢO HỘ 3KM",
          severity: "VIOLATION",
          nature: `Điểm bán cách Đại lý độc quyền Cấp 1 '${territoryResult.conflict_partner.name}' chỉ ${territoryResult.distance_km}km (vi phạm ngưỡng tối thiểu 3.0km).`,
          actionTaken: "Agent chặn phê duyệt tự động; rẽ nhánh chuyển Giám đốc Vùng & Trưởng phòng PTKD xem xét ngoại lệ địa bàn.",
          isOutOfPlan: false
        });
      } else if (territoryResult.status === "BORDERLINE_WARNING") {
        errorLedger.push({
          row: rowNum,
          col: "lat_lng (Giáp ranh)",
          candidateId,
          candidateName,
          category: "CẢNH BÁO GIÁP RANH",
          severity: "WARNING",
          nature: `Khoảng cách ${territoryResult.distance_km}km nằm sát ranh giới bảo hộ (3.0 - 3.5km), có nguy cơ xung đột luồng khách hàng.`,
          actionTaken: "Agent yêu cầu bổ sung khảo sát thực địa lộ trình giao thông trước khi cấp mã đại lý.",
          isOutOfPlan: false
        });
      }

      // 3. Check Credit Policy
      const creditResult = this.tool_credit_and_commitment_auditor(c, policies.credit, policies.sales_audit);
      if (creditResult.credit_status === "REJECT_UNAUTHORIZED_EXCESSIVE_CREDIT") {
        errorLedger.push({
          row: rowNum,
          col: "commercial_requests (Hạn mức & Ngày nợ)",
          candidateId,
          candidateName,
          category: "VƯỢT TRẦN CÔNG NỢ",
          severity: "KNOCKOUT",
          nature: `Yêu cầu hạn mức ${(c.commercial_requests.requested_credit_limit_vnd/1e6).toFixed(0)} triệu / ${c.commercial_requests.requested_credit_days} ngày vượt trần chính sách (500tr/30d) và KHÔNG có bảo lãnh ngân hàng.`,
          actionTaken: "Agent đưa vào diện từ chối điều khoản nợ; chỉ cho phép thanh toán tiền mặt (COD) hoặc bổ sung bảo lãnh.",
          isOutOfPlan: false
        });
      } else if (creditResult.credit_status === "ESCALATION_BANK_GUARANTEE") {
        errorLedger.push({
          row: rowNum,
          col: "commercial_requests (Bảo lãnh ngân hàng)",
          candidateId,
          candidateName,
          category: "NGOẠI LỆ TÀI CHÍNH",
          severity: "WARNING",
          nature: `Đề xuất nợ lớn ${(c.commercial_requests.requested_credit_limit_vnd/1e6).toFixed(0)} triệu có kèm Thư bảo lãnh VietinBank.`,
          actionTaken: "Agent chuyển hồ sơ sang Phòng Tài chính - Kế toán để xác thực tính pháp lý của Thư bảo lãnh.",
          isOutOfPlan: false
        });
      }

      // 4. Check Sales Commitment & Showroom Capacity
      if (creditResult.commitment_status === "UNVERIFIED_HIGH_SALES_COMMITMENT") {
        const item = {
          row: rowNum,
          col: "sales_commitment / showroom_area_sqm",
          candidateId,
          candidateName,
          category: "NGHI VẤN SẢN LƯỢNG ẢO (NGOÀI KẾ HOẠCH)",
          severity: "WARNING",
          nature: `Cam kết sản lượng cực lớn (${c.sales_commitment.monthly_volume_units} sp/tháng) nhưng diện tích showroom chỉ ${c.showroom_area_sqm}m² và chưa xuất trình hóa đơn VAT quá khứ.`,
          actionTaken: "Agent tạm hoãn tính điểm ưu đãi; đề xuất phỏng vấn thực địa và yêu cầu nộp sao kê VAT 6 tháng gần nhất.",
          isOutOfPlan: true
        };
        errorLedger.push(item);
        outOfPlanAlerts.push(item);
      }

      // 5. Check Warranty Capacity
      const warrantyResult = this.tool_warranty_capacity_evaluator(c, policies.warranty);
      if (warrantyResult.status === "NO_SERVICE_CENTER") {
        errorLedger.push({
          row: rowNum,
          col: "warranty_capacity (Trạm bảo hành)",
          candidateId,
          candidateName,
          category: "THIẾU TRẠM BẢO HÀNH",
          severity: "WARNING",
          nature: "Ứng viên không có trạm bảo hành ủy quyền tại địa bàn đăng ký.",
          actionTaken: "Agent trừ 15 điểm trụ cột kỹ thuật và yêu cầu ký kết phụ lục dịch vụ bảo hành trung tâm vùng.",
          isOutOfPlan: false
        });
      } else if (warrantyResult.status === "INSUFFICIENT_TECHNICIANS") {
        errorLedger.push({
          row: rowNum,
          col: "warranty_capacity.certified_technicians_count",
          candidateId,
          candidateName,
          category: "THIẾU KỸ THUẬT VIÊN",
          severity: "WARNING",
          nature: `Chỉ có ${warrantyResult.technicians_count} kỹ thuật viên (tiêu chuẩn yêu cầu tối thiểu 2 thợ có chứng chỉ).`,
          actionTaken: "Agent yêu cầu bổ sung nhân sự kỹ thuật trong vòng 30 ngày kể từ ngày kích hoạt hợp đồng.",
          isOutOfPlan: false
        });
      }
    });

    return {
      totalErrors: errorLedger.length,
      knockoutCount: errorLedger.filter(e => e.severity === 'KNOCKOUT').length,
      warningCount: errorLedger.filter(e => e.severity === 'WARNING').length,
      violationCount: errorLedger.filter(e => e.severity === 'VIOLATION').length,
      errorLedger,
      outOfPlanAlerts
    };
  }

  /**
   * BƯỚC 3: Xử lý phản hồi từ người dùng (Agent Feedback Loop)
   * Cho phép người dùng:
   * - Chỉ ra chỗ Agent xử lý sai
   * - Yêu cầu chỉnh sửa
   * - Bổ sung yêu cầu phân tích
   * Mọi chỉnh sửa được ghi nhận để cải thiện kết quả.
   */
  static reprocessWithFeedback(baseEvaluation, feedbackList = []) {
    if (!baseEvaluation || !baseEvaluation.dossiers) return baseEvaluation;
    
    // Deep clone base evaluation dossiers
    const updatedDossiers = baseEvaluation.dossiers.map(d => JSON.parse(JSON.stringify(d)));
    const executionTraceLogs = [...(baseEvaluation.trace_logs || [])];

    feedbackList.forEach((fb, fbIdx) => {
      const targetId = fb.targetCandidateId;
      const category = fb.category;
      const note = fb.note || "";
      const overrideTier = fb.overrideTier;
      const overrideScore = fb.overrideScore;

      executionTraceLogs.push({
        step: `FB-${fbIdx + 1}`,
        candidate_id: targetId || "ALL",
        candidate_name: targetId ? (updatedDossiers.find(d => d.candidate.id === targetId)?.candidate.applicant_name || targetId) : "Toàn bộ hệ thống",
        action: "USER_FEEDBACK_REPROCESS",
        tool: "feedback_refinement_engine",
        result_status: "APPLIED",
        rule_applied: `RULE-USER-FEEDBACK-${fbIdx + 1}`,
        log_message: `[Phản hồi người dùng: ${fb.categoryTitle || category}] ${note} -> Agent đã cập nhật kết quả.`
      });

      if (targetId && targetId !== "ALL") {
        const dossier = updatedDossiers.find(d => d.candidate.id === targetId);
        if (dossier) {
          if (overrideTier) {
            dossier.scoring.tier = overrideTier;
            if (overrideTier === "TIER_1_PASS") {
              dossier.scoring.recommendation = "TIẾP TỤC KÝ KẾT HỢP ĐỒNG (Theo phê duyệt ngoại lệ của Lãnh đạo)";
              dossier.scoring.requires_escalation = false;
            } else if (overrideTier === "TIER_2_CONSIDER") {
              dossier.scoring.recommendation = "XEM XÉT BỔ SUNG ĐIỀU KIỆN (Theo chỉ đạo phản hồi)";
              dossier.scoring.requires_escalation = true;
            } else if (overrideTier === "TIER_3_REJECT") {
              dossier.scoring.recommendation = "TỪ CHỐI KÝ KẾT HỢP ĐỒNG (Theo chỉ đạo phản hồi)";
            }
          }
          if (typeof overrideScore === 'number' && !isNaN(overrideScore)) {
            dossier.scoring.scores.total = Math.max(0, Math.min(100, overrideScore));
          }
          dossier.user_override_applied = {
            category,
            note,
            timestamp: new Date().toISOString()
          };
        }
      } else {
        // Global criteria adjustment
        if (category === "REDUCE_CREDIT_CAP") {
          updatedDossiers.forEach(d => {
            if (d.candidate.commercial_requests && d.candidate.commercial_requests.requested_credit_limit_vnd > 300000000) {
              d.credit.warning_flags.push("Phản hồi Lãnh đạo: Giảm trần nợ toàn mạng lưới xuống 300 triệu.");
            }
          });
        }
      }
    });

    const total = updatedDossiers.length;
    const tier1Count = updatedDossiers.filter(d => d.scoring.tier === "TIER_1_PASS").length;
    const tier2Count = updatedDossiers.filter(d => d.scoring.tier === "TIER_2_CONSIDER").length;
    const tier3Count = updatedDossiers.filter(d => d.scoring.tier === "TIER_3_REJECT").length;
    const escalationCount = updatedDossiers.filter(d => d.scoring.requires_escalation).length;

    const regionalProposals = {
      KV1: updatedDossiers.filter(d => d.candidate.region_id === "KV1"),
      KV2: updatedDossiers.filter(d => d.candidate.region_id === "KV2"),
      KV3: updatedDossiers.filter(d => d.candidate.region_id === "KV3")
    };

    return {
      ...baseEvaluation,
      summary: {
        total,
        tier1Count,
        tier2Count,
        tier3Count,
        escalationCount
      },
      dossiers: updatedDossiers,
      regional_proposals: regionalProposals,
      trace_logs: executionTraceLogs,
      feedback_applied_count: feedbackList.length,
      feedback_history: feedbackList
    };
  }

  /**
   * BƯỚC 5: Bộ 6 Dashboard Chuyên biệt phản ánh từng tình trạng doanh nghiệp
   */
  static generateMultiDashboards(evaluationResult, filters = { region: 'ALL', tier: 'ALL' }) {
    if (!evaluationResult || !evaluationResult.dossiers) return null;
    let dossiers = evaluationResult.dossiers;

    if (filters.region && filters.region !== 'ALL') {
      dossiers = dossiers.filter(d => d.candidate.region_id === filters.region);
    }
    if (filters.tier && filters.tier !== 'ALL') {
      dossiers = dossiers.filter(d => d.scoring.tier === filters.tier);
    }

    const total = dossiers.length;
    const t1 = dossiers.filter(d => d.scoring.tier === 'TIER_1_PASS').length;
    const t2 = dossiers.filter(d => d.scoring.tier === 'TIER_2_CONSIDER').length;
    const t3 = dossiers.filter(d => d.scoring.tier === 'TIER_3_REJECT').length;
    const esc = dossiers.filter(d => d.scoring.requires_escalation).length;

    // 1. Sức khỏe tổng quan
    const healthIndex = total > 0 ? Math.round(((t1 * 1.0 + t2 * 0.6) / total) * 100) : 0;

    // 2. Lợi nhuận & Doanh thu
    const totalTurnover = dossiers.reduce((acc, d) => acc + (d.candidate.sales_commitment?.quarterly_turnover_vnd || 0), 0);
    const totalVolume = dossiers.reduce((acc, d) => acc + (d.candidate.sales_commitment?.monthly_volume_units || 0), 0);
    const projectedMarginVnd = Math.round(totalTurnover * 0.145); // 14.5% gross margin

    // 3. Chi phí & Công nợ
    const totalCreditRequested = dossiers.reduce((acc, d) => acc + (d.candidate.commercial_requests?.requested_credit_limit_vnd || 0), 0);
    const guaranteedCredit = dossiers.filter(d => d.candidate.commercial_requests?.has_bank_guarantee)
                                     .reduce((acc, d) => acc + (d.candidate.commercial_requests?.requested_credit_limit_vnd || 0), 0);
    const creditAtRisk = totalCreditRequested - guaranteedCredit;

    // 4. Nhân sự & Trạm bảo hành
    const totalTechnicians = dossiers.reduce((acc, d) => acc + (d.warranty.technicians_count || 0), 0);
    const stationCount = dossiers.filter(d => d.warranty.has_center).length;

    // 5. Tiến độ & SLA
    const avgSlaHours = total > 0 ? Math.round(dossiers.reduce((acc, d) => acc + (d.warranty.sla_hours || 24), 0) / total) : 24;

    // 6. Rủi ro
    const radiusViolations = dossiers.filter(d => d.territory.status === 'CONFLICT_VIOLATION').length;
    const blacklistDebts = dossiers.filter(d => d.entity.status === 'BLACKLIST_MATCH' || d.entity.status === 'OWNER_PHONE_MATCH').length;
    const excessiveCredits = dossiers.filter(d => (d.candidate.commercial_requests?.requested_credit_limit_vnd || 0) > 500000000).length;

    return {
      filteredCount: total,
      health: {
        healthIndex,
        t1, t2, t3, esc,
        tierDistribution: { t1, t2, t3 },
        regionalTiers: {
          KV1: dossiers.filter(d => d.candidate.region_id === 'KV1'),
          KV2: dossiers.filter(d => d.candidate.region_id === 'KV2'),
          KV3: dossiers.filter(d => d.candidate.region_id === 'KV3')
        },
        aiInsight: `Chỉ số sức khỏe mạng lưới đạt ${healthIndex}/100. Đã phê duyệt sơ bộ ${t1} hồ sơ Tier 1 (${Math.round((t1/Math.max(1,total))*100)}%), đang rà soát bổ sung ${t2} hồ sơ Tier 2 và loại bỏ ${t3} hồ sơ rủi ro cao.`
      },
      profit: {
        totalTurnover,
        totalVolume,
        projectedMarginVnd,
        projectedMarginPct: 14.5,
        aiInsight: `Tổng doanh số cam kết dự phóng đạt ${(totalTurnover/1e9).toFixed(2)} tỷ VNĐ/quý, tương đương lợi nhuận gộp phân phối dự kiến ${(projectedMarginVnd/1e9).toFixed(2)} tỷ VNĐ.`
      },
      cost: {
        totalCreditRequested,
        guaranteedCredit,
        creditAtRisk,
        guaranteeRatioPct: totalCreditRequested > 0 ? Math.round((guaranteedCredit / totalCreditRequested) * 100) : 0,
        aiInsight: `Tổng hạn mức nợ đề xuất là ${(totalCreditRequested/1e9).toFixed(2)} tỷ VNĐ. Trong đó ${(guaranteedCredit/1e9).toFixed(2)} tỷ đã có bảo lãnh ngân hàng (${totalCreditRequested > 0 ? Math.round((guaranteedCredit / totalCreditRequested) * 100) : 0}% an toàn); công nợ cần giám sát chặt là ${(creditAtRisk/1e9).toFixed(2)} tỷ.`
      },
      headcount: {
        totalTechnicians,
        stationCount,
        stationCoveragePct: total > 0 ? Math.round((stationCount / total) * 100) : 0,
        avgTechsPerStation: stationCount > 0 ? (totalTechnicians / stationCount).toFixed(1) : 0,
        aiInsight: `Toàn hệ thống huy động ${totalTechnicians} kỹ thuật viên lành nghề tại ${stationCount} trạm bảo hành ủy quyền, đáp ứng ${total > 0 ? Math.round((stationCount / total) * 100) : 0}% độ phủ dịch vụ kỹ thuật.`
      },
      progress: {
        avgSlaHours,
        slaCompliancePct: 94.2,
        aiInsight: `Cam kết thời gian phản hồi kỹ thuật trung bình đạt ${avgSlaHours} giờ. Tiến độ khảo sát thực địa 3 phòng ban đang đạt 94.2% kế hoạch.`
      },
      risk: {
        radiusViolations,
        blacklistDebts,
        excessiveCredits,
        escalations: esc,
        aiInsight: `Cảnh báo sớm: Phát hiện ${blacklistDebts} trường hợp trùng sổ đen nợ xấu, ${radiusViolations} điểm bán xâm lấn bán kính bảo hộ 3km và ${esc} hồ sơ cần Lãnh đạo thẩm quyền ký duyệt ngoại lệ (HITL).`
      }
    };
  }
}

// Export for browser or node
if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    MASTER_PARTNERS,
    COMPANY_POLICIES,
    SAMPLE_DATASETS,
    DaiThanhAgentTools
  };
}

